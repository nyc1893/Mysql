package web_design;

import java.util.*;
import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
public class read_table {
 

    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
    static final String DB_URL = "jdbc:mysql://localhost:3306/RUNOOB?characterEcoding=utf-8&useSSL=false&serverTimezone=UTC";
 
 
    // ���ݿ���û��������룬��Ҫ�����Լ�������
    static final String USER = "root";
    static final String PASS = "123";

    
    

        Connection conn = null;
        Statement stat = null;
  /*   
        public static Vector getNextRow()
        {
            int i  = 0;
            Vector v = new Vector(); 
            for(i = 0; i<3;i++) 
            {
            	v.add(i); 
            	v.add("CK"); 
            }
    		return v;
    	}
    	
*/
        public static Vector getNextRow()
        {
        	

        	
            Connection conn = null;
            Statement stat = null;
        	Vector v = new Vector(); 

	        try{
	            // ע�� JDBC ����
	            Class.forName(JDBC_DRIVER);
	            // ������
	            System.out.println("�������ݿ�...");
	            conn = DriverManager.getConnection(DB_URL,USER,PASS);
	        
	            // ִ�в�ѯ
	            System.out.println(" ʵ����Statement����...");
	            conn = DriverManager.getConnection(DB_URL,USER,PASS);
	            stat = conn.createStatement();
	          //  Object[][] tableDate=new Object[10][2];
	            int i =0;
	            ResultSet result = stat.executeQuery("select * from test");
	            while (result.next())
	            {
	     //       	id int,price int, number int,ch_name varchar(80),en_name varchar(80),unit varchar(20))
	            	v.add(result.getInt("id"));
	              	v.add(result.getString("ch_name"));
	             //   i = i+1;
	            }
	
	 
	            result.close();
	            stat.close();
	            conn.close();
	
	        }catch(SQLException se){
	            // ���� JDBC ����
	            se.printStackTrace();
	        }catch(Exception e){
	            // ���� Class.forName ����
	            e.printStackTrace();
	        }finally{
	            // �ر���Դ
	            try{
	                if(stat!=null) stat.close();
	            }catch(SQLException se2){
	            }// ʲô������
	            try{
	                if(conn!=null) conn.close();
	            }catch(SQLException se){
	                se.printStackTrace();
	            }
	        }
	      //  System.out.println("Goodbye!");
	        return v;


	    }
    
        public static Vector AfterSearch(String table_name,String keywords)
        {
        	

        	
            Connection conn = null;
            Statement stat = null;
        	Vector v = new Vector(); 

	        try{
	            // ע�� JDBC ����
	            Class.forName(JDBC_DRIVER);
	            // ������
	            System.out.println("�������ݿ�...");
	            conn = DriverManager.getConnection(DB_URL,USER,PASS);
	        
	            // ִ�в�ѯ
	            System.out.println(" ʵ����Statement����...");
	            conn = DriverManager.getConnection(DB_URL,USER,PASS);
	            stat = conn.createStatement();
	         //   Object[][] tableDate=new Object[10][2];
	            int i =0;
	      //      select * from test where ch_name like '%��%' or en_name like '%��%';
	            
	            
	            
	            ResultSet result = stat.executeQuery(String.format("select * from %s where ch_name like '%%%s%%'",table_name,keywords ));
	            while (result.next())
	            {
	     //       	id int,price int, number int,ch_name varchar(80),en_name varchar(80),unit varchar(20))
	            	v.add(result.getInt("id"));
	              	v.add(result.getString("ch_name"));
	             //   i = i+1;
	            }
	
	 
	            result.close();
	            stat.close();
	            conn.close();
	
	        }catch(SQLException se){
	            // ���� JDBC ����
	            se.printStackTrace();
	        }catch(Exception e){
	            // ���� Class.forName ����
	            e.printStackTrace();
	        }finally{
	            // �ر���Դ
	            try{
	                if(stat!=null) stat.close();
	            }catch(SQLException se2){
	            }// ʲô������
	            try{
	                if(conn!=null) conn.close();
	            }catch(SQLException se){
	                se.printStackTrace();
	            }
	        }
	      //  System.out.println("Goodbye!");
	        return v;

	    }
    

       

}