package javaGui;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.io.File;
public class Backup_page extends JFrame {

	private JPanel contentPane;
	Connection connection = null;
	String tableC = "customlist";
	String tableO = "orderList";
	String tableI = "InventoryList";
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				
//				writeExcel();
				try {
					Backup_page frame = new Backup_page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
    private static void writeExcel(String[][] input,String header[], String fname) {
    	
	try {
	        File xlsFile = new File(fname);
	        // ����һ��������
	        WritableWorkbook workbook = Workbook.createWorkbook(xlsFile);
	        // ����һ��������
	        WritableSheet sheet = workbook.createSheet("sheet1", 0);
	        
	      
        	int row =0;
            for (int col = 0; col < header.length; col++) 
            {

                sheet.addCell(new Label(col, row, header[col]));
            }
     	        

	        
	        // ���к�����д����
	        for ( row = 1; row <= input.length; row++) 
	        {
	            for (int col = 0; col < input[0].length; col++) 
	            {
	                sheet.addCell(new Label(col, row, input[row-1][col]));
	            }
	        }
	 
	        //�ر���Դ
	        workbook.write();
	        workbook.close();
 
		} 
    	catch (Exception e2) 
    	{
			e2.printStackTrace();
		}
	
	}

	/**
	 * Create the frame.
	 */
	public Backup_page() {
		connection = sqlcon.db();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 604, 483);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("nuser");
		lblNewLabel.setBounds(70, 58, 54, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblUser = new JLabel("user");
		lblUser.setBounds(70, 83, 54, 15);
		contentPane.add(lblUser);
		
		JLabel lblNewLabel_1 = new JLabel("Login Users");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(122, 71, 89, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblCatelist = new JLabel("catelist");
		lblCatelist.setBounds(70, 117, 68, 15);
		contentPane.add(lblCatelist);
		
		JLabel lblTemporder = new JLabel("temporder");
		lblTemporder.setBounds(70, 148, 68, 15);
		contentPane.add(lblTemporder);
		
		JLabel lblCustomlist = new JLabel("CustomList");
		lblCustomlist.setFont(new Font("Arial", Font.PLAIN, 16));
		lblCustomlist.setBounds(70, 192, 82, 15);
		contentPane.add(lblCustomlist);
		
		JLabel lblInventorylist = new JLabel("InventoryList");
		lblInventorylist.setFont(new Font("Arial", Font.PLAIN, 16));
		lblInventorylist.setBounds(69, 284, 108, 15);
		contentPane.add(lblInventorylist);
		
		JLabel lblOrderlist = new JLabel("OrderList");
		lblOrderlist.setFont(new Font("Arial", Font.PLAIN, 16));
		lblOrderlist.setBounds(371, 186, 89, 27);
		contentPane.add(lblOrderlist);
		
		JButton btnNewButton = new JButton("|>");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String [] header = {"inv_id","en_name" ,"category","ch_name","pricetime","taxable","Units","price"};
				try {
					String sql2= "select  * from " +tableI;

						PreparedStatement pst= connection.prepareStatement(sql2);
//						System.out.println(sql2);
						ArrayList<String[]> arr = new ArrayList<>();
						ResultSet rs = pst.executeQuery();
						int index = 0;
						while(rs.next())
						{
							String tt[] = new String[header.length]; 

							for(int i =0;i<header.length;i++)
							{
								tt[i] = rs.getString(header[i]);

							}
							index++;
							
							System.out.println("");
							 arr.add(tt);
							 
						}
						String inventory [][] = (String[][])arr.toArray(new String[0][]);
						String fname = "./img/BK_inventory.xls";
						writeExcel( inventory, header, fname); 
						JOptionPane.showMessageDialog(null, fname +" Save done");
						System.out.print(fname +" Save done" );
						pst.close();				
						rs.close();				
					} catch (Exception e2) {
						e2.printStackTrace();
					}
																		
				
				
			}
		});
		btnNewButton.setBounds(84, 309, 54, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("|>");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String [] header = {"id","name" ,"phone","addr","city","State","zip","tax","note"};
				try {
					String sql2= "select  * from " +tableC;

						PreparedStatement pst= connection.prepareStatement(sql2);
//						System.out.println(sql2);
						ArrayList<String[]> arr = new ArrayList<>();
						ResultSet rs = pst.executeQuery();
						int index = 0;
						while(rs.next())
						{
							String tt[] = new String[header.length]; 							
							for(int i =0;i<header.length;i++)
							{
								tt[i] = rs.getString(header[i]);

							}
							index++;
							
							System.out.println("");
							 arr.add(tt);
							 
						}
						String custom [][] = (String[][])arr.toArray(new String[0][]);
						String fname = "./img/BK_custom.xls";
						writeExcel( custom, header, fname); 
						JOptionPane.showMessageDialog(null, fname +" Save done");
						System.out.print(fname +" Save done" );
						pst.close();				
						rs.close();				
					} catch (Exception e2) {
						e2.printStackTrace();
					}
														
				
				
			}
		});
		btnNewButton_1.setBounds(84, 227, 54, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("|>");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String [] header = {"invoice_number","cid" ,"name","price","orderdate"};
				try {
//					String sql2= "select  * from " +tableO;
					String sql2= "select DISTINCT tb1.id as invoice_number,tb1.cid, tb2.name, tb1.price, tb1.orderdate "
							+ "from "+tableO+" as tb1 "
							+ "left join "+tableC+" as tb2 "
							+ "on tb2.id = tb1.cid";
						PreparedStatement pst= connection.prepareStatement(sql2);
//						System.out.println(sql2);
						ArrayList<String[]> arr = new ArrayList<>();
						ResultSet rs = pst.executeQuery();
						int index = 0;
						while(rs.next())
						{
							String tt[] = new String[header.length]; 

							for(int i =0;i<header.length;i++)
							{
								tt[i] = rs.getString(header[i]);

							}
							index++;
							
							System.out.println("");
							 arr.add(tt);
							 
						}
						String order [][] = (String[][])arr.toArray(new String[0][]);
						String fname = "./img/BK_orderList.xls";
						writeExcel( order, header, fname); 
						JOptionPane.showMessageDialog(null, fname +" Save done");
						System.out.print(fname +" Save done" );
						pst.close();				
						rs.close();				
					} catch (Exception e2) {
						e2.printStackTrace();
					}
												
				
			}
		});
		btnNewButton_1_1.setBounds(381, 223, 54, 23);
		contentPane.add(btnNewButton_1_1);
	}

}
