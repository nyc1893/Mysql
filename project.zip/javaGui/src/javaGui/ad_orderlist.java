package javaGui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class ad_orderlist extends JFrame {

	private JPanel contentPane;
	private JTable table;
	Connection connection = null;
	private JTable table_1;
	String EID = "";
	String GID = "";
	String FID = "";
	String temp2 = "";
	String temp3[] = new String [10];
	private JTextField textFieldid;
	private JTextField textFieldqty;
	private JTextField textFieldunit;
	private JTextField textFieldprice;
	private JTextField textFieldtaxrate;
	private JLabel lblChineseName;
	private JLabel lblEnglishName;
	private JTextField textFieldch;
	private JTextField textFielden;
	private JLabel lblInvoiceId;
	private JTextField textFieldfapiao;
	private JTable table_2;
	private JTextField textFieldsearchinv;
	private JButton btnSearchen;
	private JButton btnNewButton_2;
	private JTextField textFieldt1;
	private JTextField textFieldt2;
	private JTextField textFieldname;
	private JLabel lblFrom;
	private JLabel lblPrice_2;
	private JButton btnSearchtime;
	private JButton btnSearchname;
	private JButton btnSearchboth;
	private JTextField textFieldpname;
	private JTextField textFieldremark;
	private JButton btnLoad;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ad_orderlist frame = new ad_orderlist();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	public void refreshTable3() {
		try {
			
			String query= "select tb1.inv_id, tb2.chcate as CATEGORY, "
					+"tb1.en_name ,tb1.ch_name ,tb1.itemunit,tb1.itemprice "
					+"from InventoryList as tb1 "
					+ "left join catelist as tb2 on tb1.CATEGORY = tb2.cateid";	
//			System.out.println(query); 
//			String query="select * from InventoryList";
				PreparedStatement pst= connection.prepareStatement(query);
				ResultSet rs = pst.executeQuery();
				table_2.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}
	public void refreshTable() {
		try {
//			Why add one day here
			String sql2= "select  id as invoicenumber, "
//					+ " date_add(orderdate,interval 1 day) as date, "
					+ " orderdate as date, "
					+ " name, "

					+ " total "
					+ " from InvoiceList";
//					+ "left join InventoryList as tb1 on tb1.inv_id = tb2.id";
			
				PreparedStatement pst= connection.prepareStatement(sql2);
				ResultSet rs = pst.executeQuery();
				System.out.println(sql2);
				table_1.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}	
	
	
	public void refreshTable2() {
		try {
			
			String sql2= "select  * "
					+ "from revorderlist";
//					+ "left join InventoryList as tb1 on tb1.inv_id = tb2.id";
			
				PreparedStatement pst= connection.prepareStatement(sql2);
				ResultSet rs = pst.executeQuery();
				table.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}
	
	public void refreshTable22() {
		try {
			
			String sql2= "select  * "
					+ "from revorderlist "
					+ "where id = "+ EID;

			
				PreparedStatement pst= connection.prepareStatement(sql2);
				ResultSet rs = pst.executeQuery();
				table.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}	
	
	/**
	 * Create the frame.
	 */
	public ad_orderlist() {
		connection = sqlcon.db();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1285, 768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("load");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				refreshTable2();
			}
		});
		btnNewButton.setBounds(1039, 310, 93, 23);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(485, 99, 760, 201);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
  				try {
//					System.out.println("Hi");
							int row = table.getSelectedRow();
							
							 EID = (table.getModel().getValueAt(row,0)).toString();
							 GID = (table.getModel().getValueAt(row,1)).toString();
//							System.out.println(GID);
							String query= "select * from revorderList "
									+ " where id = "+EID +" and innerid = "+ GID;
							PreparedStatement pst= connection.prepareStatement(query);

							ResultSet rs = pst.executeQuery();
							while(rs.next())
							{

//								temp=rs.getString("id").toString().toCharArray();
								textFieldid.setText(rs.getString("innerid"));
								textFieldfapiao.setText(rs.getString("id"));

		
		 						textFieldch.setText(rs.getString("ch"));
		  						textFielden.setText(rs.getString("en")); 
		  						
		 						textFieldunit.setText(rs.getString("unit"));
		  						textFieldqty.setText(rs.getString("qty"));  	
		  						textFieldprice.setText(rs.getString("price"));
		  						textFieldtaxrate.setText(rs.getString("taxrate")); 	 						
					
							}
							pst.close();
//							System.out.println(temp);

						} 
						catch (Exception e2) 
						{
							e2.printStackTrace();				
						}			
						
				
				
			}
		});
		scrollPane.setViewportView(table);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(42, 99, 415, 197);
		contentPane.add(scrollPane_1);
		
		table_1 = new JTable();
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try 
				{
				int row = table_1.getSelectedRow();
			     EID = (table_1.getModel().getValueAt(row,0)).toString();
				System.out.println(EID);
				String sql2= "select  * "
	
						+ "from revorderlist"
						+ " where id = "+ EID;
//						+ "left join InventoryList as tb1 on tb1.inv_id = tb2.id";
				
					PreparedStatement pst= connection.prepareStatement(sql2);
					ResultSet rs = pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(rs));
				pst.close();
				rs.close();				
				}
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}						
		
			}
		});
		scrollPane_1.setViewportView(table_1);
		
		JLabel lblNewLabel = new JLabel("Inner ID");
		lblNewLabel.setBounds(876, 366, 99, 15);
		contentPane.add(lblNewLabel);
		
		textFieldid = new JTextField();
		textFieldid.setBounds(950, 366, 66, 21);
		contentPane.add(textFieldid);
		textFieldid.setColumns(10);
		
		textFieldqty = new JTextField();
		textFieldqty.setColumns(10);
		textFieldqty.setBounds(950, 404, 66, 21);
		contentPane.add(textFieldqty);
		
		textFieldunit = new JTextField();
		textFieldunit.setColumns(10);
		textFieldunit.setBounds(950, 442, 66, 21);
		contentPane.add(textFieldunit);
		
		textFieldprice = new JTextField();
		textFieldprice.setColumns(10);
		textFieldprice.setBounds(752, 366, 66, 21);
		contentPane.add(textFieldprice);
		
		textFieldtaxrate = new JTextField();
		textFieldtaxrate.setColumns(10);
		textFieldtaxrate.setBounds(752, 404, 66, 21);
		contentPane.add(textFieldtaxrate);
		
		JLabel lblQty = new JLabel("Qty");
		lblQty.setBounds(899, 407, 54, 15);
		contentPane.add(lblQty);
		
		JLabel lblUnit = new JLabel("Unit");
		lblUnit.setBounds(905, 445, 35, 15);
		contentPane.add(lblUnit);
		
		JLabel lblPrice = new JLabel("Price");
		lblPrice.setBounds(698, 369, 44, 15);
		contentPane.add(lblPrice);
		
		JLabel lblTaxrate = new JLabel("Taxrate");
		lblTaxrate.setBounds(686, 407, 66, 15);
		contentPane.add(lblTaxrate);
		
		lblChineseName = new JLabel("Chinese Name");
		lblChineseName.setBounds(775, 493, 99, 15);
		contentPane.add(lblChineseName);
		
		lblEnglishName = new JLabel("English Name");
		lblEnglishName.setBounds(775, 535, 99, 15);
		contentPane.add(lblEnglishName);
		
		textFieldch = new JTextField();
		textFieldch.setColumns(10);
		textFieldch.setBounds(873, 490, 272, 21);
		contentPane.add(textFieldch);
		
		textFielden = new JTextField();
		textFielden.setColumns(10);
		textFielden.setBounds(873, 532, 272, 21);
		contentPane.add(textFielden);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {


			//		System.out.println(Integer.parseInt(String.valueOf(temp2))+1);
					
					


						String sql = "select max(innerid) from revorderList " 
								+ "  where id = "+ EID;
						PreparedStatement pst2= connection.prepareStatement(sql);

						ResultSet rs = pst2.executeQuery();
	  					while(rs.next())
	  					{
	  						temp2=rs.getString("max(innerid)");
	  					}
	  					
						pst2.close();
//						temp2
						
										
			
						
				} catch (Exception e2) {
					e2.printStackTrace();
				}						
							
				try {
						if(FID == null || GID == null) 
						{
							JOptionPane.showMessageDialog(null, "Please select one from the table.");
						}
						
						else 
						{
							
						String sql2 = "select * from  InventoryList" 
								+ "  where inv_id = "+ FID;
						PreparedStatement pst2 = connection.prepareStatement(sql2);

						ResultSet rs = pst2.executeQuery();
		
		
							PreparedStatement pst= connection.prepareStatement(sql2);
							 rs = pst.executeQuery();

							while(rs.next())
							{
								temp3[0] = (rs.getString("inv_id"));
								temp3[1] = (rs.getString("en_name"));
								temp3[2] = (rs.getString("ch_name"));
		  						
		  						temp3[3] = (rs.getString("itemunit"));
		  						temp3[4] = (rs.getString("itemprice"));
		  						temp3[5] = (rs.getString("Taxable"));
//		  						temp3[6] = (rs.getString("zip"));					
					
				
							}				
						
							pst2.close();
							rs.close();
						
						
						String query= "insert into revorderList " 
								+"(id,innerid,goodid,qty,unit,price,taxrate,ch,en) "
								+ "values (?,?,?,?,?,?,?,?,?)";
						 pst= connection.prepareStatement(query);
						 int id_num = Integer.parseInt(temp2)+1;		
						pst.setString(1, EID);
						pst.setString(2, Integer.toString(id_num));
						pst.setString(3, temp3[0]);
						pst.setString(4, "1");
						pst.setString(5, temp3[3]);
						pst.setString(6, temp3[4] );
						pst.setString(7, temp3[5] );
						pst.setString(8, temp3[2] );
						pst.setString(9, temp3[1] );
						System.out.println(query);
						pst.execute();
						
						JOptionPane.showMessageDialog(null, "Data Saved");
						
					}
					

					
					
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
				refreshTable22();
				
			}
		});
		btnAdd.setBounds(352, 627, 93, 23);
		contentPane.add(btnAdd);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					

					String query= "update revorderList "

							+" set ch='"+ textFieldch.getText()
							+"' ,en='"+ textFielden.getText()
							+"' ,unit='"+ textFieldunit.getText()
							+"' ,taxrate='"+ textFieldtaxrate.getText()
							+"' ,price='"+ textFieldprice.getText()
							+"' ,qty= "+ textFieldqty.getText()
							+" ,remark ='"+ textFieldremark.getText()
//							+"' ,note='"+ textFieldNote.getText()
							+"' where innerid = "+textFieldid.getText()+""
									+ " and id = "+textFieldfapiao.getText() ;
				
					System.out.println(query);
								
					PreparedStatement pst= connection.prepareStatement(query);
			
					pst.execute();

					JOptionPane.showMessageDialog(null, "Data Updated");
					
					pst.close();
		
					
				} catch (Exception e3) {
					e3.printStackTrace();
				}				
				refreshTable22();
			}
		});
		btnUpdate.setBounds(766, 310, 93, 23);
		contentPane.add(btnUpdate);
		
		JButton btnRemove = new JButton("Remove");
		btnRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String sql2= "DELETE from revorderList where id = "+ EID +" and innerid = " +GID;
					PreparedStatement pst= connection.prepareStatement(sql2);
					 pst= connection.prepareStatement(sql2);
					System.out.println(sql2);
					pst.execute();
					pst.close();
	
				} 
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}					
  				refreshTable22();	
					
				
				
			}
		});
		btnRemove.setBounds(649, 310, 93, 23);
		contentPane.add(btnRemove);
		
		lblInvoiceId = new JLabel("Invoice ID");
		lblInvoiceId.setBounds(683, 445, 99, 15);
		contentPane.add(lblInvoiceId);
		
		textFieldfapiao = new JTextField();
		textFieldfapiao.setColumns(10);
		textFieldfapiao.setBounds(762, 442, 97, 21);
		contentPane.add(textFieldfapiao);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(42, 406, 609, 211);
		contentPane.add(scrollPane_2);
		
		table_2 = new JTable();
		table_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table_2.getSelectedRow();
			     FID = (table_2.getModel().getValueAt(row,0)).toString();
				System.out.println(FID);
				
			}
		});
		scrollPane_2.setViewportView(table_2);
		
		JButton btnRefresh = new JButton("Refresh");
		btnRefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				refreshTable3();
				
			}
		});
		btnRefresh.setBounds(455, 627, 93, 23);
		contentPane.add(btnRefresh);
		
		textFieldsearchinv = new JTextField();
		textFieldsearchinv.setColumns(10);
		textFieldsearchinv.setBounds(59, 349, 237, 21);
		contentPane.add(textFieldsearchinv);
		
		btnSearchen = new JButton("searchEN");
		btnSearchen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {

					String string1 = (textFieldsearchinv.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldsearchinv.getText() + "%'");
					
					String query =
							"select tb1.inv_id," + 
							" tb1.en_name , tb1.ch_name, tb1.itemunit,tb1.itemprice " + 
							" from InventoryList as tb1 " 
							+ " WHERE en_name LIKE "
							+ string1;
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_2.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
				
				
			}
		});
		btnSearchen.setBounds(326, 332, 93, 23);
		contentPane.add(btnSearchen);
		
		btnNewButton_2 = new JButton("searchCH");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textFieldsearchinv.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldsearchinv.getText() + "%'");
					
					String query =
							"select tb1.inv_id," + 
							" tb1.en_name , tb1.ch_name, tb1.itemunit,tb1.itemprice " + 
							" from InventoryList as tb1 " 
							+ " WHERE ch_name LIKE "
							+ string1;
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_2.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}								
				
				
				
			}
		});
		btnNewButton_2.setBounds(326, 365, 93, 23);
		contentPane.add(btnNewButton_2);
		
		textFieldt1 = new JTextField();
		textFieldt1.setColumns(10);
		textFieldt1.setBounds(110, 39, 93, 21);
		contentPane.add(textFieldt1);
		
		textFieldt2 = new JTextField();
		textFieldt2.setColumns(10);
		textFieldt2.setBounds(239, 39, 93, 21);
		contentPane.add(textFieldt2);
		
		textFieldname = new JTextField();
		textFieldname.setColumns(10);
		textFieldname.setBounds(402, 39, 120, 21);
		contentPane.add(textFieldname);
		
		lblFrom = new JLabel("From");
		lblFrom.setBounds(56, 42, 44, 15);
		contentPane.add(lblFrom);
		
		lblPrice_2 = new JLabel("to");
		lblPrice_2.setBounds(212, 42, 44, 15);
		contentPane.add(lblPrice_2);
		
		btnSearchtime = new JButton("searchTime");
		btnSearchtime.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textFieldt1.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt1.getText() + "'");

					String string2 = (textFieldt2.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt2.getText() + "'");					
					
					
					String query = " select id as invoiceID, orderdate, name, total " + 
							"from InvoiceList  where orderdate >" + string1+ " "
									+ "and orderdate <" + string2;

					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_1.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
				
				
			}
		});
		btnSearchtime.setBounds(59, 66, 112, 23);
		contentPane.add(btnSearchtime);
		
		btnSearchname = new JButton("searchBuyer");
		btnSearchname.setVerticalAlignment(SwingConstants.BOTTOM);
		btnSearchname.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textFieldname.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldname.getText() + "%'");
					
//					String query = "select DISTINCT tb3.id as Invoice_number, tb3.orderdate,  tb4.name, tb3.sum \r\n" + 
//							"from (select DISTINCT tb1.id, tb2.orderdate,  tb2.cid, tb1.sum \r\n" + 
//							"from (select id, sum(qty*price) as sum \r\n" + 
//							"from revorderList group by id) as tb1\r\n" + 
//							"left join InvoiceList as tb2\r\n" + 
//							"on tb2.id = tb1.id\r\n" + 
//							")as tb3\r\n" + 
//							"inner join(select * from CustomList where name like " +string1+")  as tb4\r\n" + 
//							"on tb3.cid = tb4.id";

					String query = "select id as invoiceID, orderdate, name, total "+
					"from InvoiceList  where name like " +string1;
					
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_1.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}									
				
				
			}
		});
		btnSearchname.setBounds(402, 66, 126, 23);
		contentPane.add(btnSearchname);
		
		btnSearchboth = new JButton("Time + Buyer");
		btnSearchboth.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {

					String string1 = (textFieldt1.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt1.getText() + "'");

					String string2 = (textFieldt2.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt2.getText() + "'");	
					
					String string3 = (textFieldname.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldname.getText() + "%'");							
					
					String query = "select id as invoiceID, orderdate, name, total\r\n" + 
							"from InvoiceList   where orderdate >"+string1+" and orderdate < "+string2+" " + 
							"and name like "+string3;

					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_1.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
								
				
				
			}
		});
		btnSearchboth.setBounds(249, 66, 126, 23);
		contentPane.add(btnSearchboth);
		
		textFieldpname = new JTextField();
		textFieldpname.setColumns(10);
		textFieldpname.setBounds(567, 39, 120, 21);
		contentPane.add(textFieldpname);
		
		JButton btnDoIt = new JButton("EN");
		btnDoIt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {

					String string1 = (textFieldt1.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt1.getText() + "'");

					String string2 = (textFieldt2.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt2.getText() + "'");	
					
					String string3 = (textFieldpname.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldpname.getText() + "%'");							
					
//					String query = "select id as invoiceID, orderdate, name, total\r\n" + 
//							"from InvoiceList   where orderdate >"+string1+" and orderdate < "+string2+" " + 
//							"and name like "+string3;

					
					String query = "select  tb1.id,  tb1.orderdate, tb1.total,tb1.name \r\n" + 
					"from (select * from InvoiceList  where orderdate >"+string1 +" and "
							+ "orderdate < "+string2 + ")as tb1 \r\n" + 
					"inner join (select * from revorderList where en like "+string3 +") as tb2 \r\n" + 
					"on tb2.id = tb1.id";
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_1.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}							
				
				
			}
		});
		btnDoIt.setBounds(567, 66, 54, 23);
		contentPane.add(btnDoIt);
		
		JLabel lblTimeProductname = new JLabel("Time + ProductName");
		lblTimeProductname.setBounds(576, 14, 206, 15);
		contentPane.add(lblTimeProductname);
		
		JButton btnCn = new JButton("CN");
		btnCn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textFieldt1.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt1.getText() + "'");

					String string2 = (textFieldt2.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt2.getText() + "'");	
					
					String string3 = (textFieldpname.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldpname.getText() + "%'");							
					
//					String query = "select id as invoiceID, orderdate, name, total\r\n" + 
//							"from InvoiceList   where orderdate >"+string1+" and orderdate < "+string2+" " + 
//							"and name like "+string3;

					
					String query = "select  tb1.id,  tb1.orderdate, tb1.total,tb1.name \r\n" + 
					"from (select * from InvoiceList  where orderdate >"+string1 +" and "
							+ "orderdate < "+string2 + ")as tb1 \r\n" + 
					"inner join (select * from revorderList where ch like "+string3 +") as tb2 \r\n" + 
					"on tb2.id = tb1.id";
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_1.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}							
								
				
				
				
			}
		});
		btnCn.setBounds(631, 66, 56, 23);
		contentPane.add(btnCn);
		
		textFieldremark = new JTextField();
		textFieldremark.setColumns(10);
		textFieldremark.setBounds(829, 585, 399, 63);
		contentPane.add(textFieldremark);
		
		JLabel lblRemark = new JLabel("Remark");
		lblRemark.setBounds(752, 585, 54, 15);
		contentPane.add(lblRemark);
		
		btnLoad = new JButton("Load");
		btnLoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				refreshTable();
			}
		});
		btnLoad.setBounds(42, 298, 93, 23);
		contentPane.add(btnLoad);
		refreshTable2();
		refreshTable();
		refreshTable3();
	}
}
