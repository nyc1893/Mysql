package javaGui;
import java.sql.*;
import javax.swing.*;

public class sqlcon {
 

    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
//    as host side:
    static final String DB_URL = "jdbc:mysql://localhost:3306/RUNOOB?characterEcoding=utf-8&useSSL=false&serverTimezone=America/Los_Angeles";
// as remote side:
//    static final String DB_URL = "jdbc:mysql://192.168.0.139:3306/RUNOOB?characterEcoding=utf-8&useSSL=false&serverTimezone=America/Los_Angeles";
    
    // ���ݿ���û��������룬��Ҫ�����Լ�������
    static final String USER = "root";
    static final String PASS = "123";
//
//  static final String USER = "usename";
//  static final String PASS = "password";   
    

        Connection conn = null;
        Statement stat = null;

        public static Connection db()
        {

            Connection conn = null;

	        try{
	            // ע�� JDBC ����
	            Class.forName(JDBC_DRIVER);
	            // ������
	            System.out.println("connecting to database...");
	            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            	//JOptionPane.showMessageDialog(null, "Connection Success");
        		return conn;
	        }
    		catch(Exception e)
    		{
            	JOptionPane.showMessageDialog(null, "Connection Error");
        		return null;
	        }
    
        }

       

}