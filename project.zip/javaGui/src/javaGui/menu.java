package javaGui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;

public class menu extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					menu frame = new menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public menu() {
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 585, 575);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("EDIT Customer");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				 ad_custom  abc= new ad_custom();
				 abc.setVisible(true);
				
			}

		});
		btnNewButton.setBounds(30, 54, 121, 37);
		contentPane.add(btnNewButton);
		
		JButton btnEditProduction = new JButton("EDIT Production");
		btnEditProduction.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 admin_page  abc= new admin_page();
				 abc.setVisible(true);
				
			}
		});
		btnEditProduction.setBounds(185, 54, 140, 37);
		contentPane.add(btnEditProduction);
		
		JButton btnOrdering = new JButton("ORDERING");
		btnOrdering.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 custom_page  abc= new custom_page();
				 abc.setVisible(true);
	
			}
		});
		btnOrdering.setBounds(392, 242, 113, 37);
		contentPane.add(btnOrdering);
		
		JLabel lblNewLabel = new JLabel("\u7F16\u8F91\u5BA2\u6237\u660E\u7EC6");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 16));
		lblNewLabel.setBounds(30, 22, 113, 31);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u7F16\u8F91\u8D27\u54C1\u660E\u7EC6");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(205, 22, 134, 31);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("\u8D27\u54C1\u51FA\u5E93 (\u4E0B\u5355)");
		lblNewLabel_1_1.setFont(new Font("����", Font.PLAIN, 16));
		lblNewLabel_1_1.setBounds(391, 211, 134, 31);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("\u6253\u5370");
		lblNewLabel_1_1_1.setFont(new Font("����", Font.PLAIN, 16));
		lblNewLabel_1_1_1.setBounds(424, 112, 101, 31);
		contentPane.add(lblNewLabel_1_1_1);
		
		JButton btnStatement = new JButton("Print");
		btnStatement.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 pt_stat  abc= new pt_stat();
				 abc.setVisible(true);	
				
			}
		});
		btnStatement.setBounds(374, 141, 140, 37);
		contentPane.add(btnStatement);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("\u8D27\u54C1\u5165\u5E93");
		lblNewLabel_1_1_1_1.setFont(new Font("����", Font.PLAIN, 16));
		lblNewLabel_1_1_1_1.setBounds(408, 307, 71, 31);
		contentPane.add(lblNewLabel_1_1_1_1);
		
		JButton btnInput = new JButton("GOODS INPUT");
		btnInput.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 fromseller  abc= new fromseller();
				 abc.setVisible(true);					
				
			}
		});
		btnInput.setBounds(392, 339, 113, 37);
		contentPane.add(btnInput);
		
		JLabel lblNewLabel_1_1_1_2 = new JLabel("\u7F16\u8F91\u53D1\u7968\u57FA\u672C\u4FE1\u606F");
		lblNewLabel_1_1_1_2.setFont(new Font("����", Font.PLAIN, 16));
		lblNewLabel_1_1_1_2.setBounds(30, 112, 131, 31);
		contentPane.add(lblNewLabel_1_1_1_2);
		
		JButton btnStatics = new JButton("Edit Invoice");
		btnStatics.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ad_inoicelist abc= new ad_inoicelist();
				 abc.setVisible(true);				
				
			}
		});
		btnStatics.setBounds(30, 141, 121, 37);
		contentPane.add(btnStatics);
		
		JButton btnNewButton_1 = new JButton("Backup");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				
			}
		});
		btnNewButton_1.setBounds(30, 435, 93, 23);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("\u6570\u636E\u5E93\u5907\u4EFD");
		lblNewLabel_1_1_2.setFont(new Font("����", Font.PLAIN, 16));
		lblNewLabel_1_1_2.setBounds(23, 394, 100, 31);
		contentPane.add(lblNewLabel_1_1_2);
		
		JLabel lblNewLabel_1_2 = new JLabel("\u7F16\u8F91\u5356\u5BB6\u660E\u7EC6");
		lblNewLabel_1_2.setFont(new Font("����", Font.PLAIN, 16));
		lblNewLabel_1_2.setBounds(391, 22, 134, 31);
		contentPane.add(lblNewLabel_1_2);
		
		JButton btnEditSeller = new JButton("EDIT Seller");
		btnEditSeller.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ad_seller  abc= new ad_seller();
				 abc.setVisible(true);					
			}
			
		});
		btnEditSeller.setBounds(374, 54, 140, 37);
		contentPane.add(btnEditSeller);
		
		JButton btnEditOrderlist = new JButton("EDIT OrderList");
		btnEditOrderlist.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ad_orderlist  abc= new ad_orderlist();
				 abc.setVisible(true);				
								
				
			}
		});
		btnEditOrderlist.setBounds(204, 141, 121, 37);
		contentPane.add(btnEditOrderlist);
		
		JLabel lblNewLabel_2 = new JLabel("\u7F16\u8F91\u53D1\u7968\u8BE6\u60C5");
		lblNewLabel_2.setFont(new Font("����", Font.PLAIN, 16));
		lblNewLabel_2.setBounds(212, 112, 113, 31);
		contentPane.add(lblNewLabel_2);
		
		JButton btnRecentSelling = new JButton("Selling Record");
		btnRecentSelling.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seeDetail  abc= new seeDetail();
				 abc.setVisible(true);				
				
			}
		});
		btnRecentSelling.setBounds(30, 285, 121, 37);
		contentPane.add(btnRecentSelling);
		
		JLabel lblNewLabel_3 = new JLabel("\u552E\u5356\u8BB0\u5F55");
		lblNewLabel_3.setFont(new Font("����", Font.PLAIN, 16));
		lblNewLabel_3.setBounds(47, 244, 113, 31);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_1_1_1_1_1_1 = new JLabel("\u5E93\u5B58\u7BA1\u7406");
		lblNewLabel_1_1_1_1_1_1.setFont(new Font("����", Font.PLAIN, 16));
		lblNewLabel_1_1_1_1_1_1.setBounds(416, 410, 109, 31);
		contentPane.add(lblNewLabel_1_1_1_1_1_1);
		
		JButton btnGenerateBase = new JButton("Stock Management");
		btnGenerateBase.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ad_store  abc= new ad_store();
				 abc.setVisible(true);						
				
			}
		});
		btnGenerateBase.setBounds(374, 448, 151, 37);
		contentPane.add(btnGenerateBase);
	}
}
