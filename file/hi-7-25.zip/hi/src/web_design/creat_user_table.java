package web_design;

import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.sql.*;
 
public class creat_user_table {
 

    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
    static final String DB_URL = "jdbc:mysql://localhost:3306/RUNOOB?characterEcoding=utf-8&useSSL=false&serverTimezone=America/Los_Angeles";
 
    // ���ݿ���û��������룬��Ҫ�����Լ�������
    static final String USER = "root";
    static final String PASS = "123";

    
    
    public static void main(String[] args) 
    {
        Connection conn = null;
        Statement stat = null;
        
        
        try{
            // ע�� JDBC ����
            Class.forName(JDBC_DRIVER);
        
            // ������
            System.out.println("�������ݿ�...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
        
            // ִ�в�ѯ
            System.out.println(" ʵ����Statement����...");

            //String sql;
            
            stat = conn.createStatement();	
            //�������ݿ�hello
            String tablename = "";
            
            /*  SellerList Part 
             * 


				id int, (invoice ID)
				orderdate date,
				ponumber varchar(20),
				term int,
				total decimal(13,2��,
				
				cid int, 
				name varchar(80), 
				phone varchar(20),
				addr varchar(80),  
				city varchar(20),
				 state varchar(20), 
				zip varchar(20) , 	
				taxrate varchar(10��

             * 
             * */
            
            
//          tablename = "SellerList";
////         stat.executeUpdate("DROP TABLE " + tablename);
//          String cc = 
//          		
//          		"create table IF NOT EXISTS "+tablename +
//      			"				(id int, \r\n" + 
//      			"				orderdate date,\r\n" + 
//      			"				ponumber varchar(20),\r\n" + 
//      			"				term int,\r\n" + 
//      			"				total decimal(13,2),\r\n" + 
//      			"				\r\n" + 
//      			"				cid int, \r\n" + 
//      			"				name varchar(80), \r\n" + 
//      			"				phone varchar(20),\r\n" + 
//      			"				addr varchar(80),  \r\n" + 
//      			"				city varchar(20),\r\n" + 
//      			"				 state varchar(20), \r\n" + 
//      			"				zip varchar(20) , 	\r\n" + 
//      			"				taxrate varchar(10)"
//             		+ ")" ;       
//          	System.out.println(cc);
//         		stat.executeUpdate(cc);
//            
            
            
            /*  Account Part 

                cid int not null
				inv_id int not null, 
				smallu varchar(20) not null,
				bigu varchar(20) not null,
				smallp decimal(12,2),
				bigp decimal(14,2),
             */
  
//          tablename = "Aclist1";
//        stat.executeUpdate("DROP TABLE " + tablename);
//         String cc = 
//         		
//         		"create table IF NOT EXISTS "+tablename
//            		+ " ("+
////            		+ "id int not null, " + 
//            		"cid int not null, " + 
//            		"inv_id int not null, " + 
//            		"Taxable boolean, " + 
//        			"smallu varchar(20) not null,"+
//        			"bigu varchar(20) not null,"+
//        			"smallp decimal(12,2),"+
//        			"bigp decimal(14,2)"+
//            		");" ;                 
//         	System.out.println(cc);
//         	stat.executeUpdate(cc);
            
            
            /*  InvoiceList Part 
             * 


				id int, (invoice ID)
				orderdate date,
				ponumber varchar(20),
				term int,
				total decimal(13,2��,
				
				cid int, 
				name varchar(80), 
				phone varchar(20),
				addr varchar(80),  
				city varchar(20),
				 state varchar(20), 
				zip varchar(20) , 	
				taxrate varchar(10��

             * 
             * */
            
//            tablename = "InvoiceList";
////           stat.executeUpdate("DROP TABLE " + tablename);
//            String cc = 
//            		
//            		"create table IF NOT EXISTS "+tablename
//               		+ " ("
//               		+ "id int, " + 
//               		"orderdate date," + 
//               		"ponumber varchar(20)," + 
//               		"term int," + 
//               		"total decimal(13,2)," + 
//
//               		"cid int," + 
//               		"name varchar(80), " + 
//               		"phone varchar(20)," + 
//               		"addr varchar(80), " + 
//               		"city varchar(20)," + 
//               		" state varchar(20)," + 
//               		"zip varchar(20), " + 
//               		"taxrate varchar(10)"
//               		+ ")" ;       
//            	System.out.println(cc);
//           		stat.executeUpdate(cc);
//           		
           		
//            stat.executeUpdate("insert into "+tablename
//            		+ " values(1,1809, '2019-5-12')");
//            stat.executeUpdate("insert into "+tablename
//            		+ " values(2,1811, '2020-12-12')");      
//            stat.executeUpdate("insert into "+tablename
//            		+ " values(3,1811, '2020-1-12')");                 
//            stat.executeUpdate("insert into "+tablename
//            		+ " values(4,1811, '2017-12-12')");      
//            stat.executeUpdate("insert into "+tablename
//            		+ " values(5,1811, '2018-12-12')");                             
//            
            
            /*  BuyList Part    4variables
            id int��
			invid int��(Inv_id ID)
			sid int, (seller list id)
			transdate date,
			
			largenum decimal(12,2)) 



             * */           
            
//            tablename = "BuyList";
////          stat.executeUpdate("DROP TABLE " + tablename);
//          
//          		
//          String	cc = 	"create table IF NOT EXISTS "+tablename
//             		+ " (id int not null," + 
//             		" invid int, " + 
//             		" sid int, " + 
//             		" transdate date, " + 
//             		"largenum decimal(12,2), "
//             		+ " cost decimal(14,2)) ";
//
//
//             		
//          	System.out.println(cc);
//               
//          	   stat.executeUpdate("insert into "+tablename
//                 		+ " values(1,9412,1,'2015-7-1', 10,3.23)");            
//      
            
            
            
                /*  storelist Part    3variables

    			id int not null  
				smallnum decimal(20,2)) 
				largenum decimal(12,2)) 


                 * */           
            
//              tablename = "storelist";
////               stat.executeUpdate("DROP TABLE " + tablename);
//              
//               		
//              String	cc = 	"create table IF NOT EXISTS "+tablename
//                   		+ " (id int not null," + 
//                   		"smallnum decimal(20,2), " + 
//                   		"largenum decimal(12,2) " + 	
//             			")"; 
//                   		
//                	System.out.println(cc);
//                	stat.executeUpdate(cc);                
//                	   stat.executeUpdate("insert into "+tablename
//                       		+ " values(9412,0, 0)");            
//            
            
            /*  saledetail Part     variables

			inner_id ,
			inv_id int, (goods ID)
			qty decimal(14,4),

			unit varchar(20),
			price decimal(12,2��
			
			total decimal(14,2��
			Ch varchar(80),
			En varchar(120),
			remark varchar(120)
			taxrate decimal(10,4),
			
			csflag boolean,


             * */
            /*
            stat.executeUpdate("DROP TABLE saledetail");
            String	cc = 	"create table IF NOT EXISTS saledetail "
               		+ " (id int," + 
             		"innerid int," + 
               		"goodid int, " + 
//
               		"qty decimal(14,4)," + 
               		"unit varchar(20)," + 
               		"price decimal(12,2)," + 
               		"taxrate decimal(14,2),"+
               	    "total decimal(14,2),"+
               		"ch varchar(80)," + 
               		"en varchar(120)," + 
               		"csf boolean," + 
               		"remark varchar(120))"; 
//               		
            	System.out.println(cc);
            	stat.executeUpdate(cc);                
            */

    
            /*  revorderList Part    9 variables

			id int, (invoice ID)
			innerid int, 
			goodid int, (product ID)            
			qty decimal(14,4),
			unit varchar(20),
			price decimal(12,2��
			tax decimal(12,2��
			ch_name varchar(80),
			en_name varchar(80),

             * */
          
/*
        		
            String	cc = 	"create table IF NOT EXISTS revorderList "
               		+ " (id int," + 
             		"innerid int," + 
               		"goodid int, " + 
//
               		"qty decimal(14,4)," + 
               		"unit varchar(20)," + 
               		"price decimal(12,2)," + 
               		"taxrate varchar(10)," + 
               		"ch varchar(80)," + 
               		"en varchar(200)," + 
               		"remark varchar(120))"; 
//               		
            	System.out.println(cc);
            	stat.executeUpdate(cc);        
*/    

            
            /*  LoginUser Part */
         
            tablename = "user";   
            stat.executeUpdate("DROP TABLE " + tablename);
            stat.executeUpdate("create table IF NOT EXISTS "+tablename
            		+ " (id int,name varchar(80),pass varchar(80),power varchar(10))");
            stat.executeUpdate(AddET3(tablename,1,"lily","yee6312","S"));
            stat.executeUpdate(AddET3(tablename,2,"yy","yy331","S"));
            
            stat.executeUpdate(AddET3(tablename,3,"jack","yee6312","S"));
            stat.executeUpdate(AddET3(tablename,4,"james","jc1202","S"));
            
            
            tablename = "spuser";   
           stat.executeUpdate("DROP TABLE " + tablename);
           stat.executeUpdate("create table IF NOT EXISTS "+tablename
           		+ " (id int,name varchar(80),pass varchar(80),power varchar(10))");     
            
            stat.executeUpdate(AddET3(tablename,8,"sup1","s1","N"));
            stat.executeUpdate(AddET3(tablename,9,"sup2","s2","N"));
            stat.executeUpdate(AddET3(tablename,5,"sup3","s3","N"));
            stat.executeUpdate(AddET3(tablename,6,"sup4","s4","N"));
            stat.executeUpdate(AddET3(tablename,7,"sup5","s5","N"));
            
            stat.executeUpdate(AddET3(tablename,10,"rainie","rr","N"));
            
            tablename = "nuser";   
           stat.executeUpdate("DROP TABLE " + tablename);
           stat.executeUpdate("create table IF NOT EXISTS "+tablename
           		+ " (id int,name varchar(80),pass varchar(80),power varchar(10))");     
            
            stat.executeUpdate(AddET3(tablename,3,"guest1","g1","N"));
            stat.executeUpdate(AddET3(tablename,4,"guest2","g2","N"));
            stat.executeUpdate(AddET3(tablename,5,"guest3","g3","N"));
            stat.executeUpdate(AddET3(tablename,6,"guest4","g4","N"));
            stat.executeUpdate(AddET3(tablename,7,"guest5","g5","N"));
         
    
            
   
            
            /*  temporder Part 
             * 
             * Temporder
				inner_id ,
				id int, (goods ID)
				qty decimal(12,2),
				cati int, �¼����
				unit varchar(10),
				price decimal(12,2��
				taxrate varchar(10��
				Ch varchar(80),
				En varchar(120),
				remark varchar(120)
             * */
//            8 variable 
            
            /*
            for (int i =1;i<9;i++) 
            {
            tablename = "temporder" +Integer.toString(i) ;   
            stat.executeUpdate("drop table "+ tablename);
            String sql = "create table IF NOT EXISTS "+tablename
               		+ " ("
               		+ "inner_id int not null," 
               		+ "inv_id int not null, " + 
               		" qty decimal(14,4)," + 
               		" cati varchar(10)," + 
               		" unit varchar(10)," + 
               		" price decimal(12,2)," + 
               		"total decimal(14,2),"+
               		"taxrate varchar(10)," + 

               		" ch varchar(80)," + 
               		" en varchar(120)," + 
               		" csf boolean," + 
               		" remark varchar(120)" + 
               		")";
            System.out.println(sql);
           stat.executeUpdate(sql);
            }
            */
            /*  ��Ʒ����*/
            
//          tablename = "catelist"; 
//          stat.executeUpdate("create table IF NOT EXISTS catelist(cateid int,chcate varchar(80),encate varchar(80))");
//          stat.executeUpdate(AddET3(tablename,100,"�߲�","Vegetable"));
//          stat.executeUpdate(AddET3(tablename,200,"����ʳƷ","FreezingFood"));          
//          stat.executeUpdate(AddET3(tablename,300,"�ɻ�","Dry goods")); 
//          stat.executeUpdate(AddET3(tablename,400,"����","Drink")); 
//          stat.executeUpdate(AddET3(tablename,500,"��ʳ","Snacks")); 
//          stat.executeUpdate(AddET3(tablename,600,"��ζ��","Daily necessities"));
//          stat.executeUpdate(AddET3(tablename,700,"����Ʒ","123"));
//          stat.executeUpdate(AddET3(tablename,800,"����","Other"));
          
          


            stat.close();
            conn.close();
            System.out.println(" copy down.");
   
        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stat!=null) stat.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("Goodbye!");
    }
    
    public static String AddET3(String tablename,int id, String ch1,String ch2,String ch3 )
	{
    	String result = String.format("insert into %s values(%d,\"%s\",\"%s\",\"%s\")", tablename,id,ch1,ch2,ch3);
    	System.out.println(result);
    	return result;

	}

    public static String AddET4(String tablename,int id, String ch1,double f1,double f2  )
	{
    	String result = String.format("insert into %s values(%d,\"%s\",%f,%f)", tablename,id,ch1,f1,f2);
    	System.out.println(result);
    	return result;

	}   
    
    
}