package web_design;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;



import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

public class updatesome extends JFrame {

	private JPanel contentPane;
	private JTextField textField_P;
	private JTextField textField_C;
	private JTextField textField_S;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {

					updatesome window = new updatesome();
					window.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public updatesome() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField_P = new JTextField();
		textField_P.setBounds(85, 72, 188, 20);
		contentPane.add(textField_P);
		textField_P.setColumns(10);
		textField_P.setText("C:\\gen\\p.xls");
		
		textField_C = new JTextField();
		textField_C.setBounds(85, 121, 188, 20);
		contentPane.add(textField_C);
		textField_C.setColumns(10);
		textField_C.setText("C:\\gen\\c.xls");
		
		textField_S = new JTextField();
		textField_S.setBounds(85, 175, 188, 20);
		contentPane.add(textField_S);
		textField_S.setColumns(10);
		textField_S.setText("C:\\gen\\s.xls");
		
		JButton btnNewButton = new JButton("Product");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String tt = textField_P.getText();
				System.out.println(tt);
//				tt = "F:\\store-project\\javaGui\\javaGui\\img\\productlist.xls";
				save_data ss = new save_data();
				if(ss.Read2(tt)==1)
				{
					JOptionPane.showMessageDialog(null, "Product Updated");
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Check the file name or address");
				}					
				
			}
		});
		btnNewButton.setBounds(300, 71, 107, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Customer");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String tt = textField_C.getText();
				System.out.println(tt);
				
//				tt = "F:\\store-project\\javaGui\\javaGui\\img\\custom.xls";
				save_data ss = new save_data();
				if(ss.Read1(tt)==1)
				{
					JOptionPane.showMessageDialog(null, "Customer Updated");
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Check the file name or address");
				}				
			}
		});
		btnNewButton_1.setBounds(300, 120, 107, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Supplier");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String tt = textField_S.getText();
				System.out.println(tt);
//				tt = "F:\\store-project\\javaGui\\javaGui\\img\\supplier.xls";
				save_data ss = new save_data();
				int k = ss.Read3(tt);
				if(k==1)
				{
					JOptionPane.showMessageDialog(null, "Supplier Updated");
				}		
				else
				{
					JOptionPane.showMessageDialog(null, "err "+k);
				}
			}
		});
		btnNewButton_2.setBounds(300, 174, 107, 23);
		contentPane.add(btnNewButton_2);
		
		JLabel lblNewLabel = new JLabel("Update Data");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(40, 11, 197, 37);
		contentPane.add(lblNewLabel);
	}
}
