package web_design;

import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.sql.*;
 
public class update_tax {
 

    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
    static final String DB_URL = "jdbc:mysql://localhost:3306/RUNOOB?characterEcoding=utf-8&useSSL=false&serverTimezone=America/Los_Angeles";
 
    // ���ݿ���û��������룬��Ҫ�����Լ�������
    static final String USER = "root";
    static final String PASS = "123";

    
    
    public static void main(String[] args) 
    {
        Connection conn = null;
        Statement stat = null;
        
        
        try{
            // ע�� JDBC ����
            Class.forName(JDBC_DRIVER);
        
            // ������
            System.out.println("�������ݿ�...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
        
            // ִ�в�ѯ
            System.out.println(" ʵ����Statement����...");

            //String sql;
            
            stat = conn.createStatement();	
            //�������ݿ�hello
            
//            stat.executeUpdate("DROP TABLE buylist");
            //stat.executeUpdate("create table test(id int,ch_name varchar(80);");
            //stat.executeUpdate("create table IF NOT EXISTS test(id int,price decimal(10,2), number int,ch_name varchar(80),en_name varchar(80),unit varchar(20))");
//            stat.executeUpdate("create table IF NOT EXISTS test(id int,ch_name varchar(80))");
      
            
	        String goods[][]  = {
	        		new String[]{"0.0685","carlin"},
	        		new String[]{"0.0685","carson" },
	        		new String[]{"0.071","dayton"},
	        		new String[]{"0.0685","elko"},
	        		new String[]{"0.07725","ely" },
	        		
	        		new String[]{"0.0685","edureka"},	   
	        		new String[]{"0.076","fallon"},
	        		new String[]{"0.071","fernley" },
	        		new String[]{"0.08265","incline village"},	        		
	        		new String[]{"0.071","minden"},	        	        		

	        		new String[]{"0.08265","reno"},	   
	        		new String[]{"0.08265","sparks"},
	        		new String[]{"0.071","stateline" },
	        		new String[]{"0.08265","verdi"},	        		
	        		new String[]{"0.071","winnemucca"},	  

	        		new String[]{"0.071","yerington"},	  
	        		};
	        
//	        System.out.println(goods[0][1]);
//	        System.out.println(goods[0][0]);
	        	String ww =" ";


	        	
	        	
	 		   for(int i = 0;i<goods.length;i++)
			   {
	 			  String sql3 = "select distinct *  from customlist WHERE city LIKE '%"+goods[i][1]+"%' ";
				 System.out.println(sql3);
					PreparedStatement pst2= conn.prepareStatement(sql3);

					ResultSet rs2 = pst2.executeQuery();			 
				 
				 
				 rs2 = pst2.executeQuery();
					while(rs2.next())
					{
						
						ww=rs2.getString("id");
						System.out.println(ww);
						stat.executeUpdate("update customlist set ID= "+ww+" ,tax= "+goods[i][0]+"; ");

					}
					pst2.close();

			   }
				


            
//            stat.executeUpdate("insert into test values (1,"cctv");");
          //  stat.executeUpdate("insert into test values (2,"bbc");");

            stat.close();
            conn.close();
            System.out.println(" copy down.");
   
        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stat!=null) stat.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("Goodbye!");
    }
    
    public static String AddET2(String tablename,int id, String chname )
	{
    	String result = String.format("insert into %s values(%d,\"%s\");", tablename,id,chname);
    	System.out.println(result);
    	return result;

	}

    
    
    
}