package hi.runoobtest;
import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.sql.*;
 
public class TestWeb {
 
    // MySQL 8.0 ���°汾 - JDBC �����������ݿ� URL
    //static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
    //static final String DB_URL = "jdbc:mysql://localhost:3306/RUNOOB";
 
    // MySQL 8.0 ���ϰ汾 - JDBC �����������ݿ� URL
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
    static final String DB_URL = "jdbc:mysql://localhost:3306/RUNOOB?characterEcoding=utf-8&useSSL=false&serverTimezone=UTC";
 
 
    // ���ݿ���û��������룬��Ҫ�����Լ�������
    static final String USER = "root";
    static final String PASS = "123";

    
    
    public static void main(String[] args) 
    {
        Connection conn = null;
        Statement stmt = null;
        
        
        
        try{
            // ע�� JDBC ����
            Class.forName(JDBC_DRIVER);
        
            // ������
            System.out.println("�������ݿ�...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
        
            // ִ�в�ѯ
            System.out.println(" ʵ����Statement����...");
            //stmt = conn.createStatement();
            String sql;
            
            Statement stat = conn.createStatement();	
            //�������ݿ�hello
       //     stat.executeUpdate("create database hello");
         //   stat.executeUpdate(AddET("test",4,"Barron"));
            
            //�򿪴��������ݿ�
            stat.close();
            conn.close();
            //String  url = "jdbc:mysql://localhost:3306/hello?characterEcoding=utf-8&useSSL=false&serverTimezone=UTC";
   
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
            stat = conn.createStatement();
     /*
            //������test
       	    stat.executeUpdate("create table test(id int, name varchar(80))");
     
            //��������
            stat.executeUpdate("insert into test values(3, 'CK')");
            stat.executeUpdate("insert into test values(4, 'MG')");
     */
            //��ѯ����
            
            JFrame frame=new JFrame("Product Inventory");
            frame.setSize(500,200);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            Container contentPane=frame.getContentPane();
            Object[][] tableDate=new Object[10][6];
            int i =0;
            ResultSet result = stat.executeQuery("select * from test");
            while (result.next())
            {
     //       	id int,price int, number int,ch_name varchar(80),en_name varchar(80),unit varchar(20))
            	tableDate[i][0] = result.getInt("id");
            	tableDate[i][1] = result.getDouble("price");
            	tableDate[i][2] = result.getInt("number");
            	tableDate[i][3] = result.getString("ch_name");
            	tableDate[i][4] = result.getString("en_name");
            	tableDate[i][5] = result.getString("unit");
            	
            //    System.out.println(result.getInt("id") + " " + result.getString("name"));
                i = i+1;
            }
            
            
	
            System.out.println("\n");
            String[] name={"ID","Price","Category","Subtitle","ProductName","CaseText"};
            JTable table=new JTable(tableDate,name);
            contentPane.add(new JScrollPane(table));
            table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);


        	
          //  table.setPreferredScrollableViewportSize(new Dimension(50, 0));
        	table.getColumnModel().getColumn(0).setPreferredWidth(30);
        	table.getColumnModel().getColumn(1).setPreferredWidth(50);
        	table.getColumnModel().getColumn(2).setPreferredWidth(70);
        	table.getColumnModel().getColumn(3).setPreferredWidth(100);
        	table.getColumnModel().getColumn(4).setPreferredWidth(100);
        	table.getColumnModel().getColumn(5).setPreferredWidth(70);
            frame.setVisible(true);
            
 
            result.close();
            stat.close();
            conn.close();

        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("Goodbye!");
    }
    
    
    





    
}