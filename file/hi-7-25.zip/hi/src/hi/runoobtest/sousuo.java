package hi.runoobtest;


import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;



import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.sql.*;


public class sousuo {

	
    // MySQL 8.0 ���ϰ汾 - JDBC �����������ݿ� URL
	    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
	    static final String DB_URL = "jdbc:mysql://localhost:3306/RUNOOB?characterEcoding=utf-8&useSSL=false&serverTimezone=UTC";
	 
	 
	    // ���ݿ���û��������룬��Ҫ�����Լ�������
	    static final String USER = "root";
	    static final String PASS = "123";
	
	    
		static JPanel topPanel;
		static JPanel bottomPanel;
		static JPanel middlePanel;
		 
	static void createTopPanel() {
		Connection  conn  = null; 
		Statement  stat = null; 
		try{
	            // ע�� JDBC ����
	            Class.forName(JDBC_DRIVER);
	        
	            // ������
	            System.out.println("�������ݿ�...");
	              conn = DriverManager.getConnection(DB_URL,USER,PASS);
	        
	            // ִ�в�ѯ
	            System.out.println(" ʵ����Statement����...");

	            //String  url = "jdbc:mysql://localhost:3306/hello?characterEcoding=utf-8&useSSL=false&serverTimezone=UTC";

	              stat = conn.createStatement();

	           // JFrame frame=new JFrame("Product Inventory");
	            JPanel topPanel = new JPanel();

	           // Container contentPane=frame.getContentPane();
	            Object[][] tableDate=new Object[10][6];
	            int i =0;
	            ResultSet result = stat.executeQuery("select * from test");
	            while (result.next())
	            {
	     //       	id int,price int, number int,ch_name varchar(80),en_name varchar(80),unit varchar(20))
	            	tableDate[i][0] = result.getInt("id");
	            	tableDate[i][1] = result.getDouble("price");
	            	tableDate[i][2] = result.getInt("number");
	            	tableDate[i][3] = result.getString("ch_name");
	            	tableDate[i][4] = result.getString("en_name");
	            	tableDate[i][5] = result.getString("unit");
	            	
	            //    System.out.println(result.getInt("id") + " " + result.getString("name"));
	                i = i+1;
	            }
	            
	            
		
	            System.out.println("\n");
	            String[] name={"ID","Price","Category","Subtitle","ProductName","CaseText"};
	            JTable table=new JTable(tableDate,name);
	           // contentPane.add(new JScrollPane(table));
	            table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);


	        	
	          //  table.setPreferredScrollableViewportSize(new Dimension(50, 0));
	        	table.getColumnModel().getColumn(0).setPreferredWidth(30);
	        	table.getColumnModel().getColumn(1).setPreferredWidth(50);
	        	table.getColumnModel().getColumn(2).setPreferredWidth(70);
	        	table.getColumnModel().getColumn(3).setPreferredWidth(100);
	        	table.getColumnModel().getColumn(4).setPreferredWidth(100);
	        	table.getColumnModel().getColumn(5).setPreferredWidth(70);
	         //   frame.setVisible(true);
	            
	 
	            result.close();
	            stat.close();
	            conn.close();
		
	    		//JTable table = new JTable(new DefaultTableModel(rowData, columnName));
		
	    	//	JScrollPane scrollPane = new JScrollPane(table);
	    	//	scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	    		topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
	    		topPanel.add(Box.createVerticalStrut(10));
	    	//	topPanel.add(scrollPane);
	            topPanel.add(Box.createVerticalStrut(10));
        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stat!=null) stat.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("Goodbye!");
	

	}

	static void createMiddlePanel() {
		middlePanel = new JPanel();
		middlePanel.setLayout(new BoxLayout(middlePanel, BoxLayout.X_AXIS));
		
		JLabel sourceLabel = new JLabel("�˶�����Ŀ��");
		sourceLabel.setAlignmentY(Component.TOP_ALIGNMENT);
		sourceLabel.setBorder(BorderFactory.createEmptyBorder(4, 5, 0, 5));
		DefaultListModel listModel = new DefaultListModel();
		listModel.addElement("100��");
		listModel.addElement("200��");
		listModel.addElement("400��");
		listModel.addElement("��Զ");
		listModel.addElement("����");
		listModel.addElement("Ǧ��");
		JList sourceList = new JList(listModel);
		sourceList
				.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		sourceList.setVisibleRowCount(5);
		JScrollPane sourceListScroller = new JScrollPane(sourceList);
		sourceListScroller.setPreferredSize(new Dimension(120, 80));
		sourceListScroller
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		sourceListScroller.setAlignmentY(Component.TOP_ALIGNMENT);
		JPanel sourceListPanel = new JPanel();
		sourceListPanel.setLayout(new BoxLayout(sourceListPanel,
				BoxLayout.X_AXIS));
		sourceListPanel.add(sourceLabel);
		sourceListPanel.add(sourceListScroller);
		sourceListPanel.setAlignmentY(Component.TOP_ALIGNMENT);
		sourceListPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 30));
		middlePanel.add(sourceListPanel);
		
		JButton toTargetButton = new JButton(">>");
		JButton toSourceButton = new JButton("<<");
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
		buttonPanel.add(toTargetButton);
		buttonPanel.add(Box.createRigidArea(new Dimension(15, 15)));
		buttonPanel.add(toSourceButton);
		buttonPanel.setAlignmentY(Component.TOP_ALIGNMENT);
		buttonPanel.setBorder(BorderFactory.createEmptyBorder(15, 5, 15, 5));
		middlePanel.add(buttonPanel);

		JLabel targetLabel = new JLabel("��ѯ��Ŀ��");
		targetLabel.setAlignmentY(Component.TOP_ALIGNMENT);
		targetLabel.setBorder(BorderFactory.createEmptyBorder(4, 5, 0, 5));
		DefaultListModel targetListModel = new DefaultListModel();
		targetListModel.addElement("100��");
		JList targetList = new JList(targetListModel);
		targetList
				.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		targetList.setVisibleRowCount(5);
		JScrollPane targetListScroller = new JScrollPane(targetList);
		targetListScroller.setPreferredSize(new Dimension(120, 80));
		targetListScroller
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		targetListScroller.setAlignmentY(Component.TOP_ALIGNMENT);
		JPanel targetListPanel = new JPanel();
		targetListPanel.setLayout(new BoxLayout(targetListPanel,
				BoxLayout.X_AXIS));
		targetListPanel.add(targetLabel);
		targetListPanel.add(targetListScroller);
		targetListPanel.setAlignmentY(Component.TOP_ALIGNMENT);
		targetListPanel.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 0));
		middlePanel.add(targetListPanel);
	}

	static void createBottomPanel() {
		JButton actionButton = new JButton("��ѯ");
		JButton closeButton = new JButton("�˳�");
		bottomPanel = new JPanel();
		bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.add(actionButton);
		buttonPanel.add(Box.createHorizontalGlue());
		buttonPanel.add(closeButton);
		bottomPanel.add(Box.createVerticalStrut(10));
		bottomPanel.add(buttonPanel);
		bottomPanel.add(Box.createVerticalStrut(10));
	}

	public static void main(String[] args) {
		createTopPanel();
		createMiddlePanel();
		createBottomPanel();

		JPanel panelContainer = new JPanel();
		panelContainer.setLayout(new GridBagLayout());

		GridBagConstraints c1 = new GridBagConstraints();
		c1.gridx = 0;
		c1.gridy = 0;
		c1.weightx = 1.0;
		c1.weighty = 1.0;

		c1.fill = GridBagConstraints.BOTH;
		panelContainer.add(topPanel, c1);

		GridBagConstraints c2 = new GridBagConstraints();
		c2.gridx = 0;
		c2.gridy = 1;
		c2.weightx = 1.0;
		c2.weighty = 0;
		c2.fill = GridBagConstraints.HORIZONTAL;
		panelContainer.add(middlePanel, c2);

		GridBagConstraints c3 = new GridBagConstraints();
		c3.gridx = 0;
		c3.gridy = 2;
		c3.weightx = 1.0;
		c3.weighty = 0;
		c3.fill = GridBagConstraints.HORIZONTAL;
		panelContainer.add(bottomPanel, c3);

		JFrame frame = new JFrame("Boxlayout��ʾ");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		panelContainer.setOpaque(true);
		frame.setSize(new Dimension(480, 320));
		frame.setContentPane(panelContainer);
		frame.setVisible(true);
	}
}
