package javaGui;
import java.io.File;
import java.io.IOException;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.Number;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class gen_xls {
	public static void main(String[] args) {
        String goods[][]  = {
        		new String[]{"11","bag","Taita", "22.00", "Yes", "̫̫����","Taita", "22.00", "Yes", "̫̫����"},
        		new String[]{"2","cs","space X", "122.24", "No", "��ǰһ��","Taita", "22.00", "Yes", "̫̫����"},
        		new String[]{"11","bag","Taita", "22.00", "Yes", "̫̫����","Taita", "22.00", "Yes", "̫̫����"},
        		new String[]{"2","cs","space X", "122.24", "No", "��ǰһ��","Taita", "22.00", "Yes", "̫̫����"},		
        };
        save_supplier(goods);
	
        
	}
	public static void save_export(String [][] In) 
	{
		try 
		{
			//����Excel�ļ�
			WritableWorkbook wwb = Workbook.createWorkbook(new File(sqlcon.savepath+"export.xls"));
			//���ɵ�һҳ������
			WritableSheet sheet = wwb.createSheet("No1", 0);
			//ָ����Ԫ��

			
			
			Label label1 = new Label(0, 0, "id");
			Label label2 = new Label(1, 0, "ch_name");
			Label label3 = new Label(2, 0, "en_name");
			Label label4 = new Label(3, 0, "buy from");
			Label label5 = new Label(4, 0, "transdate");
			Label label6 = new Label(5, 0, "largenum");
			Label label7 = new Label(6, 0, "cost");

			try
			{
				sheet.addCell(label1);
				sheet.addCell(label2);
				sheet.addCell(label3);
				sheet.addCell(label4);				
				
				sheet.addCell(label5);
				sheet.addCell(label6);
				sheet.addCell(label7);
//				sheet.addCell(label8);					
//				sheet.addCell(label9);

				int rows = In.length;//����
				int columns = In[0].length;//����
				for(int j = 0; j<rows;j++)
				{
					for(int i = 0; i<columns;i++)
					{
					Label number = new Label(i,j+1,In[j][i]);
					sheet.addCell(number);
					}
				}
				wwb.write();
				wwb.close();
			} 
			catch (RowsExceededException e) 
			{
				e.printStackTrace();
			} 
			catch (WriteException e) 
			{
				e.printStackTrace();
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
		
	
	public static void trans_data(String [][] In) 
	{
		try 
		{
			//����Excel�ļ�
			WritableWorkbook wwb = Workbook.createWorkbook(new File(sqlcon.savepath+"temp.xls"));
			//���ɵ�һҳ������
			WritableSheet sheet = wwb.createSheet("No1", 0);
			//ָ����Ԫ��
			
			Label label1 = new Label(0, 0, "ID");
			Label label2 = new Label(1, 0, "innerid");
			Label label3 = new Label(2, 0, "goodid");
			Label label4 = new Label(3, 0, "qty");
			Label label5 = new Label(4, 0, "unit");
			Label label6 = new Label(5, 0, "price");
//			Label label7 = new Label(6, 0, "cost");
			Label label8 = new Label(7, 0, "taxrate");
			Label label9 = new Label(8, 0, "ch");
			Label label10 = new Label(9, 0, "en");
			Label label11 = new Label(10, 0, "remark");
	


			try
			{
				sheet.addCell(label1);
				sheet.addCell(label2);
				sheet.addCell(label3);
				sheet.addCell(label4);				
				
				sheet.addCell(label5);
				sheet.addCell(label6);
//				sheet.addCell(label7);
				sheet.addCell(label8);					
				sheet.addCell(label9);
				sheet.addCell(label10);
				sheet.addCell(label11);
				
				int rows = In.length;//����
				int columns = In[0].length;//����
				for(int j = 0; j<rows;j++)
				{
					for(int i = 0; i<columns;i++)
					{
					Label number = new Label(i,j+1,In[j][i]);
					sheet.addCell(number);
					}
				}
				wwb.write();
				wwb.close();
			} 
			catch (RowsExceededException e) 
			{
				e.printStackTrace();
			} 
			catch (WriteException e) 
			{
				e.printStackTrace();
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}	
	
	
	public static void save_item(String [][] In,String total) 
	{
		try 
		{
			
		
			
			//����Excel�ļ�
			WritableWorkbook wwb = Workbook.createWorkbook(new File(sqlcon.savepath+"item.xls"));
			//���ɵ�һҳ������
			WritableSheet sheet = wwb.createSheet("No1", 0);
			//ָ����Ԫ��
			
			Label label1 = new Label(0, 0, "Invoice_id");
			Label label2 = new Label(1, 0, "Inventory_id");
			Label label3 = new Label(2, 0, "qty");
			Label label4 = new Label(3, 0, "sale_price");
			Label label5 = new Label(4, 0, "itempercase");
			Label label6 = new Label(5, 0, "casecost");
			Label label7 = new Label(6, 0, "itemcost");

			Label label8 = new Label(7, 0, "unit");
			Label label9 = new Label(8, 0, "total");
			Label label10 = new Label(9, 0, "csflag");
			Label label11 = new Label(10, 0, "ch_name");
			Label label12 = new Label(11, 0, "en_name");
			Label label13 = new Label(12, 0, "orderdate");
			Label label14 = new Label(13, 0, "profit");
			Label label_all = new Label(14, 0,"total:"+total);
			try
			{
				sheet.addCell(label1);
				sheet.addCell(label2);
				sheet.addCell(label3);
				sheet.addCell(label4);				
				sheet.addCell(label5);
				
				sheet.addCell(label6);
				sheet.addCell(label7);
				sheet.addCell(label8);					
				sheet.addCell(label9);
				sheet.addCell(label10);
				sheet.addCell(label11);
				sheet.addCell(label12);					
				sheet.addCell(label13);
				sheet.addCell(label14);
				sheet.addCell(label_all);
				
				int rows = In.length;//����
				int columns = In[0].length;//����
				for(int j = 0; j<rows;j++)
				{
					for(int i = 0; i<columns;i++)
					{
					Label number = new Label(i,j+1,In[j][i]);
					sheet.addCell(number);
					}
				}

				
				wwb.write();
				wwb.close();
			} 
			catch (RowsExceededException e) 
			{
				e.printStackTrace();
			} 
			catch (WriteException e) 
			{
				e.printStackTrace();
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	public static void save_inv(String [][] In,String total) 
	{
		try 
		{
			//����Excel�ļ�
			WritableWorkbook wwb = Workbook.createWorkbook(new File(sqlcon.savepath+"inv.xls"));
			//���ɵ�һҳ������
			WritableSheet sheet = wwb.createSheet("No1", 0);
			//ָ����Ԫ��

			Label label1 = new Label(0, 0, "Invoice_id");
			Label label2 = new Label(1, 0, "item_number");
			Label label3 = new Label(2, 0, "name");
			Label label4 = new Label(3, 0, "city");
			Label label5 = new Label(4, 0, "state");
			Label label6 = new Label(5, 0, "orderdate");
			Label label7 = new Label(6, 0, "profit");

			Label label8 = new Label(7, 0, "total:"+total);
			try
			{
				sheet.addCell(label1);
				sheet.addCell(label2);
				sheet.addCell(label3);
				sheet.addCell(label4);				
				sheet.addCell(label5);
				
				sheet.addCell(label6);
				sheet.addCell(label7);
				sheet.addCell(label8);
				
				int rows = In.length;//����
				int columns = In[0].length;//����
				for(int j = 0; j<rows;j++)
				{
					for(int i = 0; i<columns;i++)
					{
					Label number = new Label(i,j+1,In[j][i]);
					sheet.addCell(number);
					}
				}
				wwb.write();
				wwb.close();
			} 
			catch (RowsExceededException e) 
			{
				e.printStackTrace();
			} 
			catch (WriteException e) 
			{
				e.printStackTrace();
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}

	public static void save_customer(String [][] In, String total) 
	{
		try 
		{
			//����Excel�ļ�
			WritableWorkbook wwb = Workbook.createWorkbook(new File(sqlcon.savepath+"customer_view.xls"));
			//���ɵ�һҳ������
			WritableSheet sheet = wwb.createSheet("No1", 0);
			//ָ����Ԫ��


			Label label1 = new Label(0, 0, "customer_id");
			Label label2 = new Label(1, 0, "order_Amount");
			Label label3 = new Label(2, 0, "name");
			Label label4 = new Label(3, 0, "city");
			Label label5 = new Label(4, 0, "state");
			Label label7 = new Label(5, 0, "profit");
			Label label8 = new Label(6, 0, "total:"+total);
			
			try
			{
				sheet.addCell(label1);
				sheet.addCell(label2);
				sheet.addCell(label3);
				sheet.addCell(label4);				
				sheet.addCell(label5);
				sheet.addCell(label7);
				sheet.addCell(label8);
				
				int rows = In.length;//����
				int columns = In[0].length;//����
				for(int j = 0; j<rows;j++)
				{
					for(int i = 0; i<columns;i++)
					{
					Label number = new Label(i,j+1,In[j][i]);
					sheet.addCell(number);
					}
				}
				wwb.write();
				wwb.close();
			} 
			catch (RowsExceededException e) 
			{
				e.printStackTrace();
			} 
			catch (WriteException e) 
			{
				e.printStackTrace();
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	

	
	public static void save_prod(String [][] In,String total) 
	{
		try 
		{
			//����Excel�ļ�
			WritableWorkbook wwb = Workbook.createWorkbook(new File(sqlcon.savepath+"product_view.xls"));
			//���ɵ�һҳ������
			WritableSheet sheet = wwb.createSheet("No1", 0);
			//ָ����Ԫ��


			Label label1 = new Label(0, 0, "product_id");
			Label label2 = new Label(1, 0, "qty");
			Label label3 = new Label(2, 0, "ch_name");
			Label label4 = new Label(3, 0, "en_name");

			Label label7 = new Label(4, 0, "profit");
			Label label8 = new Label(5, 0, "total:" +total);
			
			try
			{
				sheet.addCell(label1);
				sheet.addCell(label2);
				sheet.addCell(label3);
				sheet.addCell(label4);				
//				sheet.addCell(label5);
				sheet.addCell(label7);
				sheet.addCell(label8);
				
				int rows = In.length;//����
				int columns = In[0].length;//����
				for(int j = 0; j<rows;j++)
				{
					for(int i = 0; i<columns;i++)
					{
					Label number = new Label(i,j+1,In[j][i]);
					sheet.addCell(number);
					}
				}
		
				wwb.write();
				wwb.close();
			} 
			catch (RowsExceededException e) 
			{
				e.printStackTrace();
			} 
			catch (WriteException e) 
			{
				e.printStackTrace();
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
		
	
	public static void save_stock(String [][] In) 
	{
		try 
		{
			//����Excel�ļ�
			WritableWorkbook wwb = Workbook.createWorkbook(new File(sqlcon.savepath+"stock.xls"));
			//���ɵ�һҳ������
			WritableSheet sheet = wwb.createSheet("No1", 0);
			//ָ����Ԫ��
			
			Label label1 = new Label(0, 0, "productID");
			Label label2 = new Label(1, 0, "ch_name");
			Label label3 = new Label(2, 0, "en_name");
			Label label4 = new Label(3, 0, "buy");
			Label label5 = new Label(4, 0, "sale");
			Label label6 = new Label(5, 0, "storing");
			Label label8 = new Label(6, 0, "unit");
			Label label7 = new Label(7, 0, "cost");

			try
			{
				sheet.addCell(label1);
				sheet.addCell(label2);
				sheet.addCell(label3);
				sheet.addCell(label4);				
				
				sheet.addCell(label5);
				sheet.addCell(label6);
				sheet.addCell(label8);
				sheet.addCell(label7);

				int rows = In.length;//����
				int columns = In[0].length;//����
				for(int j = 0; j<rows;j++)
				{
					for(int i = 0; i<columns;i++)
					{
					Label number = new Label(i,j+1,In[j][i]);
					sheet.addCell(number);
					}
				}
				wwb.write();
				wwb.close();
			} 
			catch (RowsExceededException e) 
			{
				e.printStackTrace();
			} 
			catch (WriteException e) 
			{
				e.printStackTrace();
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
		
	
	
	public static void save_custom(String [][] In) 
	{
		try 
		{
			//����Excel�ļ�
			WritableWorkbook wwb = Workbook.createWorkbook(new File(sqlcon.savepath+"backup\\custom.xls"));
			//���ɵ�һҳ������
			WritableSheet sheet = wwb.createSheet("No1", 0);
			//ָ����Ԫ��
			
			Label label1 = new Label(0, 0, "CustomersID");
			Label label2 = new Label(1, 0, "Name");
			Label label3 = new Label(2, 0, "PhoneNumber");
			Label label4 = new Label(3, 0, "Address");
			Label label5 = new Label(4, 0, "City");
			Label label6 = new Label(5, 0, "State/Province");
			 
			Label label7 = new Label(6, 0, "Zip Code");
			Label label8 = new Label(7, 0, "Tax");
			Label label9 = new Label(8, 0, "Notes");	
	


			try
			{
				sheet.addCell(label1);
				sheet.addCell(label2);
				sheet.addCell(label3);
				sheet.addCell(label4);				
				
				sheet.addCell(label5);
				sheet.addCell(label6);
				sheet.addCell(label7);
				sheet.addCell(label8);					
				sheet.addCell(label9);

				int rows = In.length;//����
				int columns = In[0].length;//����
				for(int j = 0; j<rows;j++)
				{
					for(int i = 0; i<columns;i++)
					{
					Label number = new Label(i,j+1,In[j][i]);
					sheet.addCell(number);
					}
				}
				wwb.write();
				wwb.close();
			} 
			catch (RowsExceededException e) 
			{
				e.printStackTrace();
			} 
			catch (WriteException e) 
			{
				e.printStackTrace();
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	
	public static void save_product(String [][] In) 
	{
		try 
		{
			//����Excel�ļ�
			WritableWorkbook wwb = Workbook.createWorkbook(new File(sqlcon.savepath+"backup\\product.xls"));
			//���ɵ�һҳ������
			WritableSheet sheet = wwb.createSheet("No1", 0);
			//ָ����Ԫ��


			
			Label label1 = new Label(0, 0, "ProductID");
			Label label2 = new Label(1, 0, "ProductName");
			Label label3 = new Label(2, 0, "PRICE");
			Label label4 = new Label(3, 0, "CATEGORY");
			Label label5 = new Label(4, 0, "Subtitle");
			Label label6 = new Label(5, 0, "ItemsPerCase");
			 
			Label label7 = new Label(6, 0, "ItemPrice");
			Label label8 = new Label(7, 0, "Taxable");
			Label label9 = new Label(8, 0, "CaseText");	
			Label label10 = new Label(9, 0, "ItemText");	


			try
			{
				sheet.addCell(label1);
				sheet.addCell(label2);
				sheet.addCell(label3);
				sheet.addCell(label4);				
				
				sheet.addCell(label5);
				sheet.addCell(label6);
				sheet.addCell(label7);
				sheet.addCell(label8);					
				sheet.addCell(label9);
				sheet.addCell(label10);
				int rows = In.length;//����
				int columns = In[0].length;//����
				for(int j = 0; j<rows;j++)
				{
					for(int i = 0; i<columns;i++)
					{
					Label number = new Label(i,j+1,In[j][i]);
					sheet.addCell(number);
					}
				}
				wwb.write();
				wwb.close();
			} 
			catch (RowsExceededException e) 
			{
				e.printStackTrace();
			} 
			catch (WriteException e) 
			{
				e.printStackTrace();
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
		public static void save_supplier(String [][] In) 
		{
		try 
		{
			//����Excel�ļ�
			WritableWorkbook wwb = Workbook.createWorkbook(new File(sqlcon.savepath+"backup\\supplier.xls"));
			//���ɵ�һҳ������
			WritableSheet sheet = wwb.createSheet("No1", 0);
			//ָ����Ԫ��
			Label label1 = new Label(0, 0, "Address");
			Label label2 = new Label(1, 0, "City");
			Label label3 = new Label(2, 0, "State/Province");
			Label label4 = new Label(3, 0, "Postal Code");
			Label label5 = new Label(4, 0, "Phone Number");
			Label label6 = new Label(5, 0, "Fax Number");
			 
			Label label7 = new Label(6, 0, "Contact Name");
			Label label8 = new Label(7, 0, "Contact Title");
			Label label9 = new Label(8, 0, "Email Address");	
			Label label10 = new Label(9, 0, "Notes");	


			try
			{
				sheet.addCell(label1);
				sheet.addCell(label2);
				sheet.addCell(label3);
				sheet.addCell(label4);				
				
				sheet.addCell(label5);
				sheet.addCell(label6);
				sheet.addCell(label7);
				sheet.addCell(label8);					
				sheet.addCell(label9);
				sheet.addCell(label10);
				
				int rows = In.length;//����
				int columns = In[0].length;//����
				for(int j = 0; j<rows;j++)
				{
					for(int i = 0; i<columns;i++)
					{
					Label number = new Label(i,j+1,In[j][i]);
					sheet.addCell(number);
					}
				}
				wwb.write();
				wwb.close();
			} 
			catch (RowsExceededException e) 
			{
				e.printStackTrace();
			} 
			catch (WriteException e) 
			{
				e.printStackTrace();
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
}
