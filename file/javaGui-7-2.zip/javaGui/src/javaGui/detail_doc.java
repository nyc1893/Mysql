package javaGui;

import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.spire.doc.Document;
import com.spire.doc.FieldType;
import com.spire.doc.FileFormat;
import com.spire.doc.HeaderFooter;
import com.spire.doc.Section;
import com.spire.doc.Table;
import com.spire.doc.TableRow;
import com.spire.doc.documents.BorderStyle;
import com.spire.doc.documents.HorizontalAlignment;
import com.spire.doc.documents.Paragraph;
import com.spire.doc.documents.ParagraphStyle;
import com.spire.doc.documents.TableRowHeightType;
import com.spire.doc.documents.VerticalAlignment;
import com.spire.doc.fields.TextRange;

public class detail_doc {
	
	

		
		   public static void main(String[] args)
		   {

		         String[]temp2 =
               {
            		   "2020-1-1","2020-1-30"
               	};
//		         start date , end date, report date


		        
		        String[][] Item =
	                {
	                        new String[]{"229912","CCC", "1","23.12"},
	                        new String[]{"231338","AAA", "1","23.56"},
	                        new String[]{"231577","ddd", "2","22.22"},
	  
	                };

		        
		        top(Item,temp2);
		        

		   }
		   
		   
		   public static void top(String[][]Item, String[] temp2)
		   {
		        

		        String[] res = gentotal(Item);

		        lowLevel(Item,temp2,res);	   
			   
			   
		   }
		   public static String getSysTime()
		   {
		        SimpleDateFormat sdf = new SimpleDateFormat();// ��ʽ��ʱ�� 
		        
		        sdf.applyPattern("yyyy-MM-dd");
		        
//		        sdf.applyPattern("yyyy/MM/dd");// aΪam/pm�ı��  
		        Date date = new Date();// ��ȡ��ǰʱ�� 
		        
		        String shijian  = sdf.format(date);
		        System.out.println(shijian); 
		        return shijian;
		   }

		   public static String[] gentotal(String [][] In)
		   {
			   
			   java.text.DecimalFormat myformat=new java.text.DecimalFormat("#0.00");
			   int size = In.length;
			   int sum_ord = 0;
			   
			   
			   
			   
			   double sum= 0;

			   for(int i = 0;i<size;i++)
			   {

				   int ord_num = Integer.valueOf(In[i][2]);
				   sum_ord += ord_num;
				   double price = Double.parseDouble(In[i][3]);//װ��Ϊdouble����
				   
				   price=Double.parseDouble(myformat.format(price));//����bai2ΪС��
				   sum+=price;

			   }

			   String res[] = new String[3];  

			   res[0] = String.valueOf(size);
			   res[1] =   String.valueOf(sum_ord);
			   
			    res[2]  = myformat.format(sum);
//			   System.out.print(res[0]);
//			   System.out.print(res[1]);
//			   System.out.print(res[2]);
			   return res;
		   }
		   	   	   
		   
		
		   
		        public static void lowLevel(String data[][],String[] temp2,String[] res){   
		        //����Document����
			   	String textstyle = "Times New Roman";
		        Document doc = new Document();
		        Section sec = doc.addSection();


		        
		        Paragraph para1 = sec.addParagraph();
		        para1.appendText("Customer Overall Report\n");



		        Paragraph para2 = sec.addParagraph();
		        para2.appendText("Report From " +temp2[0]+" to "+temp2[1]+"\n");
		        
		        Paragraph para5 = sec.addParagraph();
		        para2.appendText("Report date: "+getSysTime()+"\n");		        
		        //������������
		        String[] header = {"Custom ID #","Name","Order","Total"};

		        
		        ParagraphStyle style1 = new ParagraphStyle(doc);
		        style1.setName("titleStyle");
		        style1.getCharacterFormat().setBold(true);
		        style1.getCharacterFormat().setTextColor(Color.BLACK);
		        style1.getCharacterFormat().setFontName(textstyle);
		        style1.getCharacterFormat().setFontSize(24f);
		        doc.getStyles().add(style1);
		        para1.applyStyle("titleStyle");		        
		        
		        HeaderFooter footer2 = doc.getSections().get(0).getHeadersFooters().getFooter();
		        Paragraph footerParagraph = footer2.addParagraph();
		        //�������֡�ҳ�������ҳ���򵽶���
//				 footerParagraph.appendText("��");
		        footerParagraph.appendField("page number", FieldType.Field_Page);
		        footerParagraph.appendText("/");
		        footerParagraph.appendField("number of pages", FieldType.Field_Num_Pages);
//		        footerParagraph.appendText("ҳ");
				        //���������
				 footerParagraph.getFormat().setHorizontalAlignment(HorizontalAlignment.Center);		        

		        //���ӱ���
		        Table table = sec.addTable(true);
		        table.resetCells(data.length + 1, header.length);
		        TableRow row = table.getRows().get(0);
		        //���ñ����һ����Ϊ��ͷ��д���ͷ�������ݣ�����ʽ����ͷ����
		        row = table.getRows().get(0);
//		        TableRow row = table.getRows().get(0);
		        table.getRows().get(0).getCells().get(0).setWidth(80);
		        table.getRows().get(0).getCells().get(1).setWidth(244);
		        table.getRows().get(0).getCells().get(2).setWidth(80);
		        table.getRows().get(0).getCells().get(3).setWidth(80);
		        row.isHeader(true);
//		        row.setHeight(20);
//		        row.setHeightType(TableRowHeightType.Exactly);
//		        row.getRowFormat().setBackColor(Color.ORANGE);
		        for (int i = 0; i < header.length; i++) {
		            row.getCells().get(i).getCellFormat().setVerticalAlignment(VerticalAlignment.Middle);
		            Paragraph p = row.getCells().get(i).addParagraph();
		            p.getFormat().setHorizontalAlignment(HorizontalAlignment.Center);
		            TextRange range1 = p.appendText(header[i]);
		            range1.getCharacterFormat().setFontName(textstyle);
		            range1.getCharacterFormat().setFontSize(11f);
		            range1.getCharacterFormat().setBold(true);
//		            range1.getCharacterFormat().setTextColor(Color.white);
		            
	                if(i == data[0].length-1)
	               	 range1.getOwnerParagraph().getFormat().setHorizontalAlignment(HorizontalAlignment.Right);
	               else
	               {
	               	range1.getOwnerParagraph().getFormat().setHorizontalAlignment(HorizontalAlignment.Left);
	           		
	               }
		            
		        }

		        //д��ʣ�������ݵ����񣬲���ʽ������
		        for (int r = 0; r < data.length; r++) {
		            TableRow dataRow = table.getRows().get(r + 1);
//		            dataRow.getCells().get(0).setWidth(330);
//		            dataRow.getCells().get(1).setWidth(330);
//		            dataRow.getCells().get(2).setWidth(400);
//		            dataRow.setHeight(25);
//		            dataRow.setHeightType(TableRowHeightType.Exactly);
//		            dataRow.getRowFormat().setBackColor(Color.white);
		            for (int c = 0; c < data[r].length; c++) {
		
	           		dataRow.getCells().get(c).getCellFormat().setVerticalAlignment(VerticalAlignment.Middle);
		                TextRange range2 = dataRow.getCells().get(c).addParagraph().appendText(data[r][c]);
		                
		                range2.getOwnerParagraph().getFormat().setHorizontalAlignment(HorizontalAlignment.Left);
		                range2.getCharacterFormat().setFontName(textstyle);
		                if(c == data[0].length-1)
		                	 range2.getOwnerParagraph().getFormat().setHorizontalAlignment(HorizontalAlignment.Right);
		                else
		                {
		                	range2.getOwnerParagraph().getFormat().setHorizontalAlignment(HorizontalAlignment.Left);
		            		
		                }

		   
		                range2.getCharacterFormat().setFontSize(11f);
		
		            }
		        }


		        Paragraph para3 = sec.addParagraph();
		        para3.appendText("");

		        String[][] data3 =
	               {
	                       new String[]{"Grand Total", res[0],res[1], "$"+res[2]},

	               };	        

		        //���ӱ���
		        Table table3 = sec.addTable(true);
		        table3.resetCells(data3.length, data3[0].length);
//		        table3.getRows().get(0).getCells().get(0).setWidth(280);
//		        table3.getRows().get(0).getCells().get(1).setWidth(350);
//		        table3.getRows().get(0).getCells().get(2).setWidth(250);
		        row = table3.getRows().get(0);
		        row.setHeight(30);
		        //д��ʣ�������ݵ����񣬲���ʽ������
		        for (int r = 0; r < data3.length; r++) {
		            TableRow dataRow = table3.getRows().get(r);
		            dataRow.setHeight(16);
		            dataRow.setHeightType(TableRowHeightType.Exactly);
		            dataRow.getRowFormat().setBackColor(Color.white);
		            
		            for (int c = 0; c < data3[r].length; c++) {
		            	
		            	dataRow.getCells().get(c).getCellFormat().setVerticalAlignment(VerticalAlignment.Middle);
		                TextRange range2 = dataRow.getCells().get(c).addParagraph().appendText(data3[r][c]);
		                if(c==0)
		                range2.getOwnerParagraph().getFormat().setHorizontalAlignment(HorizontalAlignment.Left);
		                else if(c>0)
		                	range2.getOwnerParagraph().getFormat().setHorizontalAlignment(HorizontalAlignment.Right);
		                range2.getCharacterFormat().setFontName(textstyle);
		                range2.getCharacterFormat().setBold(true);

		            }
		        }
		        
		        //���ñ���߿���ʽ
		        table.getTableFormat().getBorders().setBorderType(BorderStyle.Single);
//		        table.autoFit(AutoFitBehaviorType.Auto_Fit_To_Contents);

//		        table2.autoFit(AutoFitBehaviorType.Fixed_Column_Widths);
//		        table2.autoFit(AutoFitBehaviorType.Auto_Fit_To_Contents);
		        table3.getTableFormat().getBorders().setBorderType(BorderStyle.None);
		        //�����ĵ�
		        
		        HeaderFooter footer = sec.getHeadersFooters().getFooter();
//		        Paragraph fpara= footer.addParagraph();
////		        fpara.appendField("ҳ��",FieldType.Field_Page);
//		        fpara.appendText("\nAll accounts are due and payable not later than the tenth of the\nmonth "
//		        		+ "following purchase.  There will be a 1 1/2% per month charge\non balances due 30 days "
//		        		+ "or more.  This amounts to 18% per annum.");
////		        fpara.appendField("��ҳ��",FieldType.Field_Num_Pages);
//		        fpara.getFormat().setHorizontalAlignment(HorizontalAlignment.Center);
//		        fpara.getFormat().getBorders().getTop().setBorderType(BorderStyle.None);
//		        fpara.getFormat().getBorders().getTop().setLineWidth(0f);
//		        fpara.getFormat().getBorders().getTop().setSpace(2f);
//		        
		        
		        ParagraphStyle style10 = new ParagraphStyle(doc);
		        style10.setName("foot");
//		        style4.getCharacterFormat().setBold(true);
		        style10.getCharacterFormat().setTextColor(Color.BLACK);
		        style10.getCharacterFormat().setFontName(textstyle);
		        style10.getCharacterFormat().setFontSize(10f);
		        doc.getStyles().add(style10);
//		        fpara.applyStyle("foot");	  
		        doc.saveToFile(sqlcon.savepath+"detail.docx", FileFormat.Docx_2013);

		        System.out.println("save done");
		    }


	}


