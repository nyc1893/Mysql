package javaGui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import javax.swing.JTabbedPane;
import javax.swing.JLayeredPane;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class ad_profit extends JFrame {

	private JPanel contentPane;
	private JTextField textFields1;
	private JTextField textFields2;
	private JTable table_1;
	Connection connection = null;
	private JTable table_2;
	private JTable table_3;
	private JTable table_4;
	private JTextField textFieldtotal1;
	private JTextField textFieldtotal4;
	private JTextField textFieldtotal3;
	private JTextField textFieldtotal2;
	String tmp_value ="";
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ad_profit frame = new ad_profit();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	
	public void refreshUp() {
		try {

			String query= "			"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n";
				
			PreparedStatement pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table_1.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
			query=  "		select	cast( sum(tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) )))) as decimal(10,2))as total \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n";					
			pst= connection.prepareStatement(query);
			 rs = pst.executeQuery();
				while(rs.next())
				{
					textFieldtotal1.setText(rs.getString("total")); 
				}
				pst.close();
				rs.close();
				
//			textFieldtotal1
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}
	
	public void findUpNegative () {
		try {

			String query= "			"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
					+ "  where  tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) )) )<0";
				
			PreparedStatement pst= connection.prepareStatement(query);
			System.out.println(query);
			ResultSet rs = pst.executeQuery();
			table_1.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}
	public void refreshdown() {
		try {
			
			String query= "DROP VIEW IF EXISTS cc";
			PreparedStatement pst= connection.prepareStatement(query);
//			System.out.println(query);
			pst.execute();
			pst.close();
			
			query= "			CREATE VIEW cc AS\r\n"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
					+ "			 ";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();
			
			query= "DROP VIEW IF EXISTS cc2";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();			
			
			query= "CREATE VIEW cc2 AS\r\n"
					+ "SELECT tb1.id as id, COUNT(tb1.goodid) as cnt,sum(tb1.profit) as profit\r\n"
					+ "FROM cc as tb1\r\n"
					+ "GROUP BY tb1.id";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();					
			
			
			query= "select tb1.id,tb1.cnt,tb4.name,tb4.city,tb4.state,tb4.orderdate,tb1.profit "
					+ "from cc2 as tb1 "
					+ "left join InvoiceList as tb4 on tb1.id = tb4.id";
		    pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table_2.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
			query= "select sum(tb1.profit) as total "
					+ "from cc2 as tb1 "
					+ "left join InvoiceList as tb4 on tb1.id = tb4.id";

		
			System.out.println(query);
			pst= connection.prepareStatement(query);
			 rs = pst.executeQuery();
				while(rs.next())
				{
					textFieldtotal2.setText(rs.getString("total")); 
				}
				pst.close();
				rs.close();			
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}
	
	
	public void refreshCustomer() {
		try {
			
			String query= "DROP VIEW IF EXISTS cc";
			PreparedStatement pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();
			
			query= "			CREATE VIEW cc AS\r\n"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
					+ "			 ";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();
			
			query= "DROP VIEW IF EXISTS cc2";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();			
			
			query= 
					 "CREATE VIEW cc2 AS\r\n"
					+ "SELECT tb3.cid as cid,COUNT(tb1.id) as cnt, sum(profit) as profit\r\n"
					+ "from cc as tb1\r\n"
					+ " left join InvoiceList as tb3 on tb1.id = tb3.id\r\n"
					+ "GROUP BY tb3.cid";
			pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();					
			

			query= " select distinct tb1.cid,tb1.cnt as order_Number,tb3.name,tb3.city,tb3.state,tb1.profit"
					+ " from cc2 as tb1\r\n"
					+ " left join InvoiceList as tb3 on tb1.cid = tb3.cid "
					+ " ORDER BY tb1.profit DESC";

			System.out.println(query);
			pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table_3.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			

			query= "select sum(tb1.profit) as total "
					+ " from (select distinct cid,profit from cc2) tb1";


			System.out.println(query);
			pst= connection.prepareStatement(query);
			 rs = pst.executeQuery();
				while(rs.next())
				{
					textFieldtotal3.setText(rs.getString("total")); 
				}
				pst.close();
				rs.close();		
				
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}
	
	public void refreshProduct() {
		try {
			
			String query= "DROP VIEW IF EXISTS cc";
			PreparedStatement pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();
			
			query= "			CREATE VIEW cc AS\r\n"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
					+ "			 ";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();
			
			query= "DROP VIEW IF EXISTS cc2";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();			
			
			query= 	"CREATE VIEW cc2 AS\r\n"
					 + "SELECT tb1.goodid,sum(tb1.qty) as qty,sum(tb1.profit) as profit\r\n"
					 + "FROM cc as tb1\r\n"
					 + "GROUP BY tb1.goodid";
			pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();					
			
			
			query= "select tb1.goodid,tb1.qty,tb3.ch_name,tb3.en_name,tb1.profit\r\n"
					+ "from cc2 as tb1\r\n"
					+ " left join InventoryList as tb3 on tb1.goodid = tb3.inv_id\r\n"
					+ " ORDER BY tb1.profit DESC";
		    pst= connection.prepareStatement(query);
		    System.out.println(query);
			ResultSet rs = pst.executeQuery();
			table_4.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
			
			query= "select sum(tb1.profit) as total"
					+ " from cc2 as tb1";
			System.out.println(query);
			pst= connection.prepareStatement(query);
			 rs = pst.executeQuery();
				while(rs.next())
				{
					textFieldtotal4.setText(rs.getString("total")); 
				}
				pst.close();
				rs.close();					
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}
		
	
	public void findDownNegative() {
		try {
			
			String query= "DROP VIEW IF EXISTS cc";
			PreparedStatement pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();
			
			query= "			CREATE VIEW cc AS\r\n"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
					+ "			 ";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();
			
			query= "DROP VIEW IF EXISTS cc2";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();			
			
			query= "CREATE VIEW cc2 AS\r\n"
					+ "SELECT tb1.id as id, COUNT(tb1.goodid) as cnt,sum(tb1.profit) as profit\r\n"
					+ "FROM cc as tb1\r\n"
					+ "GROUP BY tb1.id";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();					
			
			
			query= "select tb1.id,tb1.cnt,tb4.name,tb4.city,tb4.state,tb4.orderdate,tb1.profit "
					+ "from cc2 as tb1 "
					+ "left join InvoiceList as tb4 on tb1.id = tb4.id"
					+ " where tb1.profit<0";
		    pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table_2.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}	
	
	public void findCustomerNegative() {
		try {
			
			String query= "DROP VIEW IF EXISTS cc";
			PreparedStatement pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();
			
			query= "			CREATE VIEW cc AS\r\n"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
					+ "			 ";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();
			
			query= "DROP VIEW IF EXISTS cc2";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();			
			
			query= 
					 "CREATE VIEW cc2 AS\r\n"
					+ "SELECT tb3.cid,COUNT(tb1.id) as cnt, sum(profit) as profit\r\n"
					+ "from cc as tb1\r\n"
					+ " left join InvoiceList as tb3 on tb1.id = tb3.id\r\n"
					+ "GROUP BY tb3.cid";
			pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();					
			
			
			query= "select distinct tb1.cid,tb1.cnt as order_Number,tb3.name,tb3.city,tb3.state,tb1.profit"
					+ " from cc2 as tb1\r\n"
					+ " left join InvoiceList as tb3 on tb1.cid = tb3.cid\r\n"
					+ " where tb1.profit<0";
		    pst= connection.prepareStatement(query);
		    System.out.println(query);
			ResultSet rs = pst.executeQuery();
			table_3.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}
	
	public void findProductNegtive() {
		try {
			
			String query= "DROP VIEW IF EXISTS cc";
			PreparedStatement pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();
			
			query= "			CREATE VIEW cc AS\r\n"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
					+ "			 ";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();
			
			query= "DROP VIEW IF EXISTS cc2";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();			
			
			query= 	"CREATE VIEW cc2 AS\r\n"
					 + "SELECT tb1.goodid,sum(qty) as qty,sum(tb1.profit) as profit\r\n"
					 + "FROM cc as tb1\r\n"
					 + "GROUP BY tb1.goodid";
			pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();					
			
			
			query= "select tb1.goodid,tb1.qty,tb3.ch_name,tb3.en_name,tb1.profit\r\n"
					+ "from cc2 as tb1\r\n"
					+ " left join InventoryList as tb3 on tb1.goodid = tb3.inv_id\r\n"
					+ " where tb1.profit<0";
		    pst= connection.prepareStatement(query);
		    System.out.println(query);
			ResultSet rs = pst.executeQuery();
			table_4.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}
		
	
	public void searchUp() {
		try {
			
			String string1 = (textFields1.getText().trim().isEmpty())?("''")
					:( "'"+textFields1.getText() + "'");

			String string2 = (textFields2.getText().trim().isEmpty())?("''")
					:( "'"+textFields2.getText() + "'");			
			
			
			
			String query= " ";

			
			query= " "
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name, tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
					+" 			where tb4.orderdate >="+ string1
					+ " 		and tb4.orderdate <= "+ string2
					+" 			order by tb1.id";

			PreparedStatement pst= connection.prepareStatement(query);
		    System.out.println(query);
			ResultSet rs = pst.executeQuery();
			table_1.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			query=  "		select	cast( sum(tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) )))) as decimal(10,2))as total \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
					+" 			where tb4.orderdate >="+ string1
					+ " 		and tb4.orderdate <= "+ string2
					+" 			order by tb1.id";			
			
			pst= connection.prepareStatement(query);
			 rs = pst.executeQuery();
				while(rs.next())
				{
					textFieldtotal1.setText(rs.getString("total")); 
				}
				pst.close();
				rs.close();
							
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}	
	
	
	public void searchDown() {
		try {
			String string1 = (textFields1.getText().trim().isEmpty())?("''")
					:( "'"+textFields1.getText() + "'");

			String string2 = (textFields2.getText().trim().isEmpty())?("''")
					:( "'"+textFields2.getText() + "'");			
			
			String query= "DROP VIEW IF EXISTS cc";
			PreparedStatement pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();
			
			query= "			CREATE VIEW cc AS\r\n"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
					+ "			 ";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();
			
			query= "DROP VIEW IF EXISTS cc2";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();			
			
			query= "CREATE VIEW cc2 AS\r\n"
					+ "SELECT tb1.id as id, COUNT(tb1.goodid) as cnt,sum(tb1.profit) as profit\r\n"
					+ "FROM cc as tb1\r\n"
					+ "GROUP BY tb1.id";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();					
			
			
			query= "select tb1.id,tb1.cnt,tb4.name,tb4.city,tb4.state,tb4.orderdate,tb1.profit "
					+ "from cc2 as tb1 "
					+ "left join InvoiceList as tb4 on tb1.id = tb4.id"
					+" 			where tb4.orderdate >="+ string1
					+ " 		and tb4.orderdate <= "+ string2
					+" 			order by tb1.id";
		    pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table_2.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
			
			query= "select sum(tb1.profit) as total "
					+ "from cc2 as tb1 "
					+ "left join InvoiceList as tb4 on tb1.id = tb4.id"
					+" 			where tb4.orderdate >="+ string1
					+ " 		and tb4.orderdate <= "+ string2
					+" 			order by tb1.id";			
			
			pst= connection.prepareStatement(query);
			 rs = pst.executeQuery();
				while(rs.next())
				{
					textFieldtotal2.setText(rs.getString("total")); 
				}
				pst.close();
				rs.close();
										
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}	
	
	
	public void searchCustomer() {
		try {
			String string1 = (textFields1.getText().trim().isEmpty())?("''")
					:( "'"+textFields1.getText() + "'");

			String string2 = (textFields2.getText().trim().isEmpty())?("''")
					:( "'"+textFields2.getText() + "'");	
			System.out.println("searchCustomer");
			String query= "DROP VIEW IF EXISTS cc";
			PreparedStatement pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();
			
			query= "			CREATE VIEW cc AS\r\n"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
					+" 			where tb4.orderdate >="+ string1
					+ " 		and tb4.orderdate <= "+ string2
					+ "			 ";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();
			
			query= "DROP VIEW IF EXISTS cc2";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();			
			
			query= 
					 "CREATE VIEW cc2 AS\r\n"
					+ "SELECT tb3.cid,COUNT(tb1.id) as cnt, sum(profit) as profit\r\n"
					+ "from cc as tb1\r\n"
					+ " left join InvoiceList as tb3 on tb1.id = tb3.id "
					+ " GROUP BY tb3.cid";
			pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();					
			
			
			query= "select distinct tb1.cid,tb1.cnt as order_Number,tb3.name,tb3.city,tb3.state,tb1.profit"
					+ " from cc2 as tb1\r\n"
					+ " left join InvoiceList as tb3 on tb1.cid = tb3.cid "
					+ " ORDER BY tb1.profit DESC";
			
		    pst= connection.prepareStatement(query);
		    System.out.println(query);
			ResultSet rs = pst.executeQuery();
			table_3.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
			query= "select sum(tb1.profit) as total "
					+ " from (select distinct cid,profit from cc2) tb1";
		
			System.out.println(query);
			pst= connection.prepareStatement(query);
			 rs = pst.executeQuery();
				while(rs.next())
				{
					textFieldtotal3.setText(rs.getString("total")); 
				}
				pst.close();
				rs.close();	
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}

	public void searchProduct() {
		try {
			String string1 = (textFields1.getText().trim().isEmpty())?("''")
					:( "'"+textFields1.getText() + "'");

			String string2 = (textFields2.getText().trim().isEmpty())?("''")
					:( "'"+textFields2.getText() + "'");				
			String query= "DROP VIEW IF EXISTS cc";
			PreparedStatement pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();
			
			query= "			CREATE VIEW cc AS\r\n"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
					+" 			where tb4.orderdate >="+ string1
					+ " 		and tb4.orderdate <= "+ string2					
					+ "			 ";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();
			
			query= "DROP VIEW IF EXISTS cc2";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();			
			
			query= 	"CREATE VIEW cc2 AS\r\n"
					 + "SELECT tb1.goodid,sum(qty) as qty,sum(tb1.profit) as profit\r\n"
					 + "FROM cc as tb1\r\n"
					 + "GROUP BY tb1.goodid";
			pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();					
			
			
			query= "select tb1.goodid,tb1.qty,tb3.ch_name,tb3.en_name,tb1.profit\r\n"
					+ "from cc2 as tb1\r\n"
					+ " left join InventoryList as tb3 on tb1.goodid = tb3.inv_id\r\n";

		    pst= connection.prepareStatement(query);
		    System.out.println(query);
			ResultSet rs = pst.executeQuery();
			table_4.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			query= "select sum(tb1.profit) as total"
					+ " from cc2 as tb1";


			System.out.println(query);
			pst= connection.prepareStatement(query);
			 rs = pst.executeQuery();
				while(rs.next())
				{
					textFieldtotal4.setText(rs.getString("total")); 
				}
				pst.close();
				rs.close();		
				
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}
	public void pt_up_all() {
		try {

			String query= "			"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n";
				
			PreparedStatement pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			 pst= connection.prepareStatement(query);
//					System.out.println(sql2);
			ArrayList<String[]> arr = new ArrayList<>();
			 rs = pst.executeQuery();
			int index = 0;
			while(rs.next())
			{
				String tt[] = new String[14]; 

				tt[0] = rs.getString("id");
				tt[1] = rs.getString("goodid");
				tt[2] = rs.getString("qty");
				tt[3] = rs.getString("price");
				
				tt[4] = rs.getString("time");
				tt[5] = rs.getString("casecost");
				tt[6] = rs.getString("itemcost");
				tt[7] = rs.getString("unit");
				tt[8] = rs.getString("total");
				tt[9] = rs.getString("csf");
				tt[10] = rs.getString("ch_name");
				tt[11] = rs.getString("en_name");
				tt[12] = rs.getString("orderdate");
				tt[13] = rs.getString("profit");

				index++;
				arr.add(tt);
				 
			}

		String info [][] = (String[][])arr.toArray(new String[0][]);
		for( int i = 0;i< info.length;i++)
		{
			for( int j = 0;j<info[0].length;j++)
			{
				System.out.print(info[i][j] + " ");
			}
			System.out.println();
		}
			query=  "		select	cast( sum(tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) )))) as decimal(10,2))as total \r\n"
				+ "			from saledetail as tb1 \r\n"
				+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
				+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
				+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n";					
		pst= connection.prepareStatement(query);
		 rs = pst.executeQuery();
			while(rs.next())
			{
				tmp_value = (rs.getString("total")); 
			}
			pst.close();
			rs.close();
		
		
			System.out.println(tmp_value);
		gen_xls.save_item( info,tmp_value);
		Runtime.getRuntime().exec(sqlcon.exepath+" "+sqlcon.savepath+"item.xls");
		pst.close();				
		rs.close();		

		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}

	public void pt_up_search() {
		try {
			String string1 = (textFields1.getText().trim().isEmpty())?("''")
					:( "'"+textFields1.getText() + "'");

			String string2 = (textFields2.getText().trim().isEmpty())?("''")
					:( "'"+textFields2.getText() + "'");	
			String query= "			"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
					+" 			where tb4.orderdate >="+ string1
					+ " 		and tb4.orderdate <= "+ string2;			
			
			PreparedStatement pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			 pst= connection.prepareStatement(query);
//					System.out.println(sql2);
			ArrayList<String[]> arr = new ArrayList<>();
			 rs = pst.executeQuery();
			int index = 0;
			while(rs.next())
			{
				String tt[] = new String[14]; 

				tt[0] = rs.getString("id");
				tt[1] = rs.getString("goodid");
				tt[2] = rs.getString("qty");
				tt[3] = rs.getString("price");
				
				tt[4] = rs.getString("time");
				tt[5] = rs.getString("casecost");
				tt[6] = rs.getString("itemcost");
				tt[7] = rs.getString("unit");
				tt[8] = rs.getString("total");
				tt[9] = rs.getString("csf");
				tt[10] = rs.getString("ch_name");
				tt[11] = rs.getString("en_name");
				tt[12] = rs.getString("orderdate");
				tt[13] = rs.getString("profit");

				index++;
				arr.add(tt);
				 
			}

		String info [][] = (String[][])arr.toArray(new String[0][]);
		for( int i = 0;i< info.length;i++)
		{
			for( int j = 0;j<info[0].length;j++)
			{
				System.out.print(info[i][j] + " ");
			}
			System.out.println();
		}


		query=  "		select	cast( sum(tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) )))) as decimal(10,2))as total \r\n"
				+ "			from saledetail as tb1 \r\n"
				+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
				+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
				+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
				+" 			where tb4.orderdate >="+ string1
				+ " 		and tb4.orderdate <= "+ string2
				+" 			order by tb1.id";		
		
		pst= connection.prepareStatement(query);
		 rs = pst.executeQuery();
			while(rs.next())
			{
				tmp_value = (rs.getString("total")); 
			}
			pst.close();
			rs.close();
		
		
		System.out.println(tmp_value);
		gen_xls.save_item( info,tmp_value);
		Runtime.getRuntime().exec(sqlcon.exepath+" "+sqlcon.savepath+"item.xls");		

		
		pst.close();				
		rs.close();		

		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}

	
	
	public void pt_down_all() {
		try {
			
			String query= "DROP VIEW IF EXISTS cc";
			PreparedStatement pst= connection.prepareStatement(query);
//			System.out.println(query);
			pst.execute();
			pst.close();
			
			query= "			CREATE VIEW cc AS\r\n"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
					+ "			 ";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();
			
			query= "DROP VIEW IF EXISTS cc2";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();			
			
			query= "CREATE VIEW cc2 AS\r\n"
					+ "SELECT tb1.id as id, COUNT(tb1.goodid) as cnt,sum(tb1.profit) as profit\r\n"
					+ "FROM cc as tb1\r\n"
					+ "GROUP BY tb1.id";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();					
			
			
			
			query= "select tb1.id,tb1.cnt,tb4.name,tb4.city,tb4.state,tb4.orderdate,tb1.profit "
					+ "from cc2 as tb1 "
					+ "left join InvoiceList as tb4 on tb1.id = tb4.id";
			 pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			 pst= connection.prepareStatement(query);
//					System.out.println(sql2);
			ArrayList<String[]> arr = new ArrayList<>();
			 rs = pst.executeQuery();
			int index = 0;
			while(rs.next())
			{
				String tt[] = new String[7]; 

				tt[0] = rs.getString("id");
				tt[1] = rs.getString("cnt");
				tt[2] = rs.getString("name");
				tt[3] = rs.getString("city");
				tt[4] = rs.getString("state");
				tt[5] = rs.getString("orderdate");
				tt[6] = rs.getString("profit");

				index++;
				arr.add(tt);
				 
			}

		String info [][] = (String[][])arr.toArray(new String[0][]);
		for( int i = 0;i< info.length;i++)
		{
			for( int j = 0;j<info[0].length;j++)
			{
				System.out.print(info[i][j] + " ");
			}
			System.out.println();
		}

	
		query=  "		select	cast( sum(tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) )))) as decimal(10,2))as total \r\n"
				+ "			from saledetail as tb1 \r\n"
				+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
				+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
				+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n";					
		pst= connection.prepareStatement(query);
		 rs = pst.executeQuery();
			while(rs.next())
			{
				tmp_value = rs.getString("total"); 
			}

			System.out.println(tmp_value);
		gen_xls.save_inv( info,tmp_value);
		Runtime.getRuntime().exec(sqlcon.exepath+" "+sqlcon.savepath+"inv.xls");
		pst.close();				
		rs.close();		

		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}
			
	public void pt_down_search() {
		try {
			String string1 = (textFields1.getText().trim().isEmpty())?("''")
					:( "'"+textFields1.getText() + "'");

			String string2 = (textFields2.getText().trim().isEmpty())?("''")
					:( "'"+textFields2.getText() + "'");	
			
			String query= "DROP VIEW IF EXISTS cc";
			PreparedStatement pst= connection.prepareStatement(query);
//			System.out.println(query);
			pst.execute();
			pst.close();
			
			query= "			CREATE VIEW cc AS\r\n"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n";

			
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();
			
			query= "DROP VIEW IF EXISTS cc2";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();			
			
			query= "CREATE VIEW cc2 AS\r\n"
					+ "SELECT tb1.id as id, COUNT(tb1.goodid) as cnt,sum(tb1.profit) as profit\r\n"
					+ "FROM cc as tb1\r\n"
					+ "GROUP BY tb1.id";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();					
			
			
			query= "select tb1.id,tb1.cnt,tb4.name,tb4.city,tb4.state,tb4.orderdate,tb1.profit "
					+ "from cc2 as tb1 "
					+ "left join InvoiceList as tb4 on tb1.id = tb4.id";
			 pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			 pst= connection.prepareStatement(query);
//					System.out.println(sql2);
			ArrayList<String[]> arr = new ArrayList<>();
			 rs = pst.executeQuery();
			int index = 0;
			while(rs.next())
			{
				String tt[] = new String[7]; 

				tt[0] = rs.getString("id");
				tt[1] = rs.getString("cnt");
				tt[2] = rs.getString("name");
				tt[3] = rs.getString("city");
				tt[4] = rs.getString("state");
				tt[5] = rs.getString("orderdate");
				tt[6] = rs.getString("profit");

				index++;
				arr.add(tt);
				 
			}

		String info [][] = (String[][])arr.toArray(new String[0][]);
		for( int i = 0;i< info.length;i++)
		{
			for( int j = 0;j<info[0].length;j++)
			{
				System.out.print(info[i][j] + " ");
			}
			System.out.println();
		}
		query= "select sum(tb1.profit) as total "
				+ "from cc2 as tb1 "
				+ "left join InvoiceList as tb4 on tb1.id = tb4.id"
				+" 			where tb4.orderdate >="+ string1
				+ " 		and tb4.orderdate <= "+ string2
				+" 			order by tb1.id";					
		pst= connection.prepareStatement(query);
		 rs = pst.executeQuery();
			while(rs.next())
			{
				tmp_value = rs.getString("total"); 
			}

			System.out.println(tmp_value);
		gen_xls.save_inv( info,tmp_value);
		Runtime.getRuntime().exec(sqlcon.exepath+" "+sqlcon.savepath+"inv.xls");
		pst.close();				
		rs.close();		


		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}			

	public void pt_Customer_all() {
		try {
			
			String query= "DROP VIEW IF EXISTS cc";
			PreparedStatement pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();
			
			query= "			CREATE VIEW cc AS\r\n"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
					+ "			 ";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();
			
			query= "DROP VIEW IF EXISTS cc2";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();			
			
			query= 
					 "CREATE VIEW cc2 AS\r\n"
					+ "SELECT tb3.cid as cid,COUNT(tb1.id) as cnt, sum(profit) as profit\r\n"
					+ "from cc as tb1\r\n"
					+ " left join InvoiceList as tb3 on tb1.id = tb3.id\r\n"
					+ "GROUP BY tb3.cid";
			pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();					
			

			query= " select distinct tb1.cid,tb1.cnt as order_Number,tb3.name,tb3.city,tb3.state,tb1.profit"
					+ " from cc2 as tb1\r\n"
					+ " left join InvoiceList as tb3 on tb1.cid = tb3.cid "
					+ " ORDER BY tb1.profit DESC";
			
			 pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			 pst= connection.prepareStatement(query);
//					System.out.println(sql2);
			ArrayList<String[]> arr = new ArrayList<>();
			 rs = pst.executeQuery();
			int index = 0;
			while(rs.next())
			{
				String tt[] = new String[6]; 
				tt[0] = rs.getString("cid");
				tt[1] = rs.getString("order_Number");
				tt[2] = rs.getString("name");
				tt[3] = rs.getString("city");
				tt[4] = rs.getString("state");
				tt[5] = rs.getString("profit");
				index++;
				arr.add(tt);
				 
			}

		String info [][] = (String[][])arr.toArray(new String[0][]);
		for( int i = 0;i< info.length;i++)
		{
			for( int j = 0;j<info[0].length;j++)
			{
				System.out.print(info[i][j] + " ");
			}
			System.out.println();
		}

			query= "select sum(tb1.profit) as total "
				+ " from (select distinct cid,profit from cc2) tb1";


			System.out.println(query);
			pst= connection.prepareStatement(query);
			rs = pst.executeQuery();
			while(rs.next())
			{
			tmp_value = (rs.getString("total")); 
			}

			System.out.println(tmp_value);		
		
		
			gen_xls.save_customer( info,tmp_value);
			Runtime.getRuntime().exec(sqlcon.exepath+" "+sqlcon.savepath+"customer_view.xls");
		pst.close();				
		rs.close();		

				
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}	
	

	public void pt_Customer_search() {
		try {
			String string1 = (textFields1.getText().trim().isEmpty())?("''")
					:( "'"+textFields1.getText() + "'");

			String string2 = (textFields2.getText().trim().isEmpty())?("''")
					:( "'"+textFields2.getText() + "'");				
			String query= "DROP VIEW IF EXISTS cc";
			PreparedStatement pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();
			
			query= "			CREATE VIEW cc AS\r\n"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
					+" 			where tb4.orderdate >="+ string1
					+ " 		and tb4.orderdate <= "+ string2;
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();
			
			query= "DROP VIEW IF EXISTS cc2";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();			
			
			query= 
					 "CREATE VIEW cc2 AS\r\n"
					+ "SELECT tb3.cid as cid,COUNT(tb1.id) as cnt, sum(profit) as profit\r\n"
					+ "from cc as tb1\r\n"
					+ " left join InvoiceList as tb3 on tb1.id = tb3.id\r\n"
					+ "GROUP BY tb3.cid";
			pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();					
			

			query= " select distinct tb1.cid,tb1.cnt as order_Number,tb3.name,tb3.city,tb3.state,tb1.profit"
					+ " from cc2 as tb1\r\n"
					+ " left join InvoiceList as tb3 on tb1.cid = tb3.cid "
					+ " ORDER BY tb1.profit DESC";
			
			 pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			 pst= connection.prepareStatement(query);
//					System.out.println(sql2);
			ArrayList<String[]> arr = new ArrayList<>();
			 rs = pst.executeQuery();
			int index = 0;
			while(rs.next())
			{
				String tt[] = new String[6]; 
				tt[0] = rs.getString("cid");
				tt[1] = rs.getString("order_Number");
				tt[2] = rs.getString("name");
				tt[3] = rs.getString("city");
				tt[4] = rs.getString("state");
				tt[5] = rs.getString("profit");
				index++;
				arr.add(tt);
				 
			}

		String info [][] = (String[][])arr.toArray(new String[0][]);
		for( int i = 0;i< info.length;i++)
		{
			for( int j = 0;j<info[0].length;j++)
			{
				System.out.print(info[i][j] + " ");
			}
			System.out.println();
		}

		query= "select sum(tb1.profit) as total "
		+ " from (select distinct cid,profit from cc2) tb1";
		
		System.out.println(query);
		pst= connection.prepareStatement(query);
		rs = pst.executeQuery();
		while(rs.next())
		{
			tmp_value = (rs.getString("total")); 
		}
		
		System.out.println(tmp_value);		
		
		gen_xls.save_customer( info,tmp_value);
		Runtime.getRuntime().exec(sqlcon.exepath+" "+sqlcon.savepath+"customer_view.xls");
		pst.close();				
		rs.close();		

		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}	
	public void pt_Product_all() {
		try {
			
			String query= "DROP VIEW IF EXISTS cc";
			PreparedStatement pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();
			
			query= "			CREATE VIEW cc AS\r\n"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
					+ "			 ";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();
			
			query= "DROP VIEW IF EXISTS cc2";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();			
			
			query= 	"CREATE VIEW cc2 AS\r\n"
					 + "SELECT tb1.goodid,sum(tb1.qty) as qty,sum(tb1.profit) as profit\r\n"
					 + "FROM cc as tb1\r\n"
					 + "GROUP BY tb1.goodid";
			pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();					
			
			
			query= "select tb1.goodid,tb1.qty,tb3.ch_name,tb3.en_name,tb1.profit\r\n"
					+ "from cc2 as tb1\r\n"
					+ " left join InventoryList as tb3 on tb1.goodid = tb3.inv_id\r\n"
					+ " ORDER BY tb1.profit DESC";
			
			 pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			 pst= connection.prepareStatement(query);
//					System.out.println(sql2);
			ArrayList<String[]> arr = new ArrayList<>();
			 rs = pst.executeQuery();
			int index = 0;
			while(rs.next())
			{
				String tt[] = new String[5]; 
				tt[0] = rs.getString("goodid");
				tt[1] = rs.getString("qty");
				tt[2] = rs.getString("ch_name");
				tt[3] = rs.getString("en_name");

				tt[4] = rs.getString("profit");
				index++;
				arr.add(tt);
				 
			}

		String info [][] = (String[][])arr.toArray(new String[0][]);
		for( int i = 0;i< info.length;i++)
		{
			for( int j = 0;j<info[0].length;j++)
			{
				System.out.print(info[i][j] + " ");
			}
			System.out.println();
		}
		query= "select sum(tb1.profit) as total"
				+ " from cc2 as tb1";
		System.out.println(query);
		pst= connection.prepareStatement(query);
		 rs = pst.executeQuery();
			while(rs.next())
			{
				tmp_value = (rs.getString("total")); 
			}

			System.out.println(tmp_value);		
		
		gen_xls.save_prod( info,tmp_value);
		Runtime.getRuntime().exec(sqlcon.exepath+" "+sqlcon.savepath+"product_view.xls");
		pst.close();				
		rs.close();		

		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}		
	
	public void pt_Product_search() {
		try {
			String string1 = (textFields1.getText().trim().isEmpty())?("''")
					:( "'"+textFields1.getText() + "'");

			String string2 = (textFields2.getText().trim().isEmpty())?("''")
					:( "'"+textFields2.getText() + "'");			
			
			String query= "DROP VIEW IF EXISTS cc";
			PreparedStatement pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();
			
			query= "			CREATE VIEW cc AS\r\n"
					+ "			select tb1.id,tb1.goodid,tb1.qty,tb1.price,\r\n"
					+ "			tb3.itempercase as time,tb2.cost as casecost,\r\n"
					+ "			cast((tb2.cost/tb3.itempercase)as decimal(10,2)) as itemcost,\r\n"
					+ "			tb1.unit,tb1.total,  tb1.csf, tb3.ch_name,tb3.en_name,tb4.orderdate, \r\n"
					+ "			cast( tb1.qty*(tb1.price - IF(tb1.csf=1,tb2.cost,  ((tb2.cost/tb3.itempercase) ))) as decimal(10,2))as profit \r\n"
					+ "			from saledetail as tb1 \r\n"
					+ "			 left join buylist as tb2 on tb1.goodid = tb2.invid \r\n"
					+ "			 left join InventoryList as tb3 on tb1.goodid = tb3.inv_id \r\n"
					+ "			 left join InvoiceList as tb4 on tb1.id = tb4.id \r\n"
					+" 			where tb4.orderdate >="+ string1
					+ " 		and tb4.orderdate <= "+ string2;
			
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();
			
			query= "DROP VIEW IF EXISTS cc2";
			pst= connection.prepareStatement(query);
			pst.execute();
			pst.close();			
			
			query= 	"CREATE VIEW cc2 AS\r\n"
					 + "SELECT tb1.goodid,sum(tb1.qty) as qty,sum(tb1.profit) as profit\r\n"
					 + "FROM cc as tb1\r\n"
					 + "GROUP BY tb1.goodid";
			pst= connection.prepareStatement(query);
			System.out.println(query);
			pst.execute();
			pst.close();					
			
			
			query= "select tb1.goodid,tb1.qty,tb3.ch_name,tb3.en_name,tb1.profit\r\n"
					+ "from cc2 as tb1\r\n"
					+ " left join InventoryList as tb3 on tb1.goodid = tb3.inv_id\r\n"
					+ " ORDER BY tb1.profit DESC";
			
			 pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			 pst= connection.prepareStatement(query);
//					System.out.println(sql2);
			ArrayList<String[]> arr = new ArrayList<>();
			 rs = pst.executeQuery();
			int index = 0;
			while(rs.next())
			{
				String tt[] = new String[5]; 
				tt[0] = rs.getString("goodid");
				tt[1] = rs.getString("qty");
				tt[2] = rs.getString("ch_name");
				tt[3] = rs.getString("en_name");

				tt[4] = rs.getString("profit");
				index++;
				arr.add(tt);
				 
			}

		String info [][] = (String[][])arr.toArray(new String[0][]);
		for( int i = 0;i< info.length;i++)
		{
			for( int j = 0;j<info[0].length;j++)
			{
				System.out.print(info[i][j] + " ");
			}
			System.out.println();
		}
		query= "select sum(tb1.profit) as total"
				+ " from cc2 as tb1";


		System.out.println(query);
		pst= connection.prepareStatement(query);
		 rs = pst.executeQuery();
			while(rs.next())
			{
				tmp_value = (rs.getString("total")); 
			}

			System.out.println(tmp_value);
		
		
		gen_xls.save_prod( info,tmp_value);
		Runtime.getRuntime().exec(sqlcon.exepath+" "+sqlcon.savepath+"product_view.xls");
		pst.close();				
		rs.close();		
			
			
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}			
	
	public ad_profit() {
		connection = sqlcon.db();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1910, 722);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("load");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				refreshUp();
			}
		});
		
		JButton btnNewButton_1_1_2_1 = new JButton("Printall");
		btnNewButton_1_1_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pt_Product_all();
			}
		});
		btnNewButton_1_1_2_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_1_2_1.setBounds(1556, 567, 89, 23);
		contentPane.add(btnNewButton_1_1_2_1);
		btnNewButton.setBounds(57, 290, 89, 23);
		contentPane.add(btnNewButton);
		
		textFields1 = new JTextField();
		textFields1.setFont(new Font("SimSun", Font.PLAIN, 16));
		textFields1.setBounds(795, 303, 86, 20);
		contentPane.add(textFields1);
		textFields1.setColumns(10);
		
		textFields2 = new JTextField();
		textFields2.setFont(new Font("SimSun", Font.PLAIN, 16));
		textFields2.setBounds(940, 303, 108, 20);
		contentPane.add(textFields2);
		textFields2.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("search");
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchUp();
				
			}
		});
		btnNewButton_1.setBounds(261, 290, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(31, 41, 1844, 237);
		contentPane.add(scrollPane);
		
		table_1 = new JTable();
		table_1.setFont(new Font("SimSun", Font.PLAIN, 17));
		scrollPane.setViewportView(table_1);
		
		JLabel lblNewLabel = new JLabel("From");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(724, 303, 61, 17);
		contentPane.add(lblNewLabel);
		
		JLabel lblTo = new JLabel("To");
		lblTo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblTo.setBounds(894, 303, 36, 17);
		contentPane.add(lblTo);
		textFields2.setText(Preview.getTime());
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(31, 367, 596, 189);
		contentPane.add(scrollPane_1);
		
		table_2 = new JTable();
		table_2.setFont(new Font("SimSun", Font.PLAIN, 17));
		scrollPane_1.setViewportView(table_2);
		
		JButton btnLoaddown = new JButton("load");
		btnLoaddown.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnLoaddown.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				refreshdown();
			}
		});
		btnLoaddown.setBounds(31, 567, 89, 23);
		contentPane.add(btnLoaddown);
		
		JButton btnNewButton_1_1 = new JButton("Printall");
		btnNewButton_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pt_up_all();
			}
		});
		btnNewButton_1_1.setBounds(360, 290, 108, 23);
		contentPane.add(btnNewButton_1_1);
		
		JButton btnNewButton_1_1_1 = new JButton("Printsearch");
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pt_up_search();
			}
		});
		btnNewButton_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_1_1.setBounds(478, 290, 143, 23);
		contentPane.add(btnNewButton_1_1_1);
		
		JButton btnNewButton_1_2 = new JButton("search");
		btnNewButton_1_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchDown();
				
			}
		});
		btnNewButton_1_2.setBounds(229, 567, 89, 23);
		contentPane.add(btnNewButton_1_2);
		
		JButton btnNewButton_1_1_2 = new JButton("Printall");
		btnNewButton_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				pt_down_all();
			}
		});
		btnNewButton_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_1_2.setBounds(328, 567, 89, 23);
		contentPane.add(btnNewButton_1_1_2);
		
		JButton btnNewButton_1_1_1_1 = new JButton("Printsearch");
		btnNewButton_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pt_down_search();
				
			}
		});
		btnNewButton_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_1_1_1.setBounds(427, 567, 125, 23);
		contentPane.add(btnNewButton_1_1_1_1);
		
		JButton btnNewButton_1_3 = new JButton("find-");
		btnNewButton_1_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				findUpNegative();
			}
		});
		btnNewButton_1_3.setBounds(162, 290, 89, 23);
		contentPane.add(btnNewButton_1_3);
		
		JButton btnNewButton_1_3_1 = new JButton("find-");
		btnNewButton_1_3_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				findDownNegative();
			}
		});
		btnNewButton_1_3_1.setBounds(130, 567, 89, 23);
		contentPane.add(btnNewButton_1_3_1);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(656, 361, 573, 196);
		contentPane.add(scrollPane_2);
		
		table_3 = new JTable();
		table_3.setFont(new Font("SimSun", Font.PLAIN, 17));
		scrollPane_2.setViewportView(table_3);
		
		JButton btnLoaddown_1 = new JButton("load");
		btnLoaddown_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnLoaddown_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				refreshCustomer();
			}
		});
		btnLoaddown_1.setBounds(666, 569, 89, 23);
		contentPane.add(btnLoaddown_1);
		
		JButton btnNewButton_1_3_1_1 = new JButton("find-");
		btnNewButton_1_3_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_3_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				findCustomerNegative();
			}
		});
		btnNewButton_1_3_1_1.setBounds(765, 569, 89, 23);
		contentPane.add(btnNewButton_1_3_1_1);
		
		JButton btnNewButton_1_1_3 = new JButton("Printall");
		btnNewButton_1_1_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pt_Customer_all();
			}
		});
		btnNewButton_1_1_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_1_3.setBounds(1005, 567, 89, 23);
		contentPane.add(btnNewButton_1_1_3);
		
		JButton btnNewButton_1_1_1_2 = new JButton("Printsearch");
		btnNewButton_1_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pt_Customer_search();
			}
		});
		btnNewButton_1_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_1_1_2.setBounds(1104, 567, 125, 23);
		contentPane.add(btnNewButton_1_1_1_2);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(41, 601, 2, 2);
		contentPane.add(scrollPane_3);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(1249, 361, 626, 195);
		contentPane.add(scrollPane_4);
		
		table_4 = new JTable();
		table_4.setFont(new Font("SimSun", Font.PLAIN, 17));
		scrollPane_4.setViewportView(table_4);
		
		JButton btnLoaddown_2 = new JButton("load");
		btnLoaddown_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnLoaddown_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				refreshProduct();
				
			}
		});
		btnLoaddown_2.setBounds(1259, 567, 89, 23);
		contentPane.add(btnLoaddown_2);
		
		JButton btnNewButton_1_3_1_2 = new JButton("find-");
		btnNewButton_1_3_1_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_3_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				findProductNegtive();
			}
		});
		btnNewButton_1_3_1_2.setBounds(1358, 567, 89, 23);
		contentPane.add(btnNewButton_1_3_1_2);
		
		JButton btnNewButton_1_2_1 = new JButton("search");
		btnNewButton_1_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchProduct();
			}
		});
		btnNewButton_1_2_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_2_1.setBounds(1457, 567, 89, 23);
		contentPane.add(btnNewButton_1_2_1);
		
		JButton btnNewButton_1_1_1_1_1 = new JButton("Printsearch");
		btnNewButton_1_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pt_Product_search();
			}
		});
		btnNewButton_1_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_1_1_1_1.setBounds(1655, 567, 125, 23);
		contentPane.add(btnNewButton_1_1_1_1_1);
		
		JButton btnNewButton_1_2_1_1 = new JButton("search");
		btnNewButton_1_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				searchCustomer();
			}
		});
		btnNewButton_1_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_2_1_1.setBounds(868, 567, 89, 23);
		contentPane.add(btnNewButton_1_2_1_1);
		
		textFieldtotal1 = new JTextField();
		textFieldtotal1.setFont(new Font("SimSun", Font.PLAIN, 20));
		textFieldtotal1.setBounds(1232, 287, 116, 30);
		contentPane.add(textFieldtotal1);
		textFieldtotal1.setColumns(10);
		
		JLabel lblTotal = new JLabel("Total Profit");
		lblTotal.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblTotal.setBounds(1121, 290, 108, 23);
		contentPane.add(lblTotal);
		
		JLabel lblEachItem = new JLabel("item detail");
		lblEachItem.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEachItem.setBounds(41, 7, 108, 23);
		contentPane.add(lblEachItem);
		
		JLabel lblEachInvoice = new JLabel(" Invoice");
		lblEachInvoice.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEachInvoice.setBounds(38, 333, 108, 23);
		contentPane.add(lblEachInvoice);
		
		JLabel lblEachCustomer = new JLabel(" Customer");
		lblEachCustomer.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEachCustomer.setBounds(656, 327, 151, 23);
		contentPane.add(lblEachCustomer);
		
		JLabel lblEachProduct = new JLabel("Product");
		lblEachProduct.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEachProduct.setBounds(1253, 328, 151, 23);
		contentPane.add(lblEachProduct);
		
		JLabel lblTotal_1 = new JLabel("Total Profit");
		lblTotal_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblTotal_1.setBounds(384, 613, 108, 23);
		contentPane.add(lblTotal_1);
		
		JLabel lblTotal_2 = new JLabel("Total Profit");
		lblTotal_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblTotal_2.setBounds(940, 620, 108, 23);
		contentPane.add(lblTotal_2);
		
		JLabel lblTotal_3 = new JLabel("Total Profit");
		lblTotal_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblTotal_3.setBounds(1591, 620, 108, 23);
		contentPane.add(lblTotal_3);
		
		textFieldtotal4 = new JTextField();
		textFieldtotal4.setFont(new Font("SimSun", Font.PLAIN, 20));
		textFieldtotal4.setColumns(10);
		textFieldtotal4.setBounds(1712, 617, 116, 30);
		contentPane.add(textFieldtotal4);
		
		textFieldtotal3 = new JTextField();
		textFieldtotal3.setFont(new Font("SimSun", Font.PLAIN, 20));
		textFieldtotal3.setColumns(10);
		textFieldtotal3.setBounds(1044, 617, 116, 30);
		contentPane.add(textFieldtotal3);
		
		textFieldtotal2 = new JTextField();
		textFieldtotal2.setFont(new Font("SimSun", Font.PLAIN, 20));
		textFieldtotal2.setColumns(10);
		textFieldtotal2.setBounds(489, 606, 116, 30);
		contentPane.add(textFieldtotal2);
		refreshUp();
		refreshdown();
		refreshCustomer();
		refreshProduct();
	}
}
