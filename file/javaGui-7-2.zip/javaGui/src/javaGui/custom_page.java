package javaGui;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTextPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;


public class custom_page extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField textFieldSearch1;
	private JTextField textFieldCity;
	private JTextField textFieldState;
	private JTextField textFieldPho;
	private JTextField textFieldName;
	private JTable table_1;
	private JTextField textFieldqty;
	private JTextField textFieldSearch;
	private JTextField textFieldAddr;
	private JTextField textFieldTax;
	private JTextField textFieldZip;
	String EID = "";
	String GID = "";
	String temp = "";
	String innerid = "";
	String temp2[] = new String [20];
	String temp4[] = new String [20];
	String info [][];
	String temp3 = "";
	String total ="";
	String Number  ="";
	
	String orderNo = sqlcon.orderNO;
//	char temp2[][] = new char [10][100];
	private JTextField textFieldch;
	private JTextField textFielden;
	private JTextField textFieldprice;
	private JTextField textFieldtaxable;
	String tableC = "customlist";
	String tableO = "revorderList";
	String tableI = "InventoryList";

	/**
	 * Launch the application.
	 */
	Connection connection = null;
	private JTable table_3;
	private JTable table_4;
	private JTextField textFielditemunit;
	private JTextField textFieldterm;
	private JTextField textFieldpo;
	private JTextField textFieldcid;
	private JTextField textFieldodate;
	private JTable table_2;
	private JTextField textField_cati;
	private JTextField textField_history;
	private JTextField textField_itnumber;
	private JTextField textField_his_id;
	private JTextField textField_remark;
	private JTextField textField_innerid;
	private JTextField textFieldcsprice;
	private JTextField textFieldcsunit;
	private JTextField textFieldp2;
	private JTextField textFieldu2;
	private JTextField textFieldq2;
	private JTextField textFieldcurrent;
	private JTextField textFieldsaveflag;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					custom_page frame = new custom_page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	   public static String getSysTime()
	   {
	        SimpleDateFormat sdf = new SimpleDateFormat();// ��ʽ��ʱ�� 
	        
//	        sdf.applyPattern("MM/dd/yyyy");
	        
	        sdf.applyPattern("yyyy-MM-dd");// aΪam/pm�ı��  
	        Date date = new Date();// ��ȡ��ǰʱ�� 
	        
	        String shijian  = sdf.format(date);
	        System.out.println(shijian); 
	        return shijian;
	   }
		public void cal_sub() {
		try {

			String query = "select inner_id,round((qty*price+ qty*price*taxrate),2) as res from " +orderNo;
			System.out.println(query);
			PreparedStatement pst2= connection.prepareStatement(query);

			ResultSet rs2 = pst2.executeQuery();
			ArrayList<String[]> arr = new ArrayList<>();
				while(rs2.next())
				{
					String tt[] = new String[2];
					total=rs2.getString("res");
					System.out.println(total);
					tt[0] = rs2.getString("inner_id");
					tt[1] = total;
					arr.add(tt);
				}
				pst2.close();
			String info [][] = (String[][])arr.toArray(new String[0][]);
			for( int i = 0;i< info.length;i++)
			{

	            String sql = "update "+orderNo 
						  +" set total = " +info[i][1]
							 +" where inner_id = "+info[i][0];
	            System.out.println(sql);
	            PreparedStatement pst= connection.prepareStatement(sql);
	            pst.executeUpdate();
	            pst.close();
			}
			
			updateGroundTable();
			
			}
			catch (Exception e2) 
			{
				e2.printStackTrace();				
			}								
		}
		
	public void updateInvTable() {
		try {
			
//			String query= "select  tb1.inv_id, tb1.taxable, tb1.CATEGORY, "
//					+"tb1.en_name ,tb1.itemunit,tb1.itemprice "
//					+"from InventoryList as tb1 "
//					+ "left join catelist as tb2 on tb1.CATEGORY = tb2.cateid"
//					+ " order by tb1.CATEGORY ";	
//			System.out.println(query); 
			String query="select * from InventoryList";
				PreparedStatement pst= connection.prepareStatement(query);
				ResultSet rs = pst.executeQuery();
				table_3.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
	
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}

	public void updateGroundTable() {
		try {
			


			String sql2= "select * "
					+ "from " +orderNo+ "  "
					+ " order by cati ";

				PreparedStatement pst= connection.prepareStatement(sql2);
				ResultSet rs = pst.executeQuery();
				table_4.setModel(DbUtils.resultSetToTableModel(rs));

			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}
	
	public void find_table_order() {
		try {	
			String query= "select TABLE_NAME,UPDATE_TIME from information_schema.TABLES where TABLE_SCHEMA='runoob' and TABLE_NAME LIKE '%temp%' order by UPDATE_TIME limit 1";
			
			
			PreparedStatement pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();

			while(rs.next())
			{

				orderNo=rs.getString("id").toString();

			}

			System.out.println(orderNo);
			//get all information to display
			table.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}
	}
	
	
	public void update_itemnumber() 
	{
		try {
			String sql= "select max(inner_id) as res from "  +orderNo;
			System.out.println(sql);
			PreparedStatement pst2= connection.prepareStatement(sql);
			
			ResultSet rs = pst2.executeQuery();
			while(rs.next())
			{
				innerid=rs.getString("res");
			}
			System.out.println(innerid);
			textField_itnumber.setText((innerid=="null")?"0":innerid);
			
			
			
			updateGroundTable();
			
		}
		catch (Exception e2) 
		{
			e2.printStackTrace();				
		}			
	}
	public void freshLeftup() 
	{
		try {
			
			String	query= " select tb1.inv_id,tb1.taxable, tb2.ch_name,tb2.en_name,"
					+ " tb1.bigu,tb1.smallu,tb1.bigp,tb1.smallp  "
					+ "	from aclist1 as tb1 "
					+ "	left join InventoryList as tb2 on tb1.inv_id = tb2.inv_id\r\n"
					+ "	where tb1.cid =" + textFieldcid.getText();		
			
				
			PreparedStatement pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			 
			 System.out.println(query);
			table_2.setModel(DbUtils.resultSetToTableModel(rs));
				}
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}	
	}
	
	public void updateCustomtable() {
		try {
			String query= "select id,name,city,tax from "+tableC;
			PreparedStatement pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			//get all information to display
			table.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();

			
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		
	}
	/**
	 * Create the frame.
	 */
	public custom_page() {
		connection = sqlcon.db();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1920, 1000);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(41, 10, 1853, 917);
		contentPane.add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Customer", null, panel, null);
		panel.setLayout(null);
		
		textFieldSearch1 = new JTextField();
		textFieldSearch1.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldSearch1.setBounds(44, 49, 298, 26);
		panel.add(textFieldSearch1);
		textFieldSearch1.setColumns(10);
		
//		 int input =JOptionPane.showConfirmDialog(null, "Create an invoice number "+Number+"?");
//		 if(input==0)
//		 {
//		 }

		//���� id +1
		try {
			
			String sql = "select * from InvoiceList";

			PreparedStatement pst= connection.prepareStatement(sql);

			ResultSet rs = pst.executeQuery();
				if(rs.next())
				{
					
					//���� id +1
		
						
						String sql2 = "select max(id) from InvoiceList ";
						PreparedStatement pst2= connection.prepareStatement(sql2);

						ResultSet rs2 = pst2.executeQuery();
	  					while(rs2.next())
	  					{
	  						temp3=rs2.getString("max(id)");
	  					}
						pst2.close();
					} 
					else {
						temp3="0";
					}
				
				
				// �����  invovice ��
				 Number = Integer.toString(Integer.parseInt(temp3)+1);
				 System.out.println(Number);		
		 
				
				}
				catch (Exception e2) {
					e2.printStackTrace();
				}		




		
		
		JButton btnSearch = new JButton("Name");
		btnSearch.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {

					String string1 = (textFieldSearch1.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldSearch1.getText() + "%'");
				
					String query = "select distinct id,name,city,tax  from "+ tableC
							+ " WHERE name LIKE "
							+ string1;
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
//					table_2.getColumnModel().getColumn(0).setPreferredWidth(80);
					table.getColumnModel().getColumn(0).setPreferredWidth(55);
					table.getColumnModel().getColumn(1).setPreferredWidth(500);
					table.getColumnModel().getColumn(2).setPreferredWidth(200);
					table.getColumnModel().getColumn(3).setPreferredWidth(80);
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
								
				
				
			}
		});
		btnSearch.setBounds(352, 32, 93, 23);
		panel.add(btnSearch);
		
		JButton btnSelect = new JButton("SELECT");
		btnSelect.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnSelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					textFieldsaveflag.setText("0");
					textFieldcurrent.setText(Number);
					textField_itnumber.setText("0");
					String query= "select * from "+tableC
							+ " where id = " + temp;
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();

					while(rs.next())
					{
						temp2[0] = (rs.getString("id"));
						temp2[1] = (rs.getString("name"));
						temp2[6] = (rs.getString("phone"));
  						
  						temp2[2] = (rs.getString("addr"));
  						temp2[3] = (rs.getString("city"));
  						temp2[4] = (rs.getString("state"));
  						temp2[5] = (rs.getString("zip"));					
  						temp2[7] = (rs.getString("tax"));
  						temp2[9] = textFieldpo.getText() ;						
  						
					}		

					freshLeftup();

//					for(int i = 1; i<8;i++)
//					{
//			
//						System.out.println(String.valueOf(temp2[i]));
//					}
					for(String word: temp2)
					{
						System.out.println(word);
					}
					 query= "Truncate Table  "+orderNo ;

					 pst= connection.prepareStatement(query);

//					System.out.println(query);	

					pst.execute();
	
					pst.close();
//					update_itemnumber();
					updateGroundTable();
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
				
				
			}
		});
		btnSelect.setBounds(905, 350, 107, 23);
		panel.add(btnSelect);
		
		textFieldCity = new JTextField();
		textFieldCity.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldCity.setBounds(140, 539, 171, 26);
		panel.add(textFieldCity);
		textFieldCity.setColumns(10);
		
		textFieldState = new JTextField();
		textFieldState.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldState.setColumns(10);
		textFieldState.setBounds(366, 539, 66, 26);
		panel.add(textFieldState);
		
		textFieldPho = new JTextField();
		textFieldPho.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldPho.setColumns(10);
		textFieldPho.setBounds(540, 582, 181, 26);
		panel.add(textFieldPho);
		
		textFieldName = new JTextField();
		textFieldName.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldName.setColumns(10);
		textFieldName.setBounds(122, 582, 310, 26);
		panel.add(textFieldName);
		
		JLabel lblNewLabel = new JLabel("City");
		lblNewLabel.setBounds(58, 544, 54, 15);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("State");
		lblNewLabel_1.setBounds(321, 544, 54, 15);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Address");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_2.setBounds(58, 496, 73, 22);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Name");
		lblNewLabel_3.setBounds(58, 587, 54, 15);
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 18));
		panel.add(lblNewLabel_3);
		
		JButton btnLoad = new JButton("LOAD");
		btnLoad.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnLoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query= "select id,name,city,tax from "+tableC;
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
				updateCustomtable();
			}
		});
		btnLoad.setBounds(915, 383, 93, 23);
		panel.add(btnLoad);
		
		JLabel lblNewLabel_2_1 = new JLabel("Zip:");
		lblNewLabel_2_1.setBounds(476, 544, 54, 15);
		lblNewLabel_2_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		panel.add(lblNewLabel_2_1);
		
		textFieldAddr = new JTextField();
		textFieldAddr.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldAddr.setColumns(10);
		textFieldAddr.setBounds(141, 496, 171, 26);
		panel.add(textFieldAddr);
		
		textFieldTax = new JTextField();
		textFieldTax.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldTax.setColumns(10);
		textFieldTax.setBounds(383, 496, 66, 26);
		panel.add(textFieldTax);
		
		JLabel lblTax = new JLabel("TAX");
		lblTax.setBounds(335, 500, 54, 15);
		lblTax.setFont(new Font("Times New Roman", Font.BOLD, 18));
		panel.add(lblTax);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Phone");
		lblNewLabel_2_1_1.setBounds(476, 587, 54, 15);
		lblNewLabel_2_1_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		panel.add(lblNewLabel_2_1_1);
		
		textFieldZip = new JTextField();
		textFieldZip.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldZip.setColumns(10);
		textFieldZip.setBounds(553, 539, 171, 26);
		panel.add(textFieldZip);
		
		JScrollPane scrollPane = new JScrollPane();

		
				scrollPane.setBounds(32, 120, 863, 286);
				panel.add(scrollPane);
				
				table = new JTable();
				table.setFont(new Font("SimSun", Font.PLAIN, 17));
				table.addMouseListener(new MouseAdapter() {
					@Override  //For user tab
					public void mouseClicked(MouseEvent e) {
						
						
						
						
  				try {
//					System.out.println("Hi");
							int row = table.getSelectedRow();
							String EID = (table.getModel().getValueAt(row,0)).toString();
							System.out.println(EID);
							String query= "select * from "+tableC
									+ " where id = '"+EID +"' ";
							PreparedStatement pst= connection.prepareStatement(query);

							ResultSet rs = pst.executeQuery();
							while(rs.next())
							{

								temp=rs.getString("id").toString();
//  						textFieldID.setText(rs.getString("id"));


 						textFieldName.setText(rs.getString("name"));
  						textFieldPho.setText(rs.getString("phone")); 
  						
 						textFieldAddr.setText(rs.getString("addr"));
  						textFieldCity.setText(rs.getString("city"));  	
  						textFieldState.setText(rs.getString("state"));
  						textFieldZip.setText(rs.getString("zip")); 	 						
  						textFieldTax.setText(rs.getString("tax"));
  						textFieldcid.setText(temp);  						
							}
	
							System.out.println(temp);
						pst.close();
						rs.close();				
							
						} 
						catch (Exception e2) 
						{
							e2.printStackTrace();				
						}			

					}
				});
				scrollPane.setViewportView(table);
				
				JButton btnSeachCity = new JButton("City");
				btnSeachCity.setFont(new Font("Tahoma", Font.PLAIN, 18));

				btnSeachCity.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						try {

							String string1 = (textFieldSearch1.getText().trim().isEmpty())?("'%'")
									:( "'%"+textFieldSearch1.getText() + "%'");
						
							String query = "select distinct id,name,city,tax  from "+ tableC
									+ " WHERE city LIKE "
									+ string1;
							System.out.println(query);
							PreparedStatement pst= connection.prepareStatement(query);
							ResultSet rs = pst.executeQuery();
							//get all information to display
							table.setModel(DbUtils.resultSetToTableModel(rs));
							pst.close();
							rs.close();
							table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
//							table_2.getColumnModel().getColumn(0).setPreferredWidth(80);
							table.getColumnModel().getColumn(0).setPreferredWidth(55);
							table.getColumnModel().getColumn(1).setPreferredWidth(500);
							table.getColumnModel().getColumn(2).setPreferredWidth(200);
							table.getColumnModel().getColumn(3).setPreferredWidth(80);
							
						} catch (Exception e2) {
							e2.printStackTrace();
						}
																
						
						
					}
				});
				
				btnSeachCity.setBounds(352, 64, 93, 23);
				panel.add(btnSeachCity);
				
				textFieldcid = new JTextField();
				textFieldcid.setFont(new Font("SimSun", Font.PLAIN, 18));
				textFieldcid.setColumns(10);
				textFieldcid.setBounds(567, 496, 84, 26);
				panel.add(textFieldcid);
				
				JLabel lblTax_1 = new JLabel("Cid");
				lblTax_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
				lblTax_1.setBounds(518, 501, 54, 15);
				panel.add(lblTax_1);
				
				JLabel lblNewLabel_5 = new JLabel("Search");
				lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblNewLabel_5.setBounds(378, 10, 54, 15);
				panel.add(lblNewLabel_5);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Order", null, panel_1, null);
		panel_1.setLayout(null);
		
		table_1 = new JTable();
		table_1.setBounds(366, 5, 0, 0);
		panel_1.add(table_1);
		
		textFieldqty = new JTextField();
		textFieldqty.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldqty.setBounds(91, 566, 66, 21);
		panel_1.add(textFieldqty);
		textFieldqty.setColumns(10);
		textFieldqty.setText("1");
//		textField_remark.setText(" ");
		
		JButton btnNewButton_1 = new JButton("<");
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
		
				try {
					
						System.out.println(textFieldtaxable.getText());
						if(EID == null || EID == "" )
						{
							JOptionPane.showMessageDialog(null, "Please select an item!");
						}
				
							
						//check if aclist1 have , have then update , not create it.
				//do not have that create one 
				String sql = "select * from aclist1 where cid = "+textFieldcid.getText() + " and inv_id = " + EID;

				PreparedStatement pst= connection.prepareStatement(sql);
				System.out.println(sql);
				String query= "";
				ResultSet rs = pst.executeQuery();
				 if(!rs.next())
				 {
					 query= "insert into aclist1 "
				+"(cid,inv_id,taxable,smallu,bigu,smallp,bigp) "
				+ "values ( " +textFieldcid.getText()
				+" , " + textField_his_id.getText()
				+" , " + textFieldtaxable.getText()
				+", '"+textFielditemunit.getText()
				+"', '"+textFieldcsunit.getText()
					+"', "+textFieldprice.getText()
					+", "+textFieldcsprice.getText()
					+")";
					 
					 
					 System.out.println(query);
						    pst= connection.prepareStatement(query);
							pst.execute();
							pst.close();
				     }
				   //already have then change it 
				 
				 else {
					  query= "update  aclist1  "
					  +" set taxable = " + textFieldtaxable.getText()
					  +" , smallu = '"+textFielditemunit.getText()
					  +"' , bigu = '"+textFieldcsunit.getText()
					  +"' , smallp = "+textFieldprice.getText()
					  +" , bigp = "+textFieldcsprice.getText()
				 +" where cid = "+textFieldcid.getText() + " and inv_id = " + textField_his_id.getText();		 
							    	 System.out.println(query);
									    pst= connection.prepareStatement(query);
										pst.execute();
										pst.close();				    	 
							     }

//							     updateInvTable();
//							     updateGroundTable();
							     freshLeftup();
//							     update_itemnumber();

				}

				 catch (Exception e2) 
				{
					e2.printStackTrace();
				}		

			}
		});
			
			
		btnNewButton_1.setBounds(978, 313, 66, 30);
		panel_1.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("Refresh");
		btnNewButton_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//				try {
//					
//					String query= "select tb1.inv_id as ID, tb2.chcate as class, "
//							+"tb1.ch_name as ch_name,tb1.price as price "
//							+"from InventoryList as tb1 "
//							+ "left join catelist as tb2 on tb1.CATEGORY = tb2.cateid";	
//					
//  					PreparedStatement pst= connection.prepareStatement(query);
//
//  					ResultSet rs = pst.executeQuery();
//  		
//					table_2.setModel(DbUtils.resultSetToTableModel(rs));
//					pst.close();
//					rs.close();
//					
//				} catch (Exception e2) {
//					e2.printStackTrace();
//				}	
				updateInvTable();
				
				
			}
		});
		btnNewButton_1_1.setBounds(1656, 311, 93, 23);
		panel_1.add(btnNewButton_1_1);
		
		textFieldSearch = new JTextField();
		textFieldSearch.setColumns(10);
		textFieldSearch.setBounds(1367, 31, 207, 28);
		panel_1.add(textFieldSearch);
		
		JButton btnNewButton_1_3 = new JButton("Search(CH)");
		btnNewButton_1_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textFieldSearch.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldSearch.getText() + "%'");
					
					

					String query = "select distinct tb1.inv_id, tb1.taxable, tb2.chcate as CATEGORY, "
							+"tb1.en_name ,tb1.itemunit,tb1.itemprice "
							+"from InventoryList as tb1 "
							+ "left join catelist as tb2 on tb1.CATEGORY = tb2.cateid"
							+ " WHERE ch_name LIKE "
							+ string1;
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_3.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					table_3.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
//					table_2.getColumnModel().getColumn(0).setPreferredWidth(80);
					table_3.getColumnModel().getColumn(0).setPreferredWidth(55);
					table_3.getColumnModel().getColumn(1).setPreferredWidth(33);
					table_3.getColumnModel().getColumn(2).setPreferredWidth(33);
					table_3.getColumnModel().getColumn(3).setPreferredWidth(255);		
					table_3.getColumnModel().getColumn(4).setPreferredWidth(45);
					table_3.getColumnModel().getColumn(5).setPreferredWidth(60);		
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
									
				
			}
		});
		
		
		btnNewButton_1_3.setBounds(1625, 11, 124, 23);
		panel_1.add(btnNewButton_1_3);
		
		JButton btnNewButton_1_4 = new JButton("Seach(EN)");
		btnNewButton_1_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textFieldSearch.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldSearch.getText() + "%'");
					

					
					
					String query = "select distinct tb1.inv_id, tb1.taxable, tb2.chcate as CATEGORY, "
							+"tb1.en_name ,tb1.itemunit,tb1.itemprice "
							+"from InventoryList as tb1 "
							+ "left join catelist as tb2 on tb1.CATEGORY = tb2.cateid"
							+ " WHERE en_name LIKE "
							+ string1;
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_3.setModel(DbUtils.resultSetToTableModel(rs));
					table_3.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
//					table_2.getColumnModel().getColumn(0).setPreferredWidth(80);
					table_3.getColumnModel().getColumn(0).setPreferredWidth(55);
					table_3.getColumnModel().getColumn(1).setPreferredWidth(33);
					table_3.getColumnModel().getColumn(2).setPreferredWidth(33);
					table_3.getColumnModel().getColumn(3).setPreferredWidth(255);		
					table_3.getColumnModel().getColumn(4).setPreferredWidth(45);
					table_3.getColumnModel().getColumn(5).setPreferredWidth(60);		
					
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
									
				
			}
		});		
		
		
		btnNewButton_1_4.setBounds(1625, 45, 124, 23);
		panel_1.add(btnNewButton_1_4);
		
		JButton btnNewButton_1_2_1 = new JButton("Remove all");
		btnNewButton_1_2_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					String query= "Truncate Table  "+orderNo ;

						PreparedStatement pst= connection.prepareStatement(query);

//						System.out.println(query);	

						pst.execute();
						JOptionPane.showMessageDialog(null, "Selection Table Cleared");
						pst.close();
						update_itemnumber();
					}
				
				 catch (Exception e2) {
					e2.printStackTrace();
				}
				updateGroundTable();				
				
				
			}
		});
		btnNewButton_1_2_1.setBounds(778, 729, 174, 23);
		panel_1.add(btnNewButton_1_2_1);
		

		JLabel lblNewLabel_4 = new JLabel("Qty:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4.setBounds(27, 561, 54, 28);
		panel_1.add(lblNewLabel_4);
		
		textFieldch = new JTextField();
		textFieldch.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldch.setColumns(10);
		textFieldch.setBounds(134, 777, 513, 25);
		panel_1.add(textFieldch);
		
		textFielden = new JTextField();
		textFielden.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFielden.setColumns(10);
		textFielden.setBounds(134, 738, 513, 28);
		panel_1.add(textFielden);
		
		JLabel lblNewLabel_4_1 = new JLabel("CH_name");
		lblNewLabel_4_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_1.setBounds(16, 774, 133, 29);
		panel_1.add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_4_1_1 = new JLabel("EN_name");
		lblNewLabel_4_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_1_1.setBounds(16, 739, 98, 23);
		panel_1.add(lblNewLabel_4_1_1);
		
		JLabel lblNewLabel_4_1_1_1 = new JLabel("Price");
		lblNewLabel_4_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_1_1_1.setBounds(202, 363, 72, 20);
		panel_1.add(lblNewLabel_4_1_1_1);
		
		textFieldprice = new JTextField();
		textFieldprice.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldprice.setColumns(10);
		textFieldprice.setBounds(266, 361, 111, 28);
		panel_1.add(textFieldprice);
		
		JLabel lblNewLabel_4_1_1_1_1 = new JLabel("Taxable(0 or 1)");
		lblNewLabel_4_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_1_1_1_1.setBounds(134, 454, 140, 41);
		panel_1.add(lblNewLabel_4_1_1_1_1);
		
		textFieldtaxable = new JTextField();
		textFieldtaxable.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldtaxable.setColumns(10);
		textFieldtaxable.setBounds(265, 467, 54, 18);
		panel_1.add(textFieldtaxable);
		
		JButton btnNewButton_1_5_1 = new JButton("Save");
		btnNewButton_1_5_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_5_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				 try {
					 
					 //				 ��2�ΰ� ɾ�� ��¼ ������¼
				 if( textFieldsaveflag.getText().equals("1")) {

						String query= "DELETE from saledetail "
								+" where id = "+Number;
					 PreparedStatement pst= connection.prepareStatement(query);

						pst.execute();
						pst.close();	
						
						query= "DELETE from InvoiceList "
								+" where id = "+Number;
					   pst= connection.prepareStatement(query);
						pst.execute();
						pst.close();							
						
				 }

				
				 //��  temporder �ٸ�  ���ƽ� revorder��

					String query= 	"select * from " +orderNo+ " order by cati";
					PreparedStatement pst= connection.prepareStatement(query);

						ArrayList<String[]> arr = new ArrayList<>();
						ResultSet rs = pst.executeQuery();
						int index = 0;
						while(rs.next())
						{
							String tt[] = new String[11]; 

							tt[0] = rs.getString("inner_id");
							tt[1] = rs.getString("inv_id");
							tt[2] = rs.getString("qty");
							tt[3] = rs.getString("unit");
							
							tt[4] = rs.getString("price");
							tt[5] = rs.getString("total");
							tt[6] = rs.getString("taxrate");
							tt[7] = rs.getString("ch");
							tt[8] = rs.getString("en");
							tt[9] = rs.getString("csf");
							tt[10] = rs.getString("remark");

							index++;
							arr.add(tt);
							 
						}

					String info [][] = (String[][])arr.toArray(new String[0][]);
					for( int i = 0;i< info.length;i++)
					{
						for( int j = 0;j<info[0].length;j++)
						{
							System.out.print(info[i][j] + " ");
						}
						System.out.println();
					}

					pst.close();				
					rs.close();				

					//remove the record from saledetail
					
				//add ÿ����¼ ��  saledetail

					for( int i = 0;i< info.length;i++)
					{
						 query= "insert into saledetail "
								+"(innerid,goodid,qty,unit,price,total,taxrate,ch,en,csf,remark,id) "
								+ "values ("+ info[i][0]
								+ ", "+info[i][1]
								+ ", "+info[i][2]
								+ ", '"+info[i][3]
								+ "', "+info[i][4]		
								+ ", "+info[i][5]
								+ ", "+info[i][6]
								+ ", '"+info[i][7]
								+ "', '"+info[i][8]															
								+ "', "+info[i][9]
								+ ", '"+info[i][10] 
								+ "', "+Number +")";		
						System.out.println(query);

						pst= connection.prepareStatement(query);

						pst.execute();
						pst.close();
					}

//					��һ�� ���� invoicelist�е� total  �Ƕ���
					query= 
							 "select sum(total) as total from saledetail\r\n"
							+ "where id = "+Number ;
							
					
						PreparedStatement pst2= connection.prepareStatement(query);

						ResultSet rs2 = pst2.executeQuery();
	  					while(rs2.next())
	  					{
	  						total=rs2.getString("total");
	  					}
	  					
						pst2.close();

					
//					��Ϣ���� invoice ��
						query= "insert into InvoiceList("
							+ "id , " + 
							"orderdate," + 
							"ponumber,"  + 
							"term, " + 
							"total, " + 
							
							"cid, " + 
							"name, " + 
							"phone, " + 
							"addr, " + 
							"city, " + 
							"state, " + 
							"zip, " + 
							"taxrate " + 

							") "
							+ "values ("+ Number
							+ ", '"+textFieldodate.getText()
							+ "', '"+textFieldpo.getText()
							+ "', "+textFieldterm.getText()
							+ ", "+ total
							+ ", "+textFieldcid.getText()
							+ ", '"+textFieldName.getText()
							+ "', '"+textFieldPho.getText()
							+ "', '"+textFieldAddr.getText()							
							+ "', '"+textFieldCity.getText()
							+ "', '"+textFieldState.getText()							
							+ "', '"+textFieldZip.getText()
							+ "', '"+textFieldTax.getText()								
							+"'  )";
					
					System.out.println(query);
//					PreparedStatement 
					pst= connection.prepareStatement(query);
						pst.execute();
						pst.close();
						textFieldsaveflag.setText("1");
						
						JOptionPane.showMessageDialog(null, "Order No."+Number+" Saved");

				 	}

		
				 	catch (Exception e2) {
						e2.printStackTrace();
					}		
					
			}

			
		});
		btnNewButton_1_5_1.setBounds(1581, 829, 88, 32);
		panel_1.add(btnNewButton_1_5_1);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(1104, 299, -313, -193);
		panel_1.add(scrollPane_1);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(593, 299, 345, -146);
		panel_1.add(scrollPane_2);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(948, 77, 801, 224);
		panel_1.add(scrollPane_3);
		
		table_3 = new JTable();
		table_3.setFont(new Font("SimSun", Font.PLAIN, 18));
		table_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
  				try {
//					System.out.println("Hi");
							int row = table_3.getSelectedRow();
						     EID = (table_3.getModel().getValueAt(row,0)).toString();
							System.out.println(EID);
							String query= "select * from "+tableI
									+ " where inv_id = '"+EID +"' ";
							System.out.println(query);
							PreparedStatement pst= connection.prepareStatement(query);

							ResultSet rs = pst.executeQuery();
							while(rs.next())
							{

							temp=rs.getString("inv_id");
							textField_his_id.setText(temp);

							textField_innerid.setText("");
	 						textFielden.setText(rs.getString("en_name"));
	  						textFieldch.setText(rs.getString("ch_name")); 
	  						
	 						textFieldtaxable.setText(rs.getString("taxable"));
	  						textFieldprice.setText(rs.getString("itemprice"));  	
	  						textFieldcsprice.setText(rs.getString("caseprice"));  
	  						textFielditemunit.setText(rs.getString("itemunit"));
	  						textFieldcsunit.setText(rs.getString("caseunit"));
	  						textField_cati.setText(rs.getString("CATEGORY")); 	 						
				
							}
							pst.close();
							System.out.println(temp);

						} 
						catch (Exception e2) 
						{
							e2.printStackTrace();				
						}						
				
			}
		});
		scrollPane_3.setViewportView(table_3);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(441, 403, 1319, 318);
		panel_1.add(scrollPane_4);
		
//		String[] columnNames = new String[] { "id", "name", "hp", "damage" };
//		String[][] heros = new String[][] { { "1", "����", "616", "100" },
//		{ "2", "��Ī", "512", "102" }, { "3", "����", "832", "200" } };

		table_4 = new JTable();
		table_4.setFont(new Font("SimSun", Font.PLAIN, 18));
		table_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
				int row = table_4.getSelectedRow();
				String temp_inner_id = (table_4.getModel().getValueAt(row,0)).toString();
				GID = (table_4.getModel().getValueAt(row,1)).toString();
				System.out.println(GID);	
				
				String query= "select * from "+orderNo
				+ " where inv_id = "+GID +" and inner_id = "+ temp_inner_id;
				
				System.out.println(query);
				PreparedStatement pst= connection.prepareStatement(query);
		
				ResultSet rs = pst.executeQuery();
				while(rs.next())
				{
		
					textField_innerid.setText(temp_inner_id);
					textField_his_id.setText(GID);
		
		
					textFielden.setText(rs.getString("en"));
					textFieldch.setText(rs.getString("ch")); 

					textFieldq2.setText(rs.getString("qty"));
					textFieldp2.setText(rs.getString("price"));  	
					textFieldu2.setText(rs.getString("unit"));
					textField_cati.setText(rs.getString("cati")); 	 						
					textField_remark.setText(rs.getString("remark"));
		//		textFieldNote.setText(rs.getString("note"));  						
				}
				pst.close();
				System.out.println(temp);
				
				}
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}						
		
			}
		});
		scrollPane_4.setViewportView(table_4);
		
		JCheckBox checkBox = new JCheckBox("New check box");
		scrollPane_4.setColumnHeaderView(checkBox);
		
		JLabel lblNewLabel_4_2 = new JLabel("ItemUnit:");
		lblNewLabel_4_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_2.setBounds(27, 361, 88, 25);
		panel_1.add(lblNewLabel_4_2);
		
		textFielditemunit = new JTextField();
		textFielditemunit.setFont(new Font("SimSun", Font.PLAIN, 18));
//		textFielditemunit.setText("1");
		textFielditemunit.setColumns(10);
		textFielditemunit.setBounds(109, 364, 66, 21);
		panel_1.add(textFielditemunit);
		
		JLabel lblNewLabel_4_1_1_1_1_1 = new JLabel("Terms(days)");
		lblNewLabel_4_1_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_1_1_1_1_1.setBounds(653, 825, 124, 41);
		panel_1.add(lblNewLabel_4_1_1_1_1_1);
		
		textFieldterm = new JTextField();
		textFieldterm.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldterm.setColumns(10);
		textFieldterm.setBounds(762, 832, 41, 30);
		panel_1.add(textFieldterm);
		updateCustomtable();
		updateGroundTable();
		updateInvTable();
		textFieldterm.setText("30");
		
		textFieldpo = new JTextField();
		textFieldpo.setFont(new Font("SimSun", Font.PLAIN, 16));
		textFieldpo.setColumns(10);
		textFieldpo.setBounds(931, 832, 196, 32);
		panel_1.add(textFieldpo);
		
		JLabel lblNewLabel_4_2_1 = new JLabel("PO Number");
		lblNewLabel_4_2_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_2_1.setBounds(837, 835, 111, 21);
		panel_1.add(lblNewLabel_4_2_1);
		
		textFieldodate = new JTextField();
		textFieldodate.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldodate.setColumns(10);
		textFieldodate.setBounds(103, 833, 140, 28);
		panel_1.add(textFieldodate);
		
		JLabel lblNewLabel_4_1_2 = new JLabel("OrderDate");
		lblNewLabel_4_1_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_1_2.setBounds(13, 834, 86, 23);
		panel_1.add(lblNewLabel_4_1_2);
//		getSysTime
		textFieldodate.setText(Preview.getTime());
		
		JScrollPane scrollPane_5 = new JScrollPane();
		scrollPane_5.setBounds(441, 299, -301, -204);
		panel_1.add(scrollPane_5);
		JRadioButton checkb = new JRadioButton("CS?");
		checkb.setSelected(true);
		checkb.setFont(new Font("Tahoma", Font.PLAIN, 18));
		checkb.setBounds(27, 466, 109, 23);
		panel_1.add(checkb);
		
		JButton btnNewButton_1_6 = new JButton("His >");
		btnNewButton_1_6.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnNewButton_1_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
						update_itemnumber();

									// import into
						String inneridd  =  String.valueOf(Integer.parseInt((innerid==null)?"0":innerid)+1);
							// 3. add it based on the 


						String sql2= "insert into " +orderNo+ " (inner_id,inv_id,qty,"
								+ "cati,unit,price,taxrate,"
								+ "ch,en,csf,"
								+ "total,remark) "+
						" values ( "+inneridd
						+ ","+textField_his_id.getText()
						+ ","+textFieldqty.getText()
						
						+ ","+textField_cati.getText()   //cati
						+ ",'"+(checkb.isSelected()?textFieldcsunit.getText():textFielditemunit.getText())   //unit
						+ "',"+(checkb.isSelected()?textFieldcsprice.getText():textFieldprice.getText())   //price
						+ ","+((textFieldtaxable.getText().equals("1"))? textFieldTax.getText() : textFieldtaxable.getText())
						+ ",'"+textFieldch.getText()   //ch
						+ "','"+textFielden.getText()   //en
						+ "',"+checkb.isSelected()  //csflag
						+ ", 0"   //subtotal
						+ ",'"+textField_remark.getText()   //
						+ "')";
						
						 System.out.println(sql2);
						PreparedStatement pst= connection.prepareStatement(sql2);
						
						 pst.execute();
						pst.close();
						cal_sub();
//					     updateInvTable();
//					     updateGroundTable();
//					     freshLeftup();
					     update_itemnumber();
					     
					
				}
		
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}		
		
				
				
			}
		});
		btnNewButton_1_6.setBounds(237, 319, 82, 21);
		panel_1.add(btnNewButton_1_6);
		
		JLabel lblNewLabel_4_1_3 = new JLabel("Whole Inventory");
		lblNewLabel_4_1_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_1_3.setBounds(951, 22, 140, 41);
		panel_1.add(lblNewLabel_4_1_3);
		
		JScrollPane scrollPane_6 = new JScrollPane();
		scrollPane_6.setBounds(40, 284, 135, -94);
		panel_1.add(scrollPane_6);
		
		JScrollPane scrollPane_7 = new JScrollPane();
		scrollPane_7.setBounds(40, 284, 391, -172);
		panel_1.add(scrollPane_7);
		
		JScrollPane scrollPane_8 = new JScrollPane();
		scrollPane_8.setBounds(28, 77, 866, 223);
		panel_1.add(scrollPane_8);
		
		table_2 = new JTable();
		table_2.setFont(new Font("SimSun", Font.PLAIN, 18));
		scrollPane_8.setViewportView(table_2);
		
		textField_cati = new JTextField();
		textField_cati.setFont(new Font("SimSun", Font.PLAIN, 18));
		textField_cati.setColumns(10);
		textField_cati.setBounds(550, 838, 93, 18);
		panel_1.add(textField_cati);
		
		JLabel lblNewLabel_4_1_3_2 = new JLabel("Category");
		lblNewLabel_4_1_3_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_1_3_2.setBounds(466, 833, 98, 25);
		panel_1.add(lblNewLabel_4_1_3_2);
		
		textField_history = new JTextField();
		textField_history.setFont(new Font("SimSun", Font.PLAIN, 18));
		textField_history.setColumns(10);
		textField_history.setBounds(402, 30, 180, 29);
		panel_1.add(textField_history);
		
		JButton btnNewButton_1_1_1_1 = new JButton("CH");
		btnNewButton_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String	query= " select tb1.inv_id,tb1.taxable, tb2.ch_name,tb2.en_name,"
							+ " tb1.bigu,tb1.smallu,tb1.bigp,tb1.smallp  "
							+ "	from aclist1 as tb1 "
							+ "	left join InventoryList as tb2 on tb1.inv_id = tb2.inv_id\r\n"
								+ "	where tb1.cid =" + textFieldcid.getText()
								+ " and  tb2.ch_name LIKE '%" +textField_history.getText() + "%'" ;
		

						System.out.println(query);
						PreparedStatement pst= connection.prepareStatement(query);
						ResultSet rs = pst.executeQuery();
						 

						table_2.setModel(DbUtils.resultSetToTableModel(rs));
				
						pst.close();
						rs.close();						
				}
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}					
			}
		});
		btnNewButton_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_1_1_1.setBounds(603, 27, 70, 31);
		panel_1.add(btnNewButton_1_1_1_1);
		
		JButton btnNewButton_1_1_1_1_1 = new JButton("EN");
		btnNewButton_1_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String	query= " select tb1.inv_id,tb1.taxable, tb2.ch_name,tb2.en_name,"
							+ " tb1.bigu,tb1.smallu,tb1.bigp,tb1.smallp  "
							+ "	from aclist1 as tb1 "
							+ "	left join InventoryList as tb2 on tb1.inv_id = tb2.inv_id\r\n"
								+ "	where tb1.cid =" + textFieldcid.getText()
							+ " and  tb2.en_name LIKE '%" +textField_history.getText() + "%'" ;
	
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					 
					 
					table_2.setModel(DbUtils.resultSetToTableModel(rs));
			
					pst.close();
					rs.close();						
			}
			catch (Exception e2) 
			{
				e2.printStackTrace();				
			}
				
			}
		});
		btnNewButton_1_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_1_1_1_1.setBounds(683, 27, 67, 31);
		panel_1.add(btnNewButton_1_1_1_1_1);
		
		JButton btnNewButton_1_1_1_1_2 = new JButton("load");
		btnNewButton_1_1_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_1_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				freshLeftup();
			}
		});
		btnNewButton_1_1_1_1_2.setBounds(26, 311, 70, 23);
		panel_1.add(btnNewButton_1_1_1_1_2);
		
		JLabel lblNewLabel_4_1_1_1_1_1_1 = new JLabel("Item number");
		lblNewLabel_4_1_1_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_1_1_1_1_1_1.setBounds(27, 509, 160, 41);
		panel_1.add(lblNewLabel_4_1_1_1_1_1_1);
		
		textField_itnumber = new JTextField();
		textField_itnumber.setFont(new Font("SimSun", Font.PLAIN, 18));

		textField_itnumber.setColumns(10);
		textField_itnumber.setBounds(155, 520, 66, 22);
		panel_1.add(textField_itnumber);
		
		textField_his_id = new JTextField();
		textField_his_id.setFont(new Font("SimSun", Font.PLAIN, 18));
		textField_his_id.setColumns(10);
		textField_his_id.setBounds(266, 564, 107, 25);
		panel_1.add(textField_his_id);
		
		JLabel lblNewLabel_4_3 = new JLabel("Inv_id");
		lblNewLabel_4_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_3.setBounds(202, 561, 54, 28);
		panel_1.add(lblNewLabel_4_3);
		
		JLabel lblNewLabel_4_4 = new JLabel("Remark");
		lblNewLabel_4_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_4.setBounds(27, 607, 93, 28);
		panel_1.add(lblNewLabel_4_4);
		
		textField_remark = new JTextField();
		textField_remark.setFont(new Font("SimSun", Font.PLAIN, 18));
		textField_remark.setColumns(10);
		textField_remark.setBounds(109, 609, 316, 28);
		panel_1.add(textField_remark);
		
		JLabel lblNewLabel_4_3_1 = new JLabel("innerid");
		lblNewLabel_4_3_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_3_1.setBounds(252, 515, 68, 28);
		panel_1.add(lblNewLabel_4_3_1);
		
		textField_innerid = new JTextField();
		textField_innerid.setFont(new Font("SimSun", Font.PLAIN, 18));
		textField_innerid.setColumns(10);
		textField_innerid.setBounds(324, 517, 54, 25);
		panel_1.add(textField_innerid);
		
		JLabel lblNewLabel_4_1_3_3 = new JLabel("To left Table");
		lblNewLabel_4_1_3_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_4_1_3_3.setBounds(1054, 309, 111, 41);
		panel_1.add(lblNewLabel_4_1_3_3);
		
		JButton btnNewButton_1_2_1_1 = new JButton("Update");
		btnNewButton_1_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String query= "update "+orderNo
							+ " set "

							+ " qty ="+textFieldq2.getText()
							+" ,cati='"+ textField_cati.getText()
							+"' ,unit='"+ textFieldu2.getText()
							+"' ,price="+ textFieldp2.getText()
							+" ,ch='"+ textFieldch.getText()
							+"' ,en='"+ textFielden.getText()
							+"' ,remark='"+ textField_remark.getText()

							+"' where inv_id = "+textField_his_id.getText() 
							+" and inner_id = "+textField_innerid.getText();
				
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
			
					pst.execute();
					pst.close();
					


				     JOptionPane.showMessageDialog(null, "temp order Updated");	
					pst.close();
					cal_sub();
//					update_itemnumber();
//					updateGroundTable();
//					freshLeftup();

					
				} 
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}					
  				updateGroundTable();					
				
				
			}
		});
		btnNewButton_1_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_2_1_1.setBounds(933, 777, 111, 23);
		panel_1.add(btnNewButton_1_2_1_1);
		
		JButton btnNewButton_1_1_1_1_1_1 = new JButton("DEL ALL");
		btnNewButton_1_1_1_1_1_1.setForeground(Color.RED);
		btnNewButton_1_1_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String q2 = "DELETE from aclist1 WHERE cid =" + textFieldcid.getText();
					
					int input =JOptionPane.showConfirmDialog(null, "DELETE history data of this customer? ");	
					if(input == 0)
					{
						System.out.println(q2);	
						PreparedStatement pst= connection.prepareStatement(q2);
						pst.execute();
						pst.close();
	//					updateGroundTable();
						freshLeftup();
					}
				}
		
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}				
				
			}
		});
		btnNewButton_1_1_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_1_1_1_1_1.setBounds(778, 313, 111, 31);
		panel_1.add(btnNewButton_1_1_1_1_1_1);
		
		JButton btnNewButton_1_1_1_1_1_1_1 = new JButton("DEL ONE");
		btnNewButton_1_1_1_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String q2 = "DELETE from aclist1 WHERE cid =" + textFieldcid.getText()
					+" and inv_id= "+ textField_his_id.getText();
					
					int input =JOptionPane.showConfirmDialog(null, "DELETE one entry? ");	
					if(input==0)
					{
						System.out.println(q2);	
						PreparedStatement pst= connection.prepareStatement(q2);
						pst.execute();
						//get all information to display
	//					table_2.setModel(DbUtils.resultSetToTableModel(rs));
						pst.close();
	//					updateGroundTable();
						freshLeftup();
					}
				}
		
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}							
				
			}
		});
		btnNewButton_1_1_1_1_1_1_1.setForeground(Color.RED);
		btnNewButton_1_1_1_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_1_1_1_1_1_1.setBounds(653, 313, 108, 31);
		panel_1.add(btnNewButton_1_1_1_1_1_1_1);
		
		JButton btnNewButton_1_2_1_2 = new JButton("del");
		btnNewButton_1_2_1_2.setForeground(Color.RED);
		btnNewButton_1_2_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String query= "DELETE from "+orderNo
							+" where inv_id = "+textField_his_id.getText() 
							+" and inner_id = "+textField_innerid.getText();
				
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
			
					pst.execute();
					pst.close();

//				     JOptionPane.showMessageDialog(null, "temp order Updated");	
					pst.close();
//					update_itemnumber();
					updateGroundTable();
//					freshLeftup();

					
				} 
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}					
  				updateGroundTable();					
				
				
			}
		});
		btnNewButton_1_2_1_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_2_1_2.setBounds(962, 729, 66, 23);
		panel_1.add(btnNewButton_1_2_1_2);
		
		JLabel lblNewLabel_4_1_3_1 = new JLabel("Custom's Product");
		lblNewLabel_4_1_3_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_1_3_1.setBounds(27, 18, 168, 41);
		panel_1.add(lblNewLabel_4_1_3_1);
		
		JLabel lblNewLabel_4_1_3_4 = new JLabel("Order List");
		lblNewLabel_4_1_3_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_1_3_4.setBounds(466, 353, 140, 41);
		panel_1.add(lblNewLabel_4_1_3_4);
		
		JLabel lblNewLabel_4_1_3_3_1 = new JLabel("Add to Order List");
		lblNewLabel_4_1_3_3_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_4_1_3_3_1.setBounds(109, 309, 145, 41);
		panel_1.add(lblNewLabel_4_1_3_3_1);
		
		JButton btnNewButton_1_2_1_1_2 = new JButton("Change");
		btnNewButton_1_2_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query= "update aclist1"
							+ " set "

							+ " smallu = '"+textFielditemunit.getText()
							+"' ,smallp="+ textFieldprice.getText()
							+" ,bigu='"+ textFieldcsunit.getText()
							+"' ,bigp="+ textFieldcsprice.getText()


							+" where cid = "+textFieldcid.getText() 
							+" and inv_id = "+textField_his_id.getText();
				
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					
					pst.execute();
					pst.close();
					JOptionPane.showMessageDialog(null, "Custom Order Info. updated");
					freshLeftup();
				}
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}		
				
				
			}
		});
		btnNewButton_1_2_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_2_1_1_2.setBounds(532, 317, 111, 23);
		panel_1.add(btnNewButton_1_2_1_1_2);
		
		JLabel lblNewLabel_4_1_1_1_3 = new JLabel("CSPrice");
		lblNewLabel_4_1_1_1_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_1_1_1_3.setBounds(185, 404, 72, 20);
		panel_1.add(lblNewLabel_4_1_1_1_3);
		
		textFieldcsprice = new JTextField();
		textFieldcsprice.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldcsprice.setColumns(10);
		textFieldcsprice.setBounds(266, 402, 111, 28);
		panel_1.add(textFieldcsprice);
		
		JLabel lblNewLabel_4_2_2 = new JLabel("CSUnit:");
		lblNewLabel_4_2_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_2_2.setBounds(26, 399, 88, 25);
		panel_1.add(lblNewLabel_4_2_2);
		
		textFieldcsunit = new JTextField();
//		textFieldcsunit.setText("1");
		textFieldcsunit.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldcsunit.setColumns(10);
		textFieldcsunit.setBounds(109, 405, 66, 21);
		panel_1.add(textFieldcsunit);
		
		JLabel lblNewLabel_4_1_3_3_2 = new JLabel("Step1");
		lblNewLabel_4_1_3_3_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_4_1_3_3_2.setBounds(1073, 338, 54, 41);
		panel_1.add(lblNewLabel_4_1_3_3_2);
		
		JLabel lblNewLabel_4_1_3_3_2_1 = new JLabel("Step2");
		lblNewLabel_4_1_3_3_2_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_4_1_3_3_2_1.setBounds(329, 309, 54, 41);
		panel_1.add(lblNewLabel_4_1_3_3_2_1);
		
		JLabel lblNewLabel_4_1_3_3_2_2 = new JLabel("Step3");
		lblNewLabel_4_1_3_3_2_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_4_1_3_3_2_2.setBounds(1674, 784, 54, 41);
		panel_1.add(lblNewLabel_4_1_3_3_2_2);
		
		JLabel lblNewLabel_4_1_1_1_4 = new JLabel("Price");
		lblNewLabel_4_1_1_1_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_1_1_1_4.setBounds(1073, 778, 72, 20);
		panel_1.add(lblNewLabel_4_1_1_1_4);
		
		JLabel lblNewLabel_4_1_1_1_4_1 = new JLabel("Unit");
		lblNewLabel_4_1_1_1_4_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_1_1_1_4_1.setBounds(1073, 736, 72, 20);
		panel_1.add(lblNewLabel_4_1_1_1_4_1);
		
		textFieldp2 = new JTextField();
		textFieldp2.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldp2.setColumns(10);
		textFieldp2.setBounds(1128, 774, 111, 28);
		panel_1.add(textFieldp2);
		
		textFieldu2 = new JTextField();
		textFieldu2.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldu2.setColumns(10);
		textFieldu2.setBounds(1128, 733, 111, 28);
		panel_1.add(textFieldu2);
		
		JLabel lblNewLabel_4_5 = new JLabel("Qty:");
		lblNewLabel_4_5.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_5.setBounds(1262, 729, 54, 28);
		panel_1.add(lblNewLabel_4_5);
		
		textFieldq2 = new JTextField();
		textFieldq2.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldq2.setColumns(10);
		textFieldq2.setBounds(1305, 733, 66, 21);
		panel_1.add(textFieldq2);
		
		JButton btnNewButton_1_2_1_1_1_1 = new JButton("Calulate");
		btnNewButton_1_2_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cal_sub();
				
			}
		});
		btnNewButton_1_2_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_2_1_1_1_1.setBounds(1407, 732, 98, 23);
		panel_1.add(btnNewButton_1_2_1_1_1_1);
		
		JButton btnNewButton_1_5_1_1 = new JButton("Print");
		btnNewButton_1_5_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//				if(textFieldflag.getText().equals("1"))
				{
				try {
					String query= "select *  from invoicelist "
							+ " where id = '"+ Number +"' ";
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
//					String [] custom = {"0.0077","name","addr","city","state","zip","Phone"};
					while(rs.next())
					{
						temp4[0] = (rs.getString("taxrate"));
						temp4[1] = (rs.getString("name"));
						temp4[2] = (rs.getString("addr"));
						temp4[3] = (rs.getString("city"));
						temp4[4] = (rs.getString("state"));
						temp4[5] = (rs.getString("zip"));
						temp4[6] = (rs.getString("Phone"));
						temp4[7] = GenOrder.convTime2(rs.getString("orderdate"));
						temp4[8] = (rs.getString("ponumber"));
						temp4[9] = (rs.getString("term"));
					}				

					
					pst.close();
					rs.close();
//
					for(String word: temp4)
					{
						System.out.println(word);
					}
					
//					System.out.println(temp2[1]);
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
				
				try {
					
					String query= "select *  from saledetail "
							+ " where id = '"+ Number +"' ";				
					PreparedStatement pst= connection.prepareStatement(query);
					System.out.println(query);
					ArrayList<String[]> arr = new ArrayList<>();
					ResultSet rs = pst.executeQuery();
					int index = 0;
					
					while(rs.next())
					{
						String tt[] = new String[6]; 
		
//						new String[]{"11","bag","Taita", "22.00", "Yes", "̫̫����"},
						
						tt[0] = rs.getString("qty");
						tt[1] = rs.getString("unit");
						tt[2] = rs.getString("price");
						tt[3] = rs.getString("taxrate");
						tt[4] = rs.getString("en");
						String ck = rs.getString("remark");
						String ck2 = rs.getString("ch");
						System.out.println("CK");
						System.out.println(ck);
						tt[5] = (ck==null|| ck.equals("")|| ck.equals(" ")|| ck.equals("  "))?ck2:ck2+" ("+ck+")";
						index++;
						
//						System.out.println("");
						 arr.add(tt);
						 
					}
					pst.close();				
					rs.close();	
					
					if( arr.size()==0) JOptionPane.showMessageDialog(null, "There is no item in the invoice");
					else {
						String statelist [][] = (String[][])arr.toArray(new String[0][]);
						for (int i =0;i<statelist.length;i++)
						{
							for(int j =0;j<statelist[0].length;j++)
							{
								System.out.print( statelist[i][j] + " ");
							}
							System.out.println("");
							//						System.out.print("Total item:"+index );
						}
						GenOrder.top( temp4,statelist,Number);
//						JOptionPane.showMessageDialog(null, "Invoice ID = " + temp+ " generated." );
//					
						Runtime.getRuntime().exec(sqlcon.wordpath+" "+sqlcon.savepath+"invoice.docx");
					}
//					System.out.println(temp2[1]);
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
																
				
				}
			}
		});
		btnNewButton_1_5_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_5_1_1.setBounds(1679, 829, 93, 32);
		panel_1.add(btnNewButton_1_5_1_1);
		
		textFieldcurrent = new JTextField();
		textFieldcurrent.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldcurrent.setColumns(10);
		textFieldcurrent.setBounds(1319, 833, 111, 28);
		panel_1.add(textFieldcurrent);
		
		JLabel lblNewLabel_4_1_1_1_4_2 = new JLabel("Invoice Number");
		lblNewLabel_4_1_1_1_4_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_1_1_1_4_2.setBounds(1187, 829, 129, 32);
		panel_1.add(lblNewLabel_4_1_1_1_4_2);
		
		textFieldsaveflag = new JTextField();
		textFieldsaveflag.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldsaveflag.setColumns(10);
		textFieldsaveflag.setBounds(1662, 731, 41, 21);
		panel_1.add(textFieldsaveflag);
		
		JLabel lblNewLabel_4_1_1_1_4_2_1 = new JLabel("saveflag");
		lblNewLabel_4_1_1_1_4_2_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4_1_1_1_4_2_1.setBounds(1587, 724, 82, 32);
		panel_1.add(lblNewLabel_4_1_1_1_4_2_1);
		
		JButton btnNewButton_1_5_1_2 = new JButton("New");
		btnNewButton_1_5_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				textFieldsaveflag.setText("0");
				Number = Integer.toString(Integer.parseInt(Number)+1);
				textFieldcurrent.setText(Number);				
				
				try {
					String query= "Truncate Table  "+orderNo ;
					PreparedStatement pst= connection.prepareStatement(query);
					pst.execute();
					updateGroundTable();
				}
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}							
			
	
			}
		});
		btnNewButton_1_5_1_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_1_5_1_2.setBounds(1478, 829, 88, 32);
		panel_1.add(btnNewButton_1_5_1_2);

		
		table_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					int row = table_2.getSelectedRow();
					EID = (table_2.getModel().getValueAt(row,0)).toString();
					System.out.println(EID);	
					
//					String query= "select * from "+tableI
//							+ " where inv_id = '"+EID +"' ";
					String query = "select tb1.inv_id,tb2.CATEGORY as cati,"
							+ "tb2.ch_name,tb2.en_name, "
							+" tb1.smallp,tb1.smallu,tb1.bigp, tb1.bigu, tb2.taxable "
							+ " from aclist1 as tb1 "
							+ " left join InventoryList as tb2 on tb1.inv_id = tb2.inv_id"
							+ " where tb1.cid = " + textFieldcid.getText() 
							+ " and tb2.inv_id = "+EID;
					
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);

					ResultSet rs = pst.executeQuery();
					while(rs.next())
					{

//					temp=rs.getString("inv_id");
//					textFieldID.setText(rs.getString("id"));
						
						textField_his_id.setText(EID);
						textFielden.setText(rs.getString("en_name"));
						textFieldch.setText(rs.getString("ch_name")); 
						textFieldqty.setText("1"); 
						textField_cati.setText(rs.getString("cati")); 
						textFieldtaxable.setText(rs.getString("taxable"));
						textFieldprice.setText(rs.getString("smallp"));  	
						textFielditemunit.setText(rs.getString("smallu"));
						textFieldcsprice.setText(rs.getString("bigp"));  	
						textFieldcsunit.setText(rs.getString("bigu")); 						
					}					
					
					
					
					}
					catch (Exception e2) 
					{
						e2.printStackTrace();				
					}							
				
				
			}
		});
		



	}
}


