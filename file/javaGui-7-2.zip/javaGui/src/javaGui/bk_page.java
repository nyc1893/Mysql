package javaGui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class bk_page extends JFrame {
	Connection connection = null;
	private JPanel contentPane;
	private JTable table_1;
	private JTable table_2;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					bk_page frame = new bk_page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	public void refreshTable() {
		try {
			String query= 					
					"select * "
					+"from InventoryList ";	

			System.out.println(query);
			PreparedStatement pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			//get all information to display
			table.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			

			
		} catch (Exception e) {
			e.printStackTrace();
		}	
		
	}

	
	public void refreshTable2() {
		try {
			String query= 					
					"select * "
					+"from Customlist ";	

			System.out.println(query);
			PreparedStatement pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			//get all information to display
			table_1.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();

			
		} 		
		
		catch (Exception e) {
			e.printStackTrace();
		}	
		
	}
	
	
	public void refreshTable3() {
		try {
			String query= 					
					"select * "
					+"from SellerList ";	

			System.out.println(query);
			PreparedStatement pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			//get all information to display
			table_2.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();

			
		} 		
		
		catch (Exception e) {
			e.printStackTrace();
		}	
		
	}
	/**
	 * Create the frame.
	 */
	public bk_page() {
		connection = sqlcon.db();
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 863, 723);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Product");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 14));
		lblNewLabel.setBounds(121, 34, 54, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblCustom = new JLabel("Custom");
		lblCustom.setFont(new Font("����", Font.PLAIN, 14));
		lblCustom.setBounds(121, 235, 54, 15);
		contentPane.add(lblCustom);
		
		JLabel lblSupplier = new JLabel("Supplier");
		lblSupplier.setFont(new Font("����", Font.PLAIN, 14));
		lblSupplier.setBounds(121, 445, 68, 15);
		contentPane.add(lblSupplier);
		
		JButton btnNewButton = new JButton("save_P");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String sql2= 	"select * from InventoryList ";
					
//				String sql2= "select  tb1.ch_name as ch,tb2.qty as qty, "
//						+ "tb1.en_name as en, tb1.taxable as tax,tb1.price as price, "
//						+ "tb1.Units as unit " 
//						+ "from temporder as tb2 "
//						+ "left join InventoryList as tb1 on tb1.inv_id = tb2.id";

					PreparedStatement pst= connection.prepareStatement(sql2);
//					System.out.println(sql2);
					ArrayList<String[]> arr = new ArrayList<>();
					ResultSet rs = pst.executeQuery();
					int index = 0;
					while(rs.next())
					{
						String tt[] = new String[10]; 
//						System.out.print(rs.getString("en") + " ");
//						System.out.print(rs.getString("ch") + " ");
//						System.out.print(rs.getString("price") + " ");
//						System.out.print(rs.getString("unit") + " ");
//						
//						System.out.print(rs.getString("qty") + " ");
//						System.out.print(rs.getString("taxrate") + " ");
						

						
						tt[0] = rs.getString("inv_id");
						tt[1] = rs.getString("en_name");
						tt[2] = rs.getString("Caseprice");
						
						tt[3] = rs.getString("CATEGORY");
						tt[4] = rs.getString("ch_name");
						tt[5] = rs.getString("Itempercase");
						tt[6] = rs.getString("Itemprice");
						tt[7] = rs.getString("Taxable");
						
						tt[8] = rs.getString("caseunit");
						tt[9] = rs.getString("itemunit");

						index++;
						
						System.out.println("");
						 arr.add(tt);
						 
					}
					String goods [][] = (String[][])arr.toArray(new String[0][]);

					gen_xls.save_product( goods);
//					JOptionPane.showMessageDialog(null, "Save Product Info done!");
//					System.out.print("Total item:"+index );

					Runtime.getRuntime().exec(sqlcon.exepath+" "+sqlcon.savepath+"backup\\product.xls");
//					Runtime.getRuntime().exec(sqlcon.exepath+" F:/generated/backup/product.xls");
					pst.close();				
					rs.close();				
				} catch (Exception e2) {
					e2.printStackTrace();
				}
														
				
				
				
			}
		});
		btnNewButton.setBounds(687, 120, 93, 23);
		contentPane.add(btnNewButton);
		
		JButton btnSavec = new JButton("save_C");
		btnSavec.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String sql2= 	"select * from Customlist ";
					

					PreparedStatement pst= connection.prepareStatement(sql2);
//					System.out.println(sql2);
					ArrayList<String[]> arr = new ArrayList<>();
					ResultSet rs = pst.executeQuery();
					int index = 0;
					while(rs.next())
					{
						String tt[] = new String[9]; 

						
						tt[0] = rs.getString("id");
						tt[1] = rs.getString("name");
						tt[2] = rs.getString("phone");
						
						tt[3] = rs.getString("addr");
						tt[4] = rs.getString("city");
						tt[5] = rs.getString("state");
						tt[6] = rs.getString("zip");
						tt[7] = rs.getString("tax");
						
						tt[8] = rs.getString("note");
	

						index++;
						
						System.out.println("");
						 arr.add(tt);
						 
					}
					String goods [][] = (String[][])arr.toArray(new String[0][]);

					gen_xls.save_custom( goods);
//					JOptionPane.showMessageDialog(null, "Save custom Info done!");
//					System.out.print("Total item:"+index );
					
					Runtime.getRuntime().exec(sqlcon.exepath+" "+sqlcon.savepath+"backup\\custom.xls");
										
//					Runtime.getRuntime().exec(sqlcon.exepath+" F:/generated/backup/custom.xls");
					pst.close();				
					rs.close();				
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
				
				
			}
		});
		
		
		
		btnSavec.setBounds(687, 336, 93, 23);
		contentPane.add(btnSavec);
		
		JButton btnSaves = new JButton("save_S");
		btnSaves.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String sql2= 	"select * from Sellerlist ";
					

					PreparedStatement pst= connection.prepareStatement(sql2);
//					System.out.println(sql2);
					ArrayList<String[]> arr = new ArrayList<>();
					ResultSet rs = pst.executeQuery();
					int index = 0;
					while(rs.next())
					{
						String tt[] = new String[13]; 

						
						tt[0] = rs.getString("id");
						tt[1] = rs.getString("name");
						tt[2] = rs.getString("addr");
						
						tt[3] = rs.getString("city");
						tt[4] = rs.getString("state");
						tt[5] = rs.getString("zip");
						tt[6] = rs.getString("phone");
						tt[7] = rs.getString("fax");
						
						tt[8] = rs.getString("cname");
						tt[9] = rs.getString("ctitle");
						tt[10] = rs.getString("ctitle");
						tt[11] = rs.getString("email");
						tt[12] = rs.getString("note");
					
						index++;
						
						System.out.println("");
						 arr.add(tt);
						 
					}
					String goods [][] = (String[][])arr.toArray(new String[0][]);

					gen_xls.save_supplier( goods);
//					JOptionPane.showMessageDialog(null, "Save supplier Info done!");
//					System.out.print("Total item:"+index );

					Runtime.getRuntime().exec(sqlcon.exepath+" "+sqlcon.savepath+"backup\\supplier.xls");
//					Runtime.getRuntime().exec(sqlcon.exepath+" F:/generated/backup/supplier.xls");
					pst.close();				
					rs.close();				
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
				
				
				
				
			}
		});
		btnSaves.setBounds(687, 530, 93, 23);
		contentPane.add(btnSaves);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(64, 259, 601, 156);
		contentPane.add(scrollPane_1);
		
		table_1 = new JTable();
		scrollPane_1.setViewportView(table_1);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(64, 471, 601, 160);
		contentPane.add(scrollPane_2);
		
		table_2 = new JTable();
		scrollPane_2.setViewportView(table_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(64, 56, 601, 156);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JLabel lblBackupSystem = new JLabel("Backup System");
		lblBackupSystem.setFont(new Font("Arial Black", Font.BOLD, 16));
		lblBackupSystem.setBounds(37, 0, 263, 28);
		contentPane.add(lblBackupSystem);
		refreshTable();
		refreshTable2();
		refreshTable3();
	}
}
