package javaGui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Menu2 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu2 frame = new Menu2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Menu2() {
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Edit Orderlist");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ad_orderlist  abc= new ad_orderlist();
				 abc.setVisible(true);					

			}
		});
		btnNewButton.setBounds(68, 67, 131, 47);
		contentPane.add(btnNewButton);
		
		JButton btnOrdering = new JButton("Ordering");
		btnOrdering.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnOrdering.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 custom_page  abc= new custom_page();
				 abc.setVisible(true);				
			
			}
		});
		btnOrdering.setBounds(229, 67, 131, 47);
		contentPane.add(btnOrdering);
		
		JLabel lblNewLabel_1_1 = new JLabel("\u8D27\u54C1\u51FA\u5E93 (\u4E0B\u5355)");
		lblNewLabel_1_1.setFont(new Font("SimSun", Font.PLAIN, 16));
		lblNewLabel_1_1.setBounds(239, 26, 134, 31);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u7F16\u8F91\u53D1\u7968\u8BE6\u60C5");
		lblNewLabel_2.setFont(new Font("SimSun", Font.PLAIN, 16));
		lblNewLabel_2.setBounds(86, 25, 113, 31);
		contentPane.add(lblNewLabel_2);
	}

}
