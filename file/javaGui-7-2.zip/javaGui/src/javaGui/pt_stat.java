package javaGui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;

public class pt_stat extends JFrame {

	private JPanel contentPane;

	private JTextField textFieldT1;
	private JTextField textFieldT2;
	private JTextField textFieldSearch2;
	Connection connection = null;
	
	String tableC = "customlist";
	String tableO = "revorderList";
	String temp = "";
	private JTable table;
	String temp2[] = new String [10];
//	String custom[] = new String[20];
	private JTable table_1;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					pt_stat frame = new pt_stat();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void refreshTable1() {
		try {
			
			String sql2= "select  * "
					+ "from revorderlist";
//					+ "left join InventoryList as tb1 on tb1.inv_id = tb2.id";
			
				PreparedStatement pst= connection.prepareStatement(sql2);
				ResultSet rs = pst.executeQuery();
				table_1.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}
	
	
	public void refreshTable2() {
		try {
			String query= "select id,orderdate,name,total" + 
					"  from InvoiceList";
			PreparedStatement pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			//get all information to display
			table.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		
	}
	/**
	 * Create the frame.
	 */
	public pt_stat() {
		connection = sqlcon.db();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1920, 733);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Invoice Record:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(50, 59, 142, 20);
		contentPane.add(lblNewLabel);
		
		textFieldT1 = new JTextField();
		textFieldT1.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldT1.setBounds(185, 505, 180, 20);
		contentPane.add(textFieldT1);
		textFieldT1.setColumns(10);
		
		textFieldT2 = new JTextField();
		textFieldT2.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldT2.setColumns(10);
		textFieldT2.setBounds(185, 539, 180, 20);
		contentPane.add(textFieldT2);
		
		JLabel lblNewLabel_1 = new JLabel("Date from");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(82, 506, 93, 19);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("to");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_1.setBounds(144, 536, 38, 23);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Company Name");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_2.setBounds(50, 568, 142, 31);
		contentPane.add(lblNewLabel_1_2);
		
		textFieldSearch2 = new JTextField();
		textFieldSearch2.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldSearch2.setColumns(10);
		textFieldSearch2.setBounds(185, 576, 285, 20);
		contentPane.add(textFieldSearch2);
		
		JButton btnNewButton = new JButton("Time");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {

					String string1 = (textFieldT1.getText().trim().isEmpty())?("''")
							:( "'"+textFieldT1.getText() + "'");

					String string2 = (textFieldT2.getText().trim().isEmpty())?("''")
							:( "'"+textFieldT2.getText() + "'");					
					
					

					String query = "select id,orderdate,name,total\r\n" + 
							" from InvoiceList\r\n" +
							" where orderdate >="+ string1
							+ " and orderdate <= "+ string2;

					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
											
				
			}
		});
		btnNewButton.setBounds(513, 538, 119, 23);
		contentPane.add(btnNewButton);
		
		JButton btnSearchname = new JButton("Name");
		btnSearchname.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnSearchname.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {

					String string1 = (textFieldSearch2.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldSearch2.getText() + "%'");
					

					String query = "select id,orderdate,name,total" + 
							" from InvoiceList" + 
							" where name like "+ string1;
							
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
										
				
			}
		});
		btnSearchname.setBounds(513, 571, 119, 23);
		contentPane.add(btnSearchname);
		
		JButton btnSearchboth = new JButton("Time+Name");
		btnSearchboth.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnSearchboth.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					

						String string1 = (textFieldT1.getText().trim().isEmpty())?("''")
								:( "'"+textFieldT1.getText() + "'");
	
						String string2 = (textFieldT2.getText().trim().isEmpty())?("''")
								:( "'"+textFieldT2.getText() + "'");					
						
						String string3 = (textFieldSearch2.getText().trim().isEmpty())?("'%'")
								:( "'%"+textFieldSearch2.getText() + "%'");		
						
						if(string1 == "''" ||string2 == "''" ) 
						{
							JOptionPane.showMessageDialog(null, "Please enter time period");
						}
						else {
						
		
						String query = "select id,orderdate,name,total\r\n" + 
								"from InvoiceList\r\n" + 
								"where orderdate >=" + string1
								+ " and orderdate <= " + string2
								+ " and name like "+ string3;
						
						System.out.println(query);
						PreparedStatement pst= connection.prepareStatement(query);
						ResultSet rs = pst.executeQuery();
						//get all information to display
						table.setModel(DbUtils.resultSetToTableModel(rs));
						pst.close();
						rs.close();
					}
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
				
			}
		});
		btnSearchboth.setBounds(501, 605, 129, 23);
		contentPane.add(btnSearchboth);
		
		JButton btnComfirm = new JButton("Print Statement");
		btnComfirm.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnComfirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				

				
				try {
					
					if(!textFieldT1.getText().trim().isEmpty() && !textFieldT2.getText().trim().isEmpty())
					{							
						String string1 = (textFieldT1.getText().trim().isEmpty())?("''")
								:( "'"+textFieldT1.getText() + "'");
	
						String string2 = (textFieldT2.getText().trim().isEmpty())?("''")
								:( "'"+textFieldT2.getText() + "'");					

						temp2[8] = (textFieldT1.getText());
						temp2[9] = (textFieldT2.getText());

						
						String query = "select id as Invoice_number,orderdate,name,total as sum\r\n" + 
								"from InvoiceList\r\n" + 
								"where orderdate >=" + string1
								+ " and orderdate <= " + string2
								+ " and name = '"+ textFieldSearch2.getText() +"'";

	
							PreparedStatement pst= connection.prepareStatement(query);
							System.out.println(query);
							ArrayList<String[]> arr = new ArrayList<>();
							ResultSet rs = pst.executeQuery();
							int index = 0;
							while(rs.next())
							{
								String tt[] = new String[3]; 

								tt[0] = rs.getString("Invoice_number");

								tt[2] = rs.getString("sum");
								tt[1] = rs.getString("orderdate");
	
								index++;
								
								System.out.println("");
								 arr.add(tt);
								 
							}
							pst.close();				
							rs.close();	
							
							
							if( arr.size()==0) JOptionPane.showMessageDialog(null, "Please choose the right time");
							else {
								String statelist [][] = (String[][])arr.toArray(new String[0][]);
								for (int i =0;i<statelist.length;i++)
								{
									for(int j =0;j<statelist[0].length;j++)
									{
										System.out.print( statelist[i][j] + " ");
									}
									System.out.println("");
									//						System.out.print("Total item:"+index );
								}
								temp2[1] = textFieldSearch2.getText();
								Statement.top(statelist,temp2);
//								JOptionPane.showMessageDialog(null, "Statement Print Done.");
//						
								Runtime.getRuntime().exec(sqlcon.wordpath+" "+sqlcon.savepath+"stat.docx");
							}
						}
						else 
						{
							JOptionPane.showMessageDialog(null, "Please have both time period and  selected company by mouse!");
						}
					} catch (Exception e2) {
						e2.printStackTrace();
					}
				/*
				*/
				

				
				
			}
		});
		btnComfirm.setBounds(274, 619, 196, 41);
		contentPane.add(btnComfirm);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(37, 90, 413, 291);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("SimSun", Font.PLAIN, 18));
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
  				try {
//					System.out.println("Hi");
					int row = table.getSelectedRow();
					temp = (table.getModel().getValueAt(row,0)).toString();
				
					System.out.println(temp);
					

	
						String sql2= "select  * "
			
								+ "from saledetail"
								+ " where id = "+ temp;
//								+ "left join InventoryList as tb1 on tb1.inv_id = tb2.id";
						
							PreparedStatement pst= connection.prepareStatement(sql2);
							ResultSet rs = pst.executeQuery();
							table_1.setModel(DbUtils.resultSetToTableModel(rs));
	
						pst.close();
						rs.close();					
						
						String sql3= "select  name "
								
								+ "from invoicelist"
								+ " where id = "+ temp;
//								+ "left join InventoryList as tb1 on tb1.inv_id = tb2.id";
						
							System.out.println(sql3);
							PreparedStatement pst2= connection.prepareStatement(sql3);

							ResultSet rs2 = pst2.executeQuery();
							while(rs2.next())
								{

									textFieldSearch2.setText(rs2.getString("name"));
	
								}				
							
						pst2.close();
						rs2.close();							

				} 
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}				
  				
  				
				
				
				
			}
		});
		scrollPane.setViewportView(table);
		
		JButton btnNewButton_2 = new JButton("LOAD");
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				refreshTable2();
				
			}
		});
		btnNewButton_2.setBounds(50, 421, 93, 23);
		contentPane.add(btnNewButton_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Date Format: yyyy-mm-dd");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_3.setBounds(46, 469, 259, 25);
		contentPane.add(lblNewLabel_1_3);
		
		JLabel lblPrintStatement = new JLabel("Statment system");
		lblPrintStatement.setFont(new Font("Arial Black", Font.BOLD, 19));
		lblPrintStatement.setBounds(36, 11, 203, 31);
		contentPane.add(lblPrintStatement);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(477, 67, 1366, 314);
		contentPane.add(scrollPane_1);
		
		table_1 = new JTable();
		table_1.setFont(new Font("SimSun", Font.PLAIN, 18));
		scrollPane_1.setViewportView(table_1);
		refreshTable2();
		refreshTable1();
	}
}
