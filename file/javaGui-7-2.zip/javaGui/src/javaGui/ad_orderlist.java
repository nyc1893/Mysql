package javaGui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;

public class ad_orderlist extends JFrame {

	private JPanel contentPane;
	private JTable table;
	Connection connection = null;
	private JTable table_1;
	String EID = "";
	String GID = "";
	String FID = "";
	String temp2 = "";
	String tep_subtotal = "";
	String temp_inner="";
	String temp4[] = new String [10];
	String temp3[] = new String [10];
	private JTextField textFieldid;
	private JTextField textFieldqty;
	private JTextField textFieldunit;
	private JTextField textFieldprice;
	private JTextField textFieldtaxrate;
	private JLabel lblChineseName;
	private JLabel lblEnglishName;
	private JTextField textFieldch;
	private JTextField textFielden;
	private JLabel lblInvoiceId;
	private JTextField textFieldfapiao;
	private JTable table_2;
	private JTextField textFieldsearchinv;
	private JButton btnSearchen;
	private JButton btnNewButton_2;
	private JTextField textFieldt1;
	private JTextField textFieldt2;
	private JTextField textFieldname;
	private JLabel lblFrom;
	private JLabel lblPrice_2;
	private JButton btnSearchtime;
	private JButton btnSearchname;
	private JButton btnSearchboth;
	private JTextField textFieldpname;
	private JTextField textFieldremark;
	private JButton btnLoad;
	private JLabel lblEditDetailedInvoice;
	private JTextField textFieldgoodid;
	private JTextField textFieldcsf;
	private JLabel lblProductnameOnly;
	private JButton btnOld;
	private JLabel lblCustomer;
	private JLabel lblEnglishName_2;
	private JLabel lblEnglishName_3;
	private JTextField textFieldponumber;
	private JTextField textFieldorderdate;
	private JLabel lblEnglishName_4;
	private JButton btnUpdate_2;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ad_orderlist frame = new ad_orderlist();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	public void refreshLeftBottom() {
		try {
			
			String query= "select *  "
					+"from InventoryList  ";

//			System.out.println(query); 
//			String query="select * from InventoryList";
				PreparedStatement pst= connection.prepareStatement(query);
				ResultSet rs = pst.executeQuery();
				table_2.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}
	
	
	public void refresh_total()
	{
		// calculate  subtotal
		try {
		 	String query= "select round((qty*price+ qty*price*taxrate),2) as res from  saledetail"
				+" where innerid = "+textFieldid.getText()
						+ " and id = "+textFieldfapiao.getText() ;					
			PreparedStatement pst2= connection.prepareStatement(query);
			System.out.println(query);
			ResultSet rs2 = pst2.executeQuery();
				while(rs2.next())
				{
					tep_subtotal=rs2.getString("res");
				}
	
			pst2.close();			
			
		// update  subtotal
		query= "update saledetail "
				+" set total="+ tep_subtotal
				+" where innerid = "+textFieldid.getText()+""
						+ " and id = "+textFieldfapiao.getText();
		PreparedStatement pst= connection.prepareStatement(query);
		 System.out.println(query);
		pst.execute();
		pst.close();		
		
		// calculate sum of subtotal
	 	query= "select sum(total) as res from saledetail"
			+" where  id = "+textFieldfapiao.getText() ;	
	 	
	 	pst2= connection.prepareStatement(query);
	 	System.out.println(query);
		 rs2 = pst2.executeQuery();
			while(rs2.next())
			{
				tep_subtotal=rs2.getString("res");
			}
			// update total in InvoiceList
		query= "update InvoiceList "
				+" set total="+ tep_subtotal
				+" where id = "+textFieldfapiao.getText();
		System.out.println(query);
		 pst= connection.prepareStatement(query);
		pst.execute();
		pst.close();		
		refreshrightUp();
		refreshLeftUp();
		
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}
	
	public void refreshLeftUp() {
		try {
//			Why add one day here
			String sql2= "select  id as invoicenumber, "
//					+ " date_add(orderdate,interval 1 day) as date, "
					+ " orderdate as date, "
					+ " name, "
					+ " ponumber, "
					+ " total "
					+ " from InvoiceList";
//					+ "left join InventoryList as tb1 on tb1.inv_id = tb2.id";
			
				PreparedStatement pst= connection.prepareStatement(sql2);
				ResultSet rs = pst.executeQuery();
				System.out.println(sql2);
				table_1.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}	
	
	
	public void refreshTable2() {
		try {
			
			String sql2= "select  * "
					+ "from saledetail";
//					+ "left join InventoryList as tb1 on tb1.inv_id = tb2.id";
			
				PreparedStatement pst= connection.prepareStatement(sql2);
				ResultSet rs = pst.executeQuery();
				table.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}
	
	public void refreshrightUp() {
		try {
			
			String sql2= "select  * "
					+ "from saledetail "
					+ "where id = "+ EID;

			
				PreparedStatement pst= connection.prepareStatement(sql2);
				ResultSet rs = pst.executeQuery();
				table.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}	
	}	
	
	/**
	 * Create the frame.
	 */
	public ad_orderlist() {
		connection = sqlcon.db();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1920, 1000);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("load");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				refreshTable2();
			}
		});
		btnNewButton.setBounds(1186, 311, 93, 23);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(690, 99, 1192, 201);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("SimSun", Font.PLAIN, 18));
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
  				try {
//					System.out.println("Hi");
							int row = table.getSelectedRow();
							
							 EID = (table.getModel().getValueAt(row,0)).toString();
							 GID = (table.getModel().getValueAt(row,1)).toString();
//							System.out.println(GID);
							String query= "select * from saledetail "
									+ " where id = "+EID +" and innerid = "+ GID;
							PreparedStatement pst= connection.prepareStatement(query);

							ResultSet rs = pst.executeQuery();
							while(rs.next())
							{

//								temp=rs.getString("id").toString().toCharArray();
								textFieldid.setText(rs.getString("innerid"));
								textFieldfapiao.setText(rs.getString("id"));

		
		 						textFieldch.setText(rs.getString("ch"));
		  						textFielden.setText(rs.getString("en")); 
		  						
		 						textFieldunit.setText(rs.getString("unit"));
		  						textFieldqty.setText(rs.getString("qty"));  	
		  						textFieldprice.setText(rs.getString("price"));
		  						textFieldtaxrate.setText(rs.getString("taxrate")); 	 						
		  						textFieldremark.setText(rs.getString("remark")); 	
		  						textFieldcsf.setText(rs.getString("csf")); 	
		  						textFieldgoodid.setText(rs.getString("goodid")); 	
		  						
							}
							pst.close();
//							System.out.println(temp);

						} 
						catch (Exception e2) 
						{
							e2.printStackTrace();				
						}			
						
				
				
			}
		});
		scrollPane.setViewportView(table);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 125, 651, 222);
		contentPane.add(scrollPane_1);
		
		table_1 = new JTable();
		table_1.setFont(new Font("SimSun", Font.PLAIN, 18));
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try 
				{
				int row = table_1.getSelectedRow();
			     EID = (table_1.getModel().getValueAt(row,0)).toString();
				System.out.println(EID);
				textFieldfapiao.setText(EID);
				String sql2= "select  * "
	
						+ "from saledetail"
						+ " where id = "+ EID;
//						+ "left join InventoryList as tb1 on tb1.inv_id = tb2.id";
				
					PreparedStatement pst= connection.prepareStatement(sql2);
					ResultSet rs = pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(rs));
					
				pst.close();
				rs.close();		
				

				sql2= "select  * "
						+ "from InvoiceList"
						+ " where id = "+ EID;

				 pst= connection.prepareStatement(sql2);

				 rs = pst.executeQuery();
				while(rs.next())
				{
					textFieldponumber.setText(rs.getString("ponumber"));
					textFieldorderdate.setText(rs.getString("orderdate"));

				}
				pst.close();
				rs.close();			

				}
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}						
		
			}
		});
		scrollPane_1.setViewportView(table_1);
		
		JLabel lblNewLabel = new JLabel("Inner ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(1113, 369, 83, 15);
		contentPane.add(lblNewLabel);
		
		textFieldid = new JTextField();
		textFieldid.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldid.setBounds(1186, 363, 85, 21);
		contentPane.add(textFieldid);
		textFieldid.setColumns(10);
		
		textFieldqty = new JTextField();
		textFieldqty.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldqty.setColumns(10);
		textFieldqty.setBounds(1186, 404, 85, 21);
		contentPane.add(textFieldqty);
		
		textFieldunit = new JTextField();
		textFieldunit.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldunit.setColumns(10);
		textFieldunit.setBounds(1186, 442, 85, 21);
		contentPane.add(textFieldunit);
		
		textFieldprice = new JTextField();
		textFieldprice.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldprice.setColumns(10);
		textFieldprice.setBounds(1000, 406, 111, 21);
		contentPane.add(textFieldprice);
		
		textFieldtaxrate = new JTextField();
		textFieldtaxrate.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldtaxrate.setColumns(10);
		textFieldtaxrate.setBounds(1433, 442, 83, 23);
		contentPane.add(textFieldtaxrate);
		
		JLabel lblQty = new JLabel("Qty");
		lblQty.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblQty.setBounds(1142, 399, 54, 24);
		contentPane.add(lblQty);
		
		JLabel lblUnit = new JLabel("Unit");
		lblUnit.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblUnit.setBounds(1142, 440, 54, 18);
		contentPane.add(lblUnit);
		
		JLabel lblPrice = new JLabel("Price");
		lblPrice.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPrice.setBounds(918, 409, 44, 15);
		contentPane.add(lblPrice);
		
		JLabel lblTaxrate = new JLabel("Taxrate");
		lblTaxrate.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblTaxrate.setBounds(1348, 444, 66, 15);
		contentPane.add(lblTaxrate);
		
		lblChineseName = new JLabel("Ch_name");
		lblChineseName.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblChineseName.setBounds(911, 502, 99, 31);
		contentPane.add(lblChineseName);
		
		lblEnglishName = new JLabel("En_name");
		lblEnglishName.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEnglishName.setBounds(911, 553, 99, 23);
		contentPane.add(lblEnglishName);
		
		textFieldch = new JTextField();
		textFieldch.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldch.setColumns(10);
		textFieldch.setBounds(1000, 508, 792, 21);
		contentPane.add(textFieldch);
		
		textFielden = new JTextField();
		textFielden.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFielden.setColumns(10);
		textFielden.setBounds(1000, 555, 809, 21);
		contentPane.add(textFielden);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {

					String sql = "select max(innerid) from saledetail " 
							+ "  where id = "+ EID;

					PreparedStatement pst= connection.prepareStatement(sql);

					ResultSet rs = pst.executeQuery();
  					if(rs.next())
  					{
  						
  						//���� id +1
  						try {
  							String sql2 = "select max(innerid) as res from saledetail "
  									+ "  where id = "+ EID;
  							PreparedStatement pst2= connection.prepareStatement(sql2);

  							ResultSet rs2 = pst2.executeQuery();
  		  					while(rs2.next())
  		  					{
  		  						temp2=rs2.getString("res");
  		  					}
  		  					
  							pst2.close();

//  							System.out.println(temp2); 
  						} catch (Exception e2) {
  							e2.printStackTrace();
  						}	

  					}
  					else {
//  						System.out.println(temp2); 
  						temp2="0";
  					}
					
					


  		  					
  		  				temp2 = Integer.toString(Integer.parseInt((temp2==null)?"0":temp2)+1);
  		  					
  		  				
  		 				 System.out.println(temp2);  		  				
  		  					
  	
  							
							// insert
								String query= "insert saledetail"
										+ " (id , "
										+ "innerid , "
										+ "goodid ,"
										+ "qty ,"
										+ "unit,"
										+ "price ,"
										+ "taxrate ,"
										+ "ch, "
										+ "en, "
										+ "remark, "
										+ "csf "
										+ ") "

										+ "values"
										+ " (" +textFieldfapiao.getText() +","

										+ temp2+","
										+ textFieldgoodid.getText()+ " ,"
										+ textFieldqty.getText()+" ,'"
										+ textFieldunit.getText()+"',"
										+ textFieldprice.getText()+" ,'"
										+ textFieldtaxrate.getText()+ "','"
		
										+ textFieldch.getText()+ "', '"
										+ textFielden.getText()+ "',' "
										+ textFieldremark.getText()+ "', "
//										+"0"
										+ textFieldcsf.getText()
										+ ")";

	
	
					
						System.out.println(query);
								
						 pst= connection.prepareStatement(query);
				
						pst.execute();
						pst.close();
//						
						//update total
					 	 query= "select round((qty*price+ qty*price*taxrate),2) as res from  saledetail"
								+" where innerid = "+temp2
										+ " and id = "+textFieldfapiao.getText() ;					
							PreparedStatement pst2= connection.prepareStatement(query);
							System.out.println(query);
							ResultSet rs2 = pst2.executeQuery();
								while(rs2.next())
								{
									tep_subtotal=rs2.getString("res");
								}
					
							pst2.close();			
							
						// update  subtotal
						query= "update saledetail "
								+" set total="+ tep_subtotal
								+" where innerid = "+temp2+""
										+ " and id = "+textFieldfapiao.getText();
						 pst= connection.prepareStatement(query);
						 System.out.println(query);
						pst.execute();
						pst.close();		
						
						// calculate sum of subtotal
					 	query= "select sum(total) as res from saledetail"
							+" where  id = "+textFieldfapiao.getText() ;	
					 	
					 	pst2= connection.prepareStatement(query);
					 	System.out.println(query);
						 rs2 = pst2.executeQuery();
							while(rs2.next())
							{
								tep_subtotal=rs2.getString("res");
							}
							// update total in InvoiceList
						query= "update InvoiceList "
								+" set total="+ tep_subtotal
								+" where id = "+textFieldfapiao.getText();
						System.out.println(query);
						 pst= connection.prepareStatement(query);
						pst.execute();
						pst.close();		
						refreshrightUp();
						refreshLeftUp();
						
						JOptionPane.showMessageDialog(null, "item added");
						
		
					
					
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}				

				
			}
		});
		btnAdd.setBounds(1551, 887, 93, 23);
		contentPane.add(btnAdd);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					
					// change the saledetail table
					String query= "update saledetail "

							+" set ch='"+ textFieldch.getText()
							+"' ,en='"+ textFielden.getText()
							+"' ,unit='"+ textFieldunit.getText()
							+"' ,taxrate='"+ textFieldtaxrate.getText()
							+"' ,price="+ textFieldprice.getText()
							+" ,qty= "+ textFieldqty.getText()
							+" ,remark ='"+ textFieldremark.getText()
							+"' ,csf ="+ textFieldcsf.getText()

							+" where innerid = "+textFieldid.getText()+""
									+ " and id = "+textFieldfapiao.getText() ;
				
					System.out.println(query);
							
					PreparedStatement pst= connection.prepareStatement(query);
			
					pst.execute();
					pst.close();
					refresh_total();

					
					JOptionPane.showMessageDialog(null, "Data Updated");

					
				} catch (Exception e3) {
					e3.printStackTrace();
				}				

			}
		});
		btnUpdate.setBounds(1071, 311, 93, 23);
		contentPane.add(btnUpdate);
		
		JButton btnRemove = new JButton("Remove");
		btnRemove.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String sql2= "DELETE from saledetail where id = "+ EID +" and innerid = " +GID;
					PreparedStatement pst= connection.prepareStatement(sql2);
					 pst= connection.prepareStatement(sql2);
					System.out.println(sql2);
					pst.execute();
					pst.close();
					String query= "select sum(total) as res from saledetail"
							+" where  id = "+textFieldfapiao.getText() ;						
					PreparedStatement pst2= connection.prepareStatement(query);
				 	System.out.println(query);
				 	ResultSet rs2 = pst2.executeQuery();
						while(rs2.next())
						{
							tep_subtotal=rs2.getString("res");
						}
						// update total in InvoiceList
					 query= "update InvoiceList "
							+" set total="+ ((tep_subtotal==null|tep_subtotal=="" )?"0":tep_subtotal)
							+" where id = "+textFieldfapiao.getText();
					System.out.println(query);
					 pst= connection.prepareStatement(query);
					pst.execute();
					pst.close();		
					refreshrightUp();
					refreshLeftUp();
					
					
					
				} 
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}					

				
			}
		});
		btnRemove.setBounds(950, 311, 111, 23);
		contentPane.add(btnRemove);
		
		lblInvoiceId = new JLabel("Invoice ID");
		lblInvoiceId.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblInvoiceId.setBounds(918, 369, 99, 15);
		contentPane.add(lblInvoiceId);
		
		textFieldfapiao = new JTextField();
		textFieldfapiao.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldfapiao.setColumns(10);
		textFieldfapiao.setBounds(1006, 367, 97, 21);
		contentPane.add(textFieldfapiao);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(730, 665, 1043, 211);
		contentPane.add(scrollPane_2);
		
		table_2 = new JTable();
		table_2.setFont(new Font("SimSun", Font.PLAIN, 18));
		table_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table_2.getSelectedRow();
			     FID = (table_2.getModel().getValueAt(row,0)).toString();
				System.out.println(FID);
				
  				try {
//					System.out.println("Hi");
  					
							

							String query= "select * from InventoryList "
									+ " where inv_id = "+FID;
							PreparedStatement pst= connection.prepareStatement(query);
							System.out.println(query);
							
	  						textFieldqty.setText("1");  
	  						textFieldtaxrate.setText("0"); 
	  						textFieldcsf.setText("0");
							ResultSet rs = pst.executeQuery();
							while(rs.next())
							{

//								temp=rs.getString("id").toString().toCharArray();
								textFieldid.setText("");
//								textFieldfapiao.setText(rs.getString("id"));

								textFieldgoodid.setText(rs.getString("inv_id"));
		 						textFieldch.setText(rs.getString("ch_name"));
		  						textFielden.setText(rs.getString("en_name")); 

		 						textFieldunit.setText(rs.getString("itemunit"));
		  							
		  						textFieldprice.setText(rs.getString("itemprice"));
 	
		  						textFieldremark.setText(rs.getString("remark")); 	
		  						
		
		  						
							}
							pst.close();
//							System.out.println(temp);

						} 
						catch (Exception e2) 
						{
							e2.printStackTrace();				
						}			
						
				
				
			}
		});
		scrollPane_2.setViewportView(table_2);
		
		JButton btnRefresh = new JButton("Refresh");
		btnRefresh.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnRefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				refreshLeftBottom();
				
			}
		});
		btnRefresh.setBounds(1654, 887, 93, 23);
		contentPane.add(btnRefresh);
		
		textFieldsearchinv = new JTextField();
		textFieldsearchinv.setColumns(10);
		textFieldsearchinv.setBounds(991, 901, 237, 21);
		contentPane.add(textFieldsearchinv);
		
		btnSearchen = new JButton("EN");
		btnSearchen.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnSearchen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {

					String string1 = (textFieldsearchinv.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldsearchinv.getText() + "%'");
					
					String query =
							"select tb1.inv_id," + 
							" tb1.en_name , tb1.ch_name, tb1.itemunit,tb1.itemprice " + 
							" from InventoryList as tb1 " 
							+ " WHERE en_name LIKE "
							+ string1;
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_2.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
				
				
			}
		});
		btnSearchen.setBounds(1251, 887, 93, 23);
		contentPane.add(btnSearchen);
		
		btnNewButton_2 = new JButton("CH");
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textFieldsearchinv.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldsearchinv.getText() + "%'");
					
					String query =
							"select tb1.inv_id," + 
							" tb1.en_name , tb1.ch_name, tb1.itemunit,tb1.itemprice " + 
							" from InventoryList as tb1 " 
							+ " WHERE ch_name LIKE "
							+ string1;
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_2.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}								
				
				
				
			}
		});
		btnNewButton_2.setBounds(1251, 921, 93, 23);
		contentPane.add(btnNewButton_2);
		
		textFieldt1 = new JTextField();
		textFieldt1.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldt1.setColumns(10);
		textFieldt1.setBounds(110, 39, 93, 21);
		contentPane.add(textFieldt1);
		
		textFieldt2 = new JTextField();
		textFieldt2.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldt2.setColumns(10);
		textFieldt2.setBounds(239, 39, 107, 21);
		contentPane.add(textFieldt2);
		
		textFieldname = new JTextField();
		textFieldname.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldname.setColumns(10);
		textFieldname.setBounds(445, 60, 155, 23);
		contentPane.add(textFieldname);
		
		lblFrom = new JLabel("From");
		lblFrom.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblFrom.setBounds(56, 39, 44, 18);
		contentPane.add(lblFrom);
		
		lblPrice_2 = new JLabel("to");
		lblPrice_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPrice_2.setBounds(212, 39, 61, 18);
		contentPane.add(lblPrice_2);
		
		btnSearchtime = new JButton("searchTime");
		btnSearchtime.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnSearchtime.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textFieldt1.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt1.getText() + "'");

					String string2 = (textFieldt2.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt2.getText() + "'");					
					
					
					String query = " select id as invoiceID, orderdate, name, total " + 
							"from InvoiceList  where orderdate >=" + string1+ " "
									+ "and orderdate <=" + string2;

					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_1.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
				
				
			}
		});
		btnSearchtime.setBounds(200, 71, 148, 43);
		contentPane.add(btnSearchtime);
		
		btnSearchname = new JButton("Search");
		btnSearchname.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnSearchname.setVerticalAlignment(SwingConstants.BOTTOM);
		btnSearchname.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textFieldname.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldname.getText() + "%'");
					
//					String query = "select DISTINCT tb3.id as Invoice_number, tb3.orderdate,  tb4.name, tb3.sum \r\n" + 
//							"from (select DISTINCT tb1.id, tb2.orderdate,  tb2.cid, tb1.sum \r\n" + 
//							"from (select id, sum(qty*price) as sum \r\n" + 
//							"from saledetail group by id) as tb1\r\n" + 
//							"left join InvoiceList as tb2\r\n" + 
//							"on tb2.id = tb1.id\r\n" + 
//							")as tb3\r\n" + 
//							"inner join(select * from CustomList where name like " +string1+")  as tb4\r\n" + 
//							"on tb3.cid = tb4.id";

					String query = "select id as invoiceID, orderdate, name,ponumber, total "+
					"from InvoiceList  where name like " +string1;
					
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_1.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}									
				
				
			}
		});
		btnSearchname.setBounds(610, 62, 93, 23);
		contentPane.add(btnSearchname);
		
		btnSearchboth = new JButton("search");
		btnSearchboth.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnSearchboth.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {

					String string1 = (textFieldt1.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt1.getText() + "'");

					String string2 = (textFieldt2.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt2.getText() + "'");	
					
					String string3 = (textFieldname.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldname.getText() + "%'");							
					
					String query = "select id as invoiceID, orderdate, name,ponumber, total\r\n" + 
							"from InvoiceList   where orderdate >="+string1+" and orderdate <= "+string2+" " + 
							"and name like "+string3;

					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_1.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
								
				
				
			}
		});
		btnSearchboth.setBounds(39, 436, 123, 31);
		contentPane.add(btnSearchboth);
		
		textFieldpname = new JTextField();
		textFieldpname.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldpname.setColumns(10);
		textFieldpname.setBounds(353, 394, 170, 31);
		contentPane.add(textFieldpname);
		
		JButton btnDoIt = new JButton("EN");
		btnDoIt.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnDoIt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {

					String string1 = (textFieldt1.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt1.getText() + "'");

					String string2 = (textFieldt2.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt2.getText() + "'");	
					
					String string3 = (textFieldpname.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldpname.getText() + "%'");							
					
//					String query = "select id as invoiceID, orderdate, name, total\r\n" + 
//							"from InvoiceList   where orderdate >"+string1+" and orderdate < "+string2+" " + 
//							"and name like "+string3;

					
					String query = "select  tb1.id,  tb1.orderdate,tb1.name, tb1.ponumber,tb1.total \r\n" + 
					"from (select * from InvoiceList  where orderdate >="+string1 +" and "
							+ "orderdate <= "+string2 + ")as tb1 \r\n" + 
					"inner join (select * from saledetail where en like "+string3 +") as tb2 \r\n" + 
					"on tb2.id = tb1.id";
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_1.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}							
				
				
			}
		});
		btnDoIt.setBounds(39, 502, 61, 31);
		contentPane.add(btnDoIt);
		
		JButton btnCn = new JButton("CN");
		btnCn.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnCn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textFieldt1.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt1.getText() + "'");

					String string2 = (textFieldt2.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt2.getText() + "'");	
					
					String string3 = (textFieldpname.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldpname.getText() + "%'");							
					
//					String query = "select id as invoiceID, orderdate, name, total\r\n" + 
//							"from InvoiceList   where orderdate >"+string1+" and orderdate < "+string2+" " + 
//							"and name like "+string3;

					
					String query = "select  tb1.id,  tb1.orderdate, tb1.total,tb1.name \r\n" + 
					"from (select * from InvoiceList  where orderdate >="+string1 +" and "
							+ "orderdate <= "+string2 + ")as tb1 \r\n" + 
					"inner join (select * from saledetail where ch like "+string3 +") as tb2 \r\n" + 
					"on tb2.id = tb1.id";
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_1.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}							
								
				
				
				
			}
		});
		btnCn.setBounds(142, 502, 61, 31);
		contentPane.add(btnCn);
		
		textFieldremark = new JTextField();
		textFieldremark.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldremark.setColumns(10);
		textFieldremark.setBounds(1000, 598, 488, 23);
		contentPane.add(textFieldremark);
		
		JLabel lblRemark = new JLabel("Remark");
		lblRemark.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblRemark.setBounds(918, 601, 107, 15);
		contentPane.add(lblRemark);
		
		btnLoad = new JButton("Load");
		btnLoad.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnLoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				refreshLeftUp();
			}
		});
		btnLoad.setBounds(20, 358, 93, 23);
		contentPane.add(btnLoad);
		
		JButton btncn = new JButton("CN");
		btncn.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btncn.setBounds(137, 577, 66, 31);
		contentPane.add(btncn);
		
		JButton btnen = new JButton("EN");
		btnen.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnen.setBounds(36, 577, 64, 31);
		contentPane.add(btnen);
		
		JButton btnPtorder = new JButton("Print_order");
		btnPtorder.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnPtorder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
//				if(EID == ""  ) 
//				{
//					JOptionPane.showMessageDialog(null, "Please select a invoice item!");
//				}
				try {
					String query= "select *  from invoicelist "
							+ " where id = '"+ EID +"' ";
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
//					String [] custom = {"0.0077","name","addr","city","state","zip","Phone"};
					while(rs.next())
					{
						temp4[0] = (rs.getString("taxrate"));
						temp4[1] = (rs.getString("name"));
						temp4[2] = (rs.getString("addr"));
						temp4[3] = (rs.getString("city"));
						temp4[4] = (rs.getString("state"));
						temp4[5] = (rs.getString("zip"));
						temp4[6] = (rs.getString("Phone"));
						temp4[7] = GenOrder.convTime2(rs.getString("orderdate"));
						temp4[8] = (rs.getString("ponumber"));
						temp4[9] = (rs.getString("term"));
					}				

					
					pst.close();
					rs.close();
//
					for(String word: temp4)
					{
						System.out.println(word);
					}
					
//					System.out.println(temp2[1]);
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
				
				try {
					
					String query= "select *  from saledetail "
							+ " where id = '"+ EID +"' ";				
					PreparedStatement pst= connection.prepareStatement(query);
					System.out.println(query);
					ArrayList<String[]> arr = new ArrayList<>();
					ResultSet rs = pst.executeQuery();
					int index = 0;
					
					while(rs.next())
					{
						String tt[] = new String[6]; 
		
//						new String[]{"11","bag","Taita", "22.00", "Yes", "̫̫����"},
						
						tt[0] = rs.getString("qty");
						tt[1] = rs.getString("unit");
						tt[2] = rs.getString("price");
						tt[3] = rs.getString("taxrate");
						tt[4] = rs.getString("en");
						String ck = rs.getString("remark");
						String ck2 = rs.getString("ch");
						System.out.println("CK");
						System.out.println(ck);
						tt[5] = (ck==null|| ck.equals("")|| ck.equals(" ")|| ck.equals("  "))?ck2:ck2+" ("+ck+")";
						index++;
						
//						System.out.println("");
						 arr.add(tt);
						 
					}
					pst.close();				
					rs.close();	
					
					if( arr.size()==0) JOptionPane.showMessageDialog(null, "There is no item in the invoice");
					else {
						String statelist [][] = (String[][])arr.toArray(new String[0][]);
						for (int i =0;i<statelist.length;i++)
						{
							for(int j =0;j<statelist[0].length;j++)
							{
								System.out.print( statelist[i][j] + " ");
							}
							System.out.println("");
							//						System.out.print("Total item:"+index );
						}
						GenOrder.top( temp4,statelist,EID);
//						JOptionPane.showMessageDialog(null, "Invoice ID = " + temp+ " generated." );
//					
						Runtime.getRuntime().exec(sqlcon.wordpath+" "+sqlcon.savepath+"invoice.docx");
					}
//					System.out.println(temp2[1]);
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
												
				
				
			}
		});
		btnPtorder.setBounds(9, 91, 155, 23);
		contentPane.add(btnPtorder);
		
		lblEditDetailedInvoice = new JLabel("Edit detailed Invoice");
		lblEditDetailedInvoice.setFont(new Font("Arial Black", Font.BOLD, 16));
		lblEditDetailedInvoice.setBounds(10, 0, 263, 28);
		contentPane.add(lblEditDetailedInvoice);
		
		JLabel lblGoodid = new JLabel("GoodID");
		lblGoodid.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblGoodid.setBounds(1281, 363, 83, 15);
		contentPane.add(lblGoodid);
		
		textFieldgoodid = new JTextField();
		textFieldgoodid.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldgoodid.setColumns(10);
		textFieldgoodid.setBounds(1361, 363, 93, 21);
		contentPane.add(textFieldgoodid);
		
		JLabel lblCs = new JLabel("CS?");
		lblCs.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblCs.setBounds(918, 447, 83, 15);
		contentPane.add(lblCs);
		
		textFieldcsf = new JTextField();
		textFieldcsf.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldcsf.setColumns(10);
		textFieldcsf.setBounds(1000, 444, 93, 21);
		contentPane.add(textFieldcsf);
		
		lblProductnameOnly = new JLabel("Product Name");
		lblProductnameOnly.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblProductnameOnly.setBounds(383, 361, 137, 31);
		contentPane.add(lblProductnameOnly);
		
		JButton btnDoIt_1 = new JButton("EN");
		btnDoIt_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnDoIt_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
						String string3 = (textFieldpname.getText().trim().isEmpty())?("'%'")
								:( "'%"+textFieldpname.getText() + "%'");							
						
		//				String query = "select id as invoiceID, orderdate, name, total\r\n" + 
		//						"from InvoiceList   where orderdate >"+string1+" and orderdate < "+string2+" " + 
		//						"and name like "+string3;
		
						
						String query = "select  tb1.id,  tb1.orderdate, tb1.total,tb1.name \r\n" + 
						"from  InvoiceList as tb1 " + 
						"inner join (select * from saledetail where en like "+string3 +") as tb2 \r\n" + 
						"on tb2.id = tb1.id";
						System.out.println(query);
						PreparedStatement pst= connection.prepareStatement(query);
						ResultSet rs = pst.executeQuery();
						//get all information to display
						table_1.setModel(DbUtils.resultSetToTableModel(rs));
						pst.close();
						rs.close();				
					
				} catch (Exception e2) {
				e2.printStackTrace();
			}				
				
			}
		});
		btnDoIt_1.setBounds(546, 358, 66, 30);
		contentPane.add(btnDoIt_1);
		
		JButton btnCn_1 = new JButton("CN");
		btnCn_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String string3 = (textFieldpname.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldpname.getText() + "%'");							
					
	//				String query = "select id as invoiceID, orderdate, name, total\r\n" + 
	//						"from InvoiceList   where orderdate >"+string1+" and orderdate < "+string2+" " + 
	//						"and name like "+string3;
	
					
					String query = "select  tb1.id,  tb1.orderdate,tb1.name,tb1.ponumber, tb1.total \r\n" + 
					"from  InvoiceList as tb1 " + 
					"inner join (select * from saledetail where cn like "+string3 +") as tb2 \r\n" + 
					"on tb2.id = tb1.id";
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_1.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();				
				
			} catch (Exception e2) {
			e2.printStackTrace();
		}				
							
				
			}
		});
		btnCn_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnCn_1.setBounds(544, 400, 68, 27);
		contentPane.add(btnCn_1);
		
		btnOld = new JButton("Old");
		btnOld.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String sql2= "select * from revorderlist";

					PreparedStatement pst= connection.prepareStatement(sql2);
//					System.out.println(sql2);
					ArrayList<String[]> arr = new ArrayList<>();
					ResultSet rs = pst.executeQuery();
					int index = 0;
					while(rs.next())
					{
						String tt[] = new String[10]; 
//						System.out.print(rs.getString("en") + " ");
//						System.out.print(rs.getString("ch") + " ");
//						System.out.print(rs.getString("price") + " ");
//						System.out.print(rs.getString("unit") + " ");
//						
//						System.out.print(rs.getString("qty") + " ");
//						System.out.print(rs.getString("taxrate") + " ");
						

						
						tt[0] = rs.getString("id");
						tt[1] = rs.getString("innerid");
						tt[2] = rs.getString("goodid");
						
						tt[3] = rs.getString("qty");
						tt[4] = rs.getString("unit");
						tt[5] = rs.getString("price");	

						tt[6] = rs.getString("taxrate");
						tt[7] = rs.getString("ch");
						tt[8] = rs.getString("en");							
						tt[9] = rs.getString("remark");		
						
//						tt[3] = rs.getString("buy").replace("0E-8","0.00");
//						tt[4] = rs.getString("sale").replace("0E-8","0.00");
//						tt[5] = rs.getString("storing").replace("0E-8","0.00");
//						tt[6] = rs.getString("cost");


						index++;
						
						System.out.println("");
						 arr.add(tt);
						 
					}
					String goods [][] = (String[][])arr.toArray(new String[0][]);

					gen_xls.trans_data( goods);
//					JOptionPane.showMessageDialog(null, "Save Product Info done!");
//					System.out.print("Total item:"+index );

					Runtime.getRuntime().exec(sqlcon.exepath+" "+sqlcon.savepath+"temp.xls");
//					Runtime.getRuntime().exec(sqlcon.exepath+" F:/generated/backup/product.xls");
					pst.close();				
					rs.close();				
				} catch (Exception e2) {
					e2.printStackTrace();
				}
										
			}
		});
		btnOld.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnOld.setBounds(1301, 314, 93, 23);
		contentPane.add(btnOld);
		
		JLabel lblEnglishName_1 = new JLabel("Time + Product Name");
		lblEnglishName_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEnglishName_1.setBounds(32, 468, 206, 23);
		contentPane.add(lblEnglishName_1);
		
		lblCustomer = new JLabel("Customer");
		lblCustomer.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblCustomer.setBounds(477, 26, 123, 23);
		contentPane.add(lblCustomer);
		
		lblEnglishName_2 = new JLabel("Time + Customer");
		lblEnglishName_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEnglishName_2.setBounds(32, 402, 171, 23);
		contentPane.add(lblEnglishName_2);
		
		lblEnglishName_3 = new JLabel("Time + Customer + Product Name");
		lblEnglishName_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEnglishName_3.setBounds(36, 544, 283, 23);
		contentPane.add(lblEnglishName_3);
		
		textFieldponumber = new JTextField();
		textFieldponumber.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldponumber.setColumns(10);
		textFieldponumber.setBounds(247, 669, 237, 31);
		contentPane.add(textFieldponumber);
		
		JLabel lblPoNumber = new JLabel("PO Number");
		lblPoNumber.setVerticalAlignment(SwingConstants.BOTTOM);
		lblPoNumber.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPoNumber.setBounds(272, 632, 137, 31);
		contentPane.add(lblPoNumber);
		
		JLabel lblOrderDate = new JLabel("Order Date");
		lblOrderDate.setVerticalAlignment(SwingConstants.BOTTOM);
		lblOrderDate.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblOrderDate.setBounds(272, 701, 137, 31);
		contentPane.add(lblOrderDate);
		
		textFieldorderdate = new JTextField();
		textFieldorderdate.setFont(new Font("SimSun", Font.PLAIN, 18));
		textFieldorderdate.setColumns(10);
		textFieldorderdate.setBounds(247, 743, 237, 31);
		contentPane.add(textFieldorderdate);
		
		JButton btnUpdate_1 = new JButton("Update");
		btnUpdate_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					// change the saledetail table
					String query= "update InvoiceList "

							+" set ponumber= '"+ textFieldponumber.getText()
							+" ', orderdate = '"+ textFieldorderdate.getText()
							+"' where  id = "+EID ;
				
					System.out.println(query);
							
					PreparedStatement pst= connection.prepareStatement(query);
			
					pst.execute();
					pst.close();
					refreshLeftUp();

					
					JOptionPane.showMessageDialog(null, "Data Updated");

					
				} catch (Exception e3) {
					e3.printStackTrace();
				}						
				
			}
		});
		btnUpdate_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnUpdate_1.setBounds(517, 668, 107, 32);
		contentPane.add(btnUpdate_1);
		
		lblEnglishName_4 = new JLabel("Delete One Order");
		lblEnglishName_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEnglishName_4.setBounds(394, 468, 170, 23);
		contentPane.add(lblEnglishName_4);
		
		btnUpdate_2 = new JButton("DEL");
		btnUpdate_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
  				try {
  					int input =JOptionPane.showConfirmDialog(null, "DELETE Order NO."+textFieldfapiao.getText()
  							+ "?");
  					 if(input==0)
  					 {
						String query= "DELETE from InvoiceList"
								+ " where id = "+ textFieldfapiao.getText()+" ";
						PreparedStatement pst= connection.prepareStatement(query);
						System.out.println(query);
	
						pst.execute();
						
						
						
						 query= "DELETE from saledetail"
								+ " where id = "+ textFieldfapiao.getText()+" ";
						 pst= connection.prepareStatement(query);
						System.out.println(query);
						refreshLeftUp();
						refreshrightUp();
						pst.execute();					
						pst.close();
						
						
  					 }
					} 
					catch (Exception e2) 
					{
						e2.printStackTrace();				
					}				
									
				
			}
		});
		btnUpdate_2.setForeground(Color.RED);
		btnUpdate_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnUpdate_2.setBounds(546, 463, 66, 32);
		contentPane.add(btnUpdate_2);
		refreshTable2();
		refreshLeftUp();
		refreshLeftBottom();
	}
}
