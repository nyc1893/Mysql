package web_design;

import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.sql.*;
 
public class creat_table {
 

    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
    static final String DB_URL = "jdbc:mysql://localhost:3306/RUNOOB?characterEcoding=utf-8&useSSL=false&serverTimezone=America/Los_Angeles";
 
    // ���ݿ���û��������룬��Ҫ�����Լ�������
    static final String USER = "root";
    static final String PASS = "123";

    
    
    public static void main(String[] args) 
    {
        Connection conn = null;
        Statement stat = null;
        
        
        try{
            // ע�� JDBC ����
            Class.forName(JDBC_DRIVER);
        
            // ������
            System.out.println("�������ݿ�...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
        
            // ִ�в�ѯ
            System.out.println(" ʵ����Statement����...");

            //String sql;
            
            stat = conn.createStatement();	
            //�������ݿ�hello
            
//            stat.executeUpdate("DROP TABLE test");
            //stat.executeUpdate("create table test(id int,ch_name varchar(80);");
            //stat.executeUpdate("create table IF NOT EXISTS test(id int,price decimal(10,2), number int,ch_name varchar(80),en_name varchar(80),unit varchar(20))");
            stat.executeUpdate("create table IF NOT EXISTS test(id int,ch_name varchar(80))");
            stat.executeUpdate(AddET2("test",1,"����ǽ���"));
            stat.executeUpdate(AddET2("test",2,"�ݲ�"));
            stat.executeUpdate(AddET2("test",3,"������"));
            stat.executeUpdate(AddET2("test",4,"���"));
            stat.executeUpdate(AddET2("test",5,"abc"));            
            
            
          //  stat.executeUpdate("insert into test values (1,"cctv");");
          //  stat.executeUpdate("insert into test values (2,"bbc");");

            stat.close();
            conn.close();
            System.out.println(" copy down.");
   
        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stat!=null) stat.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("Goodbye!");
    }
    
    public static String AddET2(String tablename,int id, String chname )
	{
    	String result = String.format("insert into %s values(%d,\"%s\");", tablename,id,chname);
    	System.out.println(result);
    	return result;

	}

    
    
    
}