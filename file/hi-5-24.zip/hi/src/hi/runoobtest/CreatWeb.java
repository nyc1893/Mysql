package hi.runoobtest;
import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.sql.*;
 
public class CreatWeb {
 
    // MySQL 8.0 ���°汾 - JDBC �����������ݿ� URL
    //static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
    //static final String DB_URL = "jdbc:mysql://localhost:3306/RUNOOB";
 
    // MySQL 8.0 ���ϰ汾 - JDBC �����������ݿ� URL
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
    static final String DB_URL = "jdbc:mysql://localhost:3306/RUNOOB?characterEcoding=utf-8&useSSL=false&serverTimezone=UTC";
 
 
    // ���ݿ���û��������룬��Ҫ�����Լ�������
    static final String USER = "root";
    static final String PASS = "123";

    
    
    public static void main(String[] args) 
    {
        Connection conn = null;
        Statement stat = null;
        
        
        
        try{
            // ע�� JDBC ����
            Class.forName(JDBC_DRIVER);
        
            // ������
            System.out.println("�������ݿ�...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
        
            // ִ�в�ѯ
            System.out.println(" ʵ����Statement����...");
            //stmt = conn.createStatement();
            String sql;
            
            stat = conn.createStatement();	
            //�������ݿ�hello
            stat.executeUpdate("DROP TABLE test");
            //stat.executeUpdate("create table IF NOT EXISTS test(id int,price decimal(10,2), number int,ch_name varchar(80),en_name varchar(80),unit varchar(20))");
            //
            stat.executeUpdate("create table IF NOT EXISTS test(id int,ch_name varchar(80);");
        //    stat.executeUpdate("insert into test values (1,"cctv");" );
            
            
            /*
            stat.executeUpdate(AddET("test",1,10.02,1,"����ǽ���","SOY Bean","bottle"));
            stat.executeUpdate(AddET("test",2,20.50,3,"���꽴","Dou Ban Jiang","bottle"));
            stat.executeUpdate(AddET("test",3,33.89,5,"������","fangbianmian","pkg"));
            stat.executeUpdate(AddET("test",4,1.6,300,"�཭��","Baby Bok Choy","lb"));
            stat.executeUpdate(AddET("test",4,1.6,300,"�����в�","Bok Choy Miu ","lb"));*/
            //�򿪴��������ݿ�
            stat.close();
            conn.close();
            //String  url = "jdbc:mysql://localhost:3306/hello?characterEcoding=utf-8&useSSL=false&serverTimezone=UTC";
   


        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stat!=null) stat.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("Goodbye!");
    }
    
    
    



    
    public static String AddET(String tablename,int id,double price,int number, String chname,String enname,String unitname )
	{
    	String result = String.format("insert into %s values(%d,%2f,%d,\"%s\",\"%s\",\"%s\");", tablename,id,price,number,chname,enname,unitname);
    	System.out.println(result);
    	return result;

	}


    
}