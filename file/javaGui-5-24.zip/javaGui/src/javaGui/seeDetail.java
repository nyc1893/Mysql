package javaGui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;

public class seeDetail extends JFrame {

	private JPanel contentPane;
	Connection connection = null;
	private JTable table;
	private JTable table_1;
	private JTextField textFields1;
	private JTextField textFields2;
	private JButton btnPrint;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					seeDetail frame = new seeDetail();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	
	public void refreshTable() {
		try {
			String query= "select cid,name,count(*) as orders,sum(total) as total\r\n" + 
					"  from InvoiceList \r\n" + 
					"group by name,cid";
			PreparedStatement pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			//get all information to display
			table_1.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		
	}
	public seeDetail() {
		connection = sqlcon.db();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1273, 791);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		table = new JTable();
		table.setBounds(5, 5, 1247, 0);
		contentPane.add(table);
		
		JLabel lblNewLabel = new JLabel("From");
		lblNewLabel.setBounds(36, 68, 54, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblTo = new JLabel("To");
		lblTo.setBounds(147, 68, 34, 15);
		contentPane.add(lblTo);
		
		textFields1 = new JTextField();
		textFields1.setBounds(71, 65, 66, 21);
		contentPane.add(textFields1);
		textFields1.setColumns(10);
		
		textFields2 = new JTextField();
		textFields2.setColumns(10);
		textFields2.setBounds(188, 65, 66, 21);
		contentPane.add(textFields2);
		
		JButton btnNewButton = new JButton("SearchTime");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textFields1.getText().trim().isEmpty())?("''")
							:( "'"+textFields1.getText() + "'");

					String string2 = (textFields2.getText().trim().isEmpty())?("''")
							:( "'"+textFields2.getText() + "'");					
					
					
					String query = " select cid,name,count(*) as orders,sum(total) as total\r\n" + 
							"  from InvoiceList as tb1\r\n" + 
							" where orderdate >="+string1
							+ " and orderdate <= " + string2+
							"group by name,cid";


					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_1.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}							
				
				
			}

			
		});
		btnNewButton.setBounds(264, 64, 108, 23);
		contentPane.add(btnNewButton);
		
		JButton btnLoad = new JButton("Load");
		btnLoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				refreshTable();
				
			}
			
		});
		btnLoad.setBounds(1094, 676, 93, 23);
		contentPane.add(btnLoad);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(335, 177, 858, 480);
		contentPane.add(scrollPane);
		
		table_1 = new JTable();
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				
				
			}
		});
		scrollPane.setViewportView(table_1);
		
		btnPrint = new JButton("PrintTime");
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					if(textFields1.getText().trim().isEmpty() || textFields2.getText().trim().isEmpty())
					{
						JOptionPane.showMessageDialog(null, "Please Enter the time!");
					}
					else 
					{
						String string1 = (textFields1.getText().trim().isEmpty())?("''")
								:( "'"+textFields1.getText() + "'");

						String string2 = (textFields2.getText().trim().isEmpty())?("''")
								:( "'"+textFields2.getText() + "'");					
						
						
						String query = " select cid,name,count(*) as orders,sum(total) as total\r\n" + 
								"  from InvoiceList as tb1\r\n" + 
								" where orderdate >="+string1
								+ " and orderdate <= " + string2+
								"group by name,cid";

//						JOptionPane.showConfirmDialog(null, "generate a report from "+string1 +" to "+ string2);
						System.out.println(query);
						PreparedStatement pst= connection.prepareStatement(query);

						ArrayList<String[]> arr = new ArrayList<>();
						ResultSet rs = pst.executeQuery();
						int index = 0;
						while(rs.next())
						{
							String tt[] = new String[4]; 
							tt[0] = rs.getString("cid");
							tt[1] = rs.getString("name");
							tt[2] = rs.getString("orders");
							tt[3] = rs.getString("total");
							index++;
							
							System.out.println("");
							 arr.add(tt);
							 
						}
						
						
						pst.close();
						rs.close();
						
						
						String statelist [][] = (String[][])arr.toArray(new String[0][]);
						for (int i =0;i<statelist.length;i++)
						{
							for(int j =0;j<statelist[0].length;j++)
							{
								System.out.print( statelist[i][j] + " ");
							}
							System.out.println("");
							//						System.out.print("Total item:"+index );
						}						
					
					String temp2[] = new String[2];
					
					temp2[0] = textFields1.getText();
					temp2[1] = 	textFields2.getText();

					detail_doc.top(statelist,temp2);

					Runtime.getRuntime().exec(sqlcon.wordpath+" "+sqlcon.savepath+"detail.docx");					
					}
				} catch (Exception e2) {
					e2.printStackTrace();
				}							
								
				
				
			}
		});
		btnPrint.setBounds(969, 676, 93, 23);
		contentPane.add(btnPrint);
		
		JLabel lblSaleingRecord = new JLabel("Selling Record");
		lblSaleingRecord.setFont(new Font("Arial Black", Font.BOLD, 16));
		lblSaleingRecord.setBounds(35, 11, 263, 28);
		contentPane.add(lblSaleingRecord);
		refreshTable();
	}
}
