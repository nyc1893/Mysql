package javaGui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.awt.Font;

public class fromseller extends JFrame {

	private JPanel contentPane;
	Connection connection = null;
	String temp1 ="";
	String temp2 ="";
	String temp3 = "";
	String temp4 = "";
//	char temp1[] = new char [100];
//	char temp2[] = new char [100];
	private JTable table;
	private JTable table_1;
	private JTable table_2;
	private JTextField textField_seller_name;
	private JTextField textField_ch_name;
	private JTextField textField_case_unit;
	private JTextField textField_case_number;
	private JTextField textField_en_name;
	private JTextField textField_trans_date;
	private JTextField textField_seller_id;
	private JTextField textFieldSearch;
	private JTextField textField_city;
	private JTextField textField_id;
	private JTextField textFieldSearch2;
	private JTextField textField_s1;
	private JTextField textField_s2;
	private JTextField textField_buylist_id;
	private JTextField textField_search;
	private JTextField textField_qty;
	private JTextField textField_Cost;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					fromseller frame = new fromseller();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void refreshTable1() {

		try {
			String query= " select inv_id,ch_name, en_name "+
					"from inventorylist ";

//			String query= "select * from storelist";
			System.out.println(query);

			PreparedStatement pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			//get all information to display
			table.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		
	}
	
	
	public void refreshTable2() {

		try {
			String query= " select id,name,city"+
					" from SellerList ";

//			String query= "select * from storelist";
			System.out.println(query);

			PreparedStatement pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			//get all information to display
			table_1.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		
	}
	public void refreshTable3() {

		try {
			String query= "select DISTINCT tb1.id,tb2.ch_name, tb2.en_name,tb3.name, tb1.transdate, tb1.largenum,tb1.cost   \r\n" + 
					"from (buylist tb1 inner join sellerlist tb3 on tb1.sid= tb3.id )\r\n" + 
					"inner join inventorylist tb2 \r\n" + 
					"on tb2.inv_id= tb1.invid "
					+ "ORDER BY transdate;\r\n" ;

//			String query= "select * from storelist";
			System.out.println(query);

			PreparedStatement pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			//get all information to display
			table_2.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		
	}
		
	   public static String getSysTime()
	   {
	        SimpleDateFormat sdf = new SimpleDateFormat();// ��ʽ��ʱ�� 
	        
//	        sdf.applyPattern("MM/dd/yyyy");
	        
	        sdf.applyPattern("yyyy-MM-dd");// aΪam/pm�ı��  
	        Date date = new Date();// ��ȡ��ǰʱ�� 
	        
	        String shijian  = sdf.format(date);
	        System.out.println(shijian); 
	        return shijian;
	   }
	   

	
	/**
	 * Create the frame.
	 */
	public fromseller() {
		connection = sqlcon.db();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 941, 724);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(50, 52, 351, 151);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
  				try {
//					System.out.println("Hi");
					int row = table.getSelectedRow();
					temp1 = (table.getModel().getValueAt(row,0)).toString();
					System.out.println(temp1);
					
					String query= " select inv_id,ch_name, en_name, caseunit "+
							"from inventorylist " 
							+ " where inv_id = '"+temp1 +"' ";
					System.out.println(query);

					PreparedStatement pst= connection.prepareStatement(query);

					ResultSet rs = pst.executeQuery();
					while(rs.next())
					{

//						temp1=rs.getString("id").toString().toCharArray();
						textField_id.setText(rs.getString("inv_id"));
  						textField_en_name.setText(rs.getString("en_name"));
  						textField_ch_name.setText(rs.getString("ch_name"));
  						textField_case_unit.setText(rs.getString("caseunit"));

					}
					pst.close();
//					System.out.println(temp);

				} 
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}				
								
				
			}
		});
		scrollPane.setViewportView(table);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(520, 32, 273, 161);
		contentPane.add(scrollPane_1);
		
		table_1 = new JTable();
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
  				try {
//					System.out.println("Hi");
					int row = table_1.getSelectedRow();
					temp2 = (table_1.getModel().getValueAt(row,0)).toString();
					System.out.println(temp2);
					
					String query= " select id,name, city "+
							"from sellerlist " 
							+ " where id = '"+temp2 +"' ";
					
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);

					ResultSet rs = pst.executeQuery();
					while(rs.next())
					{

//						temp1=rs.getString("id").toString().toCharArray();
  						textField_city.setText(rs.getString("city"));
  						textField_seller_id.setText(rs.getString("id"));
  						textField_seller_name.setText(rs.getString("name"));

					}
					pst.close();
//					System.out.println(temp);

				} 
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}				
								
				

				
			}
		});
		scrollPane_1.setViewportView(table_1);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(361, 369, 542, 171);
		contentPane.add(scrollPane_2);
		
		table_2 = new JTable();
		table_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
  				try {
//					System.out.println("Hi");
					int row = table_2.getSelectedRow();
					temp4 = (table_2.getModel().getValueAt(row,0)).toString();
					System.out.println(temp4);
					
					String query= " select * "+
							"from buylist " 
							+ " where id = '"+temp4 +"' ";
					
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);

					ResultSet rs = pst.executeQuery();
					while(rs.next())
					{

//						temp1=rs.getString("id").toString().toCharArray();
						textField_buylist_id.setText(rs.getString("id"));
						textField_qty.setText(rs.getString("largenum"));
					}
					pst.close();
//					System.out.println(temp);

				} 
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}				
												
				
				
			}
		});
		scrollPane_2.setViewportView(table_2);
		
		JLabel lblNewLabel = new JLabel("ch_name");
		lblNewLabel.setBounds(50, 297, 54, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblSellerName = new JLabel("seller name");
		lblSellerName.setBounds(446, 292, 82, 24);
		contentPane.add(lblSellerName);
		
		textField_seller_name = new JTextField();
		textField_seller_name.setBounds(528, 294, 273, 21);
		contentPane.add(textField_seller_name);
		textField_seller_name.setColumns(10);
		
		textField_ch_name = new JTextField();
		textField_ch_name.setBounds(26, 324, 224, 21);
		contentPane.add(textField_ch_name);
		textField_ch_name.setColumns(10);
		
		textField_case_unit = new JTextField();
		textField_case_unit.setBounds(26, 468, 94, 21);
		contentPane.add(textField_case_unit);
		textField_case_unit.setColumns(10);
		
		textField_case_number = new JTextField();
		textField_case_number.setBounds(26, 530, 94, 21);
		contentPane.add(textField_case_number);
		textField_case_number.setColumns(10);
		
		textField_en_name = new JTextField();
		textField_en_name.setBounds(26, 395, 255, 21);
		contentPane.add(textField_en_name);
		textField_en_name.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("en_name");
		lblNewLabel_1.setBounds(50, 370, 54, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Case Unit");
		lblNewLabel_2.setBounds(36, 438, 82, 15);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Case Number");
		lblNewLabel_3.setBounds(36, 505, 94, 15);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("Trans Date");
		lblNewLabel_3_1.setBounds(223, 505, 94, 15);
		contentPane.add(lblNewLabel_3_1);
		
		textField_trans_date = new JTextField();
		textField_trans_date.setBounds(208, 530, 104, 21);
		contentPane.add(textField_trans_date);
		textField_trans_date.setColumns(10);
		textField_trans_date.setText(Preview.getTime());
		
		JLabel lblSellerId = new JLabel("seller ID");
		lblSellerId.setBounds(446, 258, 68, 24);
		contentPane.add(lblSellerId);
		
		textField_seller_id = new JTextField();
		textField_seller_id.setBounds(528, 260, 66, 21);
		contentPane.add(textField_seller_id);
		textField_seller_id.setColumns(10);
		
		JButton btnNewButton = new JButton("load");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				refreshTable1();
			
			}
		});
		btnNewButton.setBounds(330, 213, 72, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("load");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				refreshTable2();
				
			}
			
		});
		btnNewButton_1.setBounds(725, 226, 68, 23);
		contentPane.add(btnNewButton_1);
		
		textFieldSearch = new JTextField();
		textFieldSearch.setBounds(50, 213, 113, 21);
		contentPane.add(textFieldSearch);
		textFieldSearch.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("search keyword");
		lblNewLabel_4.setBounds(173, 213, 94, 15);
		contentPane.add(lblNewLabel_4);
		
		JButton btnNewButton_2 = new JButton("EN");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {

					String string1 = (textFieldSearch.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldSearch.getText() + "%'");
					
					String query = "select inv_id,ch_name, en_name  from InventoryList"
							+ " WHERE en_name LIKE "
							+ string1;
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
				
			}
		});
		btnNewButton_2.setBounds(50, 244, 93, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("CHN");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {

					String string1 = (textFieldSearch.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldSearch.getText() + "%'");
					
					String query = "select inv_id,ch_name, en_name  from InventoryList"
							+ " WHERE ch_name LIKE "
							+ string1;
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
												
				
			}
		});
		btnNewButton_3.setBounds(153, 244, 93, 23);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton(">");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					if(textField_seller_id.getText().trim().isEmpty() )
					{
						JOptionPane.showMessageDialog(null, "Please select a seller");
					}
					
					else if(textField_id.getText().trim().isEmpty() )
					{
						JOptionPane.showMessageDialog(null, "Please select commodity");
					}		
					
					else if(textField_case_number.getText().trim().isEmpty() )
					{
						JOptionPane.showMessageDialog(null, "Please enter a number");
					}			
					
					else if(textField_Cost.getText().trim().isEmpty() )
					{
						JOptionPane.showMessageDialog(null, "Please enter the cost");
					}			
										
					else 
					{
//						��ѯ id +1
						try {
							
							String sql = "select * from buylist ";

							PreparedStatement pst= connection.prepareStatement(sql);

							ResultSet rs = pst.executeQuery();
		  					if(rs.next())
		  					{
		  						
		  						//���� id +1
		  						try {
		  							
		  							String sql2 = "select max(id),min(id) from buylist "
		  									+ " limit 2";
		  							PreparedStatement pst2= connection.prepareStatement(sql2);

		  							ResultSet rs2 = pst2.executeQuery();
		  		  					while(rs2.next())
		  		  					{
		  		  						temp3=rs2.getString("max(id)");
		  		  					}
		  		  					
		  							pst2.close();

		  							
		  						} catch (Exception e2) {
		  							e2.printStackTrace();
		  						}	

		  					}
		  					else {
		  						temp3="0";
		  					}
		  					
							pst.close();

							
						} catch (Exception e2) {
							e2.printStackTrace();
						}	
						
						 String Number = Integer.toString(Integer.parseInt(temp3)+1);
						 System.out.println(Number);
						
						
						String sql= "insert into buylist("
								+ "id , " 
								+ "sid , " + 
								"invid, " + 
								"transdate, " + 
								"largenum, " + 
								"cost " + 
								") "  
								+ "values (" + Number+","
								+ textField_seller_id.getText()
								+ ", "+textField_id.getText()
								+ ", '"+ textField_trans_date.getText()  
								+ "', "+textField_case_number.getText()
								+ ", "+textField_Cost.getText()
								+")";
						PreparedStatement pst= connection.prepareStatement(sql);
						System.out.println(sql);
						    pst= connection.prepareStatement(sql);
							pst.execute();
							pst.close();
							
							refreshTable3();
					}
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
				
			}
		});
		btnNewButton_4.setBounds(239, 467, 47, 23);
		contentPane.add(btnNewButton_4);
		
		JLabel lblNewLabel_5 = new JLabel("City");
		lblNewLabel_5.setBounds(643, 265, 54, 15);
		contentPane.add(lblNewLabel_5);
		
		textField_city = new JTextField();
		textField_city.setBounds(692, 262, 109, 21);
		contentPane.add(textField_city);
		textField_city.setColumns(10);
		
		textField_id = new JTextField();
		textField_id.setBounds(142, 468, 66, 21);
		contentPane.add(textField_id);
		textField_id.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Goods ID");
		lblNewLabel_6.setBounds(140, 438, 54, 15);
		contentPane.add(lblNewLabel_6);
		
		textFieldSearch2 = new JTextField();
		textFieldSearch2.setColumns(10);
		textFieldSearch2.setBounds(446, 227, 113, 21);
		contentPane.add(textFieldSearch2);
		
		JLabel lblNewLabel_4_1 = new JLabel("search keyword");
		lblNewLabel_4_1.setBounds(446, 203, 94, 15);
		contentPane.add(lblNewLabel_4_1);
		
		JButton btnNewButton_5 = new JButton("name");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textFieldSearch2.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldSearch2.getText() + "%'");
					
					String query = "select id,name,city  from sellerList"
							+ " WHERE name LIKE "
							+ string1;
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_1.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
				
				
			}
		});
		btnNewButton_5.setBounds(581, 203, 72, 23);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("city");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textFieldSearch2.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldSearch2.getText() + "%'");
					
					String query = "select id,name,city  from sellerList"
							+ " WHERE city LIKE "
							+ string1;
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_1.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}								
				
			}
		});
		btnNewButton_6.setBounds(581, 226, 72, 23);
		contentPane.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("Load");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				refreshTable3();
			}
		});
		btnNewButton_7.setBounds(808, 550, 93, 23);
		contentPane.add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("do");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {

					if(textField_s1.getText().trim().isEmpty() || textField_s2.getText().trim().isEmpty())
					{
						JOptionPane.showMessageDialog(null, "Please enter the searching date");
					}
					else {


						String string1 = (textField_s1.getText().trim().isEmpty())?("''")
								:( "'"+textField_s1.getText() + "'");

						String string2 = (textField_s2.getText().trim().isEmpty())?("''")
								:( "'"+textField_s2.getText() + "'");					
						
						String	query= " select tb1.id,tb2.ch_name, tb2.en_name,tb3.name, tb1.transdate, tb1.largenum  \r\n" + 
								"from (buylist tb1 inner join sellerlist tb3 on tb1.sid= tb3.id )\r\n" + 
								"inner join inventorylist tb2 \r\n" + 
								"on tb2.inv_id= tb1.invid  where "
										+ "tb1.transdate >=" + string1 
										+ " and tb1.transdate <=" + string2
										+ " ";
						

						System.out.println(query);
						PreparedStatement pst= connection.prepareStatement(query);
						ResultSet rs = pst.executeQuery();
						//get all information to display
						table_2.setModel(DbUtils.resultSetToTableModel(rs));
						pst.close();
						rs.close();			
					}


					
				} catch (Exception e2) {
					e2.printStackTrace();
				}							
				
				
			}
		});
		btnNewButton_8.setBounds(538, 581, 68, 23);
		contentPane.add(btnNewButton_8);
		
		textField_s1 = new JTextField();
		textField_s1.setBounds(408, 551, 82, 21);
		contentPane.add(textField_s1);
		textField_s1.setColumns(10);
		
		textField_s2 = new JTextField();
		textField_s2.setColumns(10);
		textField_s2.setBounds(528, 550, 103, 21);
		contentPane.add(textField_s2);
		
		JLabel lblNewLabel_7 = new JLabel("From");
		lblNewLabel_7.setBounds(361, 554, 54, 15);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("to");
		lblNewLabel_8.setBounds(500, 554, 12, 15);
		contentPane.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("Search Time");
		lblNewLabel_9.setBounds(446, 585, 96, 15);
		contentPane.add(lblNewLabel_9);
		
		JButton btnNewButton_4_1 = new JButton("<");
		btnNewButton_4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {

					String sql2= "DELETE from buylist where id = "+ temp4 +" ";
					PreparedStatement pst= connection.prepareStatement(sql2);
					 pst= connection.prepareStatement(sql2);
					System.out.println(sql2);
					pst.execute();
					pst.close();
	
				} 
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}					
  				refreshTable3();						
				
				
			}
		});
		btnNewButton_4_1.setBounds(296, 467, 47, 23);
		contentPane.add(btnNewButton_4_1);
		
		textField_buylist_id = new JTextField();
		textField_buylist_id.setBounds(692, 582, 82, 21);
		contentPane.add(textField_buylist_id);
		textField_buylist_id.setColumns(10);
		
		JLabel lblNewLabel_7_1 = new JLabel("Id_num");
		lblNewLabel_7_1.setBounds(692, 550, 54, 15);
		contentPane.add(lblNewLabel_7_1);
		
		JLabel lblNewLabel_9_1 = new JLabel("Search Time");
		lblNewLabel_9_1.setBounds(446, 613, 96, 15);
		contentPane.add(lblNewLabel_9_1);
		
		JButton btnNewButton_8_1 = new JButton("Batch DEL");
		btnNewButton_8_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					if(textField_s1.getText().trim().isEmpty() || textField_s2.getText().trim().isEmpty())
					{
						JOptionPane.showMessageDialog(null, "Please enter Both date");
					}
					else 
					{
						String string1 = (textField_s1.getText().trim().isEmpty())?("''")
								:( "'"+textField_s1.getText() + "'");
	
						String string2 = (textField_s2.getText().trim().isEmpty())?("''")
								:( "'"+textField_s2.getText() + "'");					
						
						
//						String query = " select * " + 
//								"from buylist  where orderdate >" + string1+ " "
//										+ "and orderdate <" + string2;
//	
						String q1 = "    DELETE from buylist WHERE id = any(select tid from\r\n" + 
								" (select id as tid FROM buylist WHERE transdate >="+string1+ " and transdate <="
										+ string2 +") as a)";
						

						
						JOptionPane.showConfirmDialog(null, "DELETE data from "+string1+" to "+string2+" ?");
						
						System.out.println(q1);
//						System.out.println(q2);
						PreparedStatement pst= connection.prepareStatement(q1);
//						executeUpdate() rather than executeQuery().
						pst.execute();
//						pst= connection.prepareStatement(q2);
//						pst.execute();
						//get all information to display
//						table.setModel(DbUtils.resultSetToTableModel(rs));
						pst.close();
		
						refreshTable3();
					}
				} catch (Exception e2) {
					e2.printStackTrace();
				}									
				
			}
		});
		btnNewButton_8_1.setForeground(Color.RED);
		btnNewButton_8_1.setBounds(538, 614, 93, 23);
		contentPane.add(btnNewButton_8_1);
		
		textField_search = new JTextField();
		textField_search.setColumns(10);
		textField_search.setBounds(116, 635, 113, 21);
		contentPane.add(textField_search);
		
		JLabel lblNewLabel_4_1_1 = new JLabel("search keyword");
		lblNewLabel_4_1_1.setBounds(116, 613, 120, 15);
		contentPane.add(lblNewLabel_4_1_1);
		
		JButton btnNewButton_9 = new JButton("CHN");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textField_search.getText().trim().isEmpty())?("'%'")
							:( "'%"+textField_search.getText() + "%'");
					
					String query = "select DISTINCT tb1.id,tb2.ch_name, tb2.en_name,tb3.name, tb1.transdate, tb1.largenum  \r\n" + 
							"from (buylist tb1 inner join sellerlist tb3 on tb1.sid= tb3.id )\r\n" + 
							"inner join inventorylist tb2 \r\n" + 
							"on tb2.inv_id= tb1.invid "
							+ " WHERE tb2.ch_name LIKE "
							+ string1;
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_2.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}								
				
			}
		});
		btnNewButton_9.setBounds(274, 613, 69, 23);
		contentPane.add(btnNewButton_9);
		
		JButton btnNewButton_10 = new JButton("EN");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {

					String string1 = (textField_search.getText().trim().isEmpty())?("'%'")
							:( "'%"+textField_search.getText() + "%'");
					
					String query = "select DISTINCT tb1.id,tb2.ch_name, tb2.en_name,tb3.name, tb1.transdate, tb1.largenum  \r\n" + 
							"from (buylist tb1 inner join sellerlist tb3 on tb1.sid= tb3.id )\r\n" + 
							"inner join inventorylist tb2 \r\n" + 
							"on tb2.inv_id= tb1.invid "
							+ " WHERE tb2.en_name LIKE "
							+ string1;
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_2.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
											
				
			}
		});
		btnNewButton_10.setBounds(274, 652, 69, 23);
		contentPane.add(btnNewButton_10);
		
		JButton btnNewButton_10_1 = new JButton("Seller ");
		btnNewButton_10_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textField_search.getText().trim().isEmpty())?("'%'")
							:( "'%"+textField_search.getText() + "%'");
					
					String query = "select DISTINCT tb1.id,tb2.ch_name, tb2.en_name,tb3.name, tb1.transdate, tb1.largenum  \r\n" + 
							"from (buylist tb1 inner join sellerlist tb3 on tb1.sid= tb3.id )\r\n" + 
							"inner join inventorylist tb2 \r\n" + 
							"on tb2.inv_id= tb1.invid "
							+ " WHERE tb3.name LIKE "
							+ string1;
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table_2.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}				
								
				
				
			}
		});
		btnNewButton_10_1.setBounds(250, 581, 93, 23);
		contentPane.add(btnNewButton_10_1);
		
		textField_qty = new JTextField();
		textField_qty.setColumns(10);
		textField_qty.setBounds(692, 635, 82, 21);
		contentPane.add(textField_qty);
		
		JLabel lblNewLabel_7_1_1 = new JLabel("Large number");
		lblNewLabel_7_1_1.setBounds(692, 613, 82, 15);
		contentPane.add(lblNewLabel_7_1_1);
		
		JButton btnNewButton_4_1_1 = new JButton("update");
		btnNewButton_4_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					

  							
						String sql2 = "select * from buylist where id =  "+temp4;

						PreparedStatement pst2= connection.prepareStatement(sql2);
						String tt ="";
						ResultSet rs2 = pst2.executeQuery();
	  					while(rs2.next())
	  					{
	  						tt=rs2.getString("largenum");
	  					}
	  					
						pst2.close();


					
					String query= "UPDATE buylist SET largenum= REPLACE(largenum,"
							+ tt +"," +textField_qty.getText() +") where id = "+ temp4;
			PreparedStatement pst= connection.prepareStatement(query);
	
			System.out.println(query);

			
			pst.execute();
	
			JOptionPane.showMessageDialog(null, "Data Updated");
			
			pst.close();
	
			
		} catch (Exception e3) {
			e3.printStackTrace();
		}

			refreshTable3() ;
			
		}			

		});
		btnNewButton_4_1_1.setBounds(802, 634, 99, 23);
		contentPane.add(btnNewButton_4_1_1);
		
		JLabel lblInputRecord = new JLabel("Input Record");
		lblInputRecord.setFont(new Font("Arial Black", Font.BOLD, 16));
		lblInputRecord.setBounds(18, 11, 263, 28);
		contentPane.add(lblInputRecord);
		
		JLabel lblNewLabel_3_2 = new JLabel("Cost Price");
		lblNewLabel_3_2.setBounds(36, 562, 94, 15);
		contentPane.add(lblNewLabel_3_2);
		
		textField_Cost = new JTextField();
		textField_Cost.setColumns(10);
		textField_Cost.setBounds(26, 582, 94, 21);
		contentPane.add(textField_Cost);
		refreshTable1();
		refreshTable2();
		refreshTable3();
	}
}
