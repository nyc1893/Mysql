package javaGui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;

public class ad_inoicelist extends JFrame {

	private JPanel contentPane;
	Connection connection = null;
	private JTable table;
	String EID = "";
	private JTextField textFieldid;
	private JLabel lblNewLabel;
	private JLabel lblOrderdate;
	private JLabel lblPonumber;
	private JLabel lblBuyername;
	private JLabel lblPhone;
	private JLabel lblAddr;
	private JLabel lblTotal;
	private JLabel lblCity;
	private JLabel lblTerm;
	private JLabel lblState;
	private JLabel lblZip;
	private JTextField textFieldodate;
	private JTextField textFieldpo;
	private JTextField textFieldbname;
	private JTextField textFieldphone;
	private JTextField textFieldaddr;
	private JTextField textFieldcity;
	private JTextField textFieldstate;
	private JTextField textFieldtotal;
	private JTextField textFieldterm;
	private JTextField textFieldzip;
	private JLabel lblCustomid;
	private JTextField textFieldcid;
	private JButton btnUpdate;
	private JButton btnDelete;
	private JLabel lblTaxrate;
	private JTextField textFieldtaxrate;
	private JTextField textFieldt1;
	private JTextField textFieldt2;
	private JLabel lblFrom;
	private JLabel lblTo;
	private JTextField textFieldname;
	private JButton btnSearchcity;
	private JButton btnSearchname;
	private JButton btnDoIt;
	private JLabel lblTimeName;
	private JButton btnSearchtime;
	private JButton btnBatchDel;
	private JLabel lblEditInvoice;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ad_inoicelist frame = new ad_inoicelist();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void refreshTable() {
		try {
			String query= "select id as Invoice_id, "
					+ " orderdate,interval as date, "
					+ " term, "
					+ " total, "
					+ " name as Custom_name,"
					+ " city, state, taxrate "
					+ " from InvoiceList";
			PreparedStatement pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			//get all information to display
			table.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		
	}
	
	
	public String formatDouble(double s) {
		DecimalFormat fmt = new DecimalFormat("##0.00");
		return fmt.format(s);
	}
	
	/**
	 * Create the frame.
	 */
	public ad_inoicelist() {
		connection = sqlcon.db();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1280, 796);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(405, 111, 693, 355);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
  				try {
//					System.out.println("Hi");
					int row = table.getSelectedRow();
					String EID = (table.getModel().getValueAt(row,0)).toString();
					System.out.println(EID);
					String query= "select * from InvoiceList "
							+ " where id = '"+EID +"' ";
					PreparedStatement pst= connection.prepareStatement(query);

					ResultSet rs = pst.executeQuery();
					while(rs.next())
					{


  						textFieldid.setText(rs.getString("id"));
  						textFieldbname.setText(rs.getString("name"));
  						textFieldphone.setText(rs.getString("phone"));
  						
  						textFieldaddr.setText(rs.getString("addr"));
  						textFieldcity.setText(rs.getString("city"));  	
  						textFieldstate.setText(rs.getString("state"));
  						textFieldzip.setText(rs.getString("zip"));  	 						
  						textFieldcid.setText(rs.getString("cid"));
  						

  						textFieldtaxrate.setText(rs.getString("taxrate"));  	
  						textFieldterm.setText(rs.getString("term"));
  						textFieldpo.setText(rs.getString("ponumber"));  	 						
  						textFieldodate.setText(rs.getString("orderdate"));
  						textFieldtotal.setText(rs.getString("total"));   						
  						
  						
					}
					pst.close();
//					System.out.println(temp);

				} 
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}				
				
				
			}
		});
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("Load");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				refreshTable();
				
			}
		});
		btnNewButton.setBounds(1000, 489, 93, 23);
		contentPane.add(btnNewButton);
		
		textFieldid = new JTextField();
		textFieldid.setBounds(160, 507, 86, 21);
		contentPane.add(textFieldid);
		textFieldid.setColumns(10);
		
		lblNewLabel = new JLabel("InvoiceID");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel.setBounds(34, 509, 77, 15);
		contentPane.add(lblNewLabel);
		
		lblOrderdate = new JLabel("OrderDate");
		lblOrderdate.setBounds(34, 547, 95, 15);
		lblOrderdate.setFont(new Font("Times New Roman", Font.BOLD, 18));
		contentPane.add(lblOrderdate);
		
		lblPonumber = new JLabel("PONumber");
		lblPonumber.setBounds(34, 584, 108, 15);
		lblPonumber.setFont(new Font("Times New Roman", Font.BOLD, 18));
		contentPane.add(lblPonumber);
		
		lblBuyername = new JLabel("BuyerName");
		lblBuyername.setBounds(34, 622, 116, 15);
		lblBuyername.setFont(new Font("Times New Roman", Font.BOLD, 18));
		contentPane.add(lblBuyername);
		
		lblPhone = new JLabel("Phone");
		lblPhone.setBounds(34, 664, 77, 15);
		lblPhone.setFont(new Font("Times New Roman", Font.BOLD, 18));
		contentPane.add(lblPhone);
		
		lblAddr = new JLabel("Addr");
		lblAddr.setBounds(280, 664, 77, 15);
		lblAddr.setFont(new Font("Times New Roman", Font.BOLD, 18));
		contentPane.add(lblAddr);
		
		lblTotal = new JLabel("Total");
		lblTotal.setBounds(351, 547, 77, 15);
		lblTotal.setFont(new Font("Times New Roman", Font.BOLD, 18));
		contentPane.add(lblTotal);
		
		lblCity = new JLabel("City");
		lblCity.setBounds(34, 708, 77, 15);
		lblCity.setFont(new Font("Times New Roman", Font.BOLD, 18));
		contentPane.add(lblCity);
		
		lblTerm = new JLabel("Term");
		lblTerm.setBounds(351, 584, 77, 15);
		lblTerm.setFont(new Font("Times New Roman", Font.BOLD, 18));
		contentPane.add(lblTerm);
		
		lblState = new JLabel("State");
		lblState.setBounds(254, 708, 77, 15);
		lblState.setFont(new Font("Times New Roman", Font.BOLD, 18));
		contentPane.add(lblState);
		
		lblZip = new JLabel("Zip");
		lblZip.setBounds(428, 708, 77, 15);
		lblZip.setFont(new Font("Times New Roman", Font.BOLD, 18));
		contentPane.add(lblZip);
		
		textFieldodate = new JTextField();
		textFieldodate.setColumns(10);
		textFieldodate.setBounds(160, 545, 133, 21);
		contentPane.add(textFieldodate);
		
		textFieldpo = new JTextField();
		textFieldpo.setColumns(10);
		textFieldpo.setBounds(160, 582, 133, 21);
		contentPane.add(textFieldpo);
		
		textFieldbname = new JTextField();
		textFieldbname.setColumns(10);
		textFieldbname.setBounds(160, 619, 401, 21);
		contentPane.add(textFieldbname);
		
		textFieldphone = new JTextField();
		textFieldphone.setColumns(10);
		textFieldphone.setBounds(109, 662, 150, 21);
		contentPane.add(textFieldphone);
		
		textFieldaddr = new JTextField();
		textFieldaddr.setColumns(10);
		textFieldaddr.setBounds(351, 662, 214, 21);
		contentPane.add(textFieldaddr);
		
		textFieldcity = new JTextField();
		textFieldcity.setColumns(10);
		textFieldcity.setBounds(82, 705, 149, 21);
		contentPane.add(textFieldcity);
		
		textFieldstate = new JTextField();
		textFieldstate.setColumns(10);
		textFieldstate.setBounds(308, 706, 110, 21);
		contentPane.add(textFieldstate);
		
		textFieldtotal = new JTextField();
		textFieldtotal.setColumns(10);
		textFieldtotal.setBounds(419, 545, 86, 21);
		contentPane.add(textFieldtotal);
		
		textFieldterm = new JTextField();
		textFieldterm.setColumns(10);
		textFieldterm.setBounds(419, 582, 86, 21);
		contentPane.add(textFieldterm);
		
		textFieldzip = new JTextField();
		textFieldzip.setColumns(10);
		textFieldzip.setBounds(472, 706, 86, 21);
		contentPane.add(textFieldzip);
		
		lblCustomid = new JLabel("CustomID");
		lblCustomid.setBounds(34, 470, 116, 15);
		lblCustomid.setFont(new Font("Times New Roman", Font.BOLD, 18));
		contentPane.add(lblCustomid);
		
		textFieldcid = new JTextField();
		textFieldcid.setColumns(10);
		textFieldcid.setBounds(160, 468, 86, 21);
		contentPane.add(textFieldcid);
		
		btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					

					String query= "update InvoiceList "
							+ " set ID="+textFieldid.getText()
							+"  ,name='"+ textFieldbname.getText()
							+"' ,phone='"+ textFieldphone.getText()
							+"' ,addr='"+ textFieldaddr.getText()
							+"' ,city='"+ textFieldcity.getText()
							+"' ,state='"+ textFieldstate.getText()
							+"' ,zip='"+ textFieldzip.getText()
							+"' ,taxrate='"+ textFieldtaxrate.getText()
							
							+"' ,cid= "+ textFieldcid.getText()
							+" ,orderdate='"+ textFieldodate.getText()
							+"' ,ponumber= '"+ textFieldpo.getText()							
							+"' ,term= "+ textFieldterm.getText()
							+"  ,total='"+ textFieldtotal.getText()
							+"' where ID = "+textFieldid.getText();
				
	
					System.out.println(query);			
					PreparedStatement pst= connection.prepareStatement(query);
			
					pst.execute();

					JOptionPane.showMessageDialog(null, "Data Updated");
					
					pst.close();
		
					
				} catch (Exception e3) {
					e3.printStackTrace();
				}
				refreshTable() ;
			}								
				
			
		});
		btnUpdate.setBounds(871, 489, 93, 23);
		contentPane.add(btnUpdate);
		
		btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
  				try {
  					JOptionPane.showConfirmDialog(null, "DELETE it?");
					String query= "DELETE from InvoiceList"
							+ " where id = "+ textFieldid.getText()+" ";
					PreparedStatement pst= connection.prepareStatement(query);
					System.out.println(query);

					pst.execute();
					
					
					
					 query= "DELETE from revorderList"
							+ " where id = "+ textFieldid.getText()+" ";
					 pst= connection.prepareStatement(query);
					System.out.println(query);

					pst.execute();					
					
					pst.close();
	
				} 
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}				
				
  				refreshTable() ;				
				
			}
		});
		btnDelete.setBounds(748, 489, 93, 23);
		contentPane.add(btnDelete);
		
		lblTaxrate = new JLabel("Taxrate");
		lblTaxrate.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblTaxrate.setBounds(580, 709, 77, 15);
		contentPane.add(lblTaxrate);
		
		textFieldtaxrate = new JTextField();
		textFieldtaxrate.setColumns(10);
		textFieldtaxrate.setBounds(651, 706, 86, 21);
		contentPane.add(textFieldtaxrate);
		
		textFieldt1 = new JTextField();
		textFieldt1.setColumns(10);
		textFieldt1.setBounds(65, 115, 86, 21);
		contentPane.add(textFieldt1);
		
		textFieldt2 = new JTextField();
		textFieldt2.setColumns(10);
		textFieldt2.setBounds(200, 115, 86, 21);
		contentPane.add(textFieldt2);
		
		lblFrom = new JLabel("From");
		lblFrom.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblFrom.setBounds(13, 118, 116, 15);
		contentPane.add(lblFrom);
		
		lblTo = new JLabel("to");
		lblTo.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblTo.setBounds(167, 117, 36, 15);
		contentPane.add(lblTo);
		
		textFieldname = new JTextField();
		textFieldname.setColumns(10);
		textFieldname.setBounds(13, 160, 216, 21);
		contentPane.add(textFieldname);
		
		btnSearchcity = new JButton("searchCity");
		btnSearchcity.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textFieldname.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldname.getText() + "%'");


					String query = "select id as Invoice_id, "
							+ " orderdate as date, "
							+ " term, "
							+ " total, "
							+ " name as Custom_name,"
							+ " city, state, taxrate "+
					"from InvoiceList  where city like " +string1;
					
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}									
								
				
			}
		});
		btnSearchcity.setBounds(254, 179, 116, 23);
		contentPane.add(btnSearchcity);
		
		btnSearchname = new JButton("searchName");
		btnSearchname.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textFieldname.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldname.getText() + "%'");
					

					String query = "select id as Invoice_id, "
							+ " orderdate as date, "
							+ " term, "
							+ " total, "
							+ " name as Custom_name,"
							+ " city, state, taxrate "+
					"from InvoiceList  where name like " +string1;
					
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}									
								
				
			}
		});
		btnSearchname.setBounds(254, 146, 116, 23);
		contentPane.add(btnSearchname);
		
		btnDoIt = new JButton("search");
		btnDoIt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textFieldt1.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt1.getText() + "'");

					String string2 = (textFieldt2.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt2.getText() + "'");	
					
					String string3 = (textFieldname.getText().trim().isEmpty())?("'%'")
							:( "'%"+textFieldname.getText() + "%'");							
					
					String query = "select id as Invoice_id, "
							+ " orderdate as date, "
							+ " term, "
							+ " total, "
							+ " name as Custom_name,"
							+ " city, state, taxrate "
							+"from InvoiceList   where date >="+string1+" and date <= "+string2+" " + 
							"and name like "+string3;

					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}								
				
			}
		});
		btnDoIt.setBounds(36, 232, 93, 23);
		contentPane.add(btnDoIt);
		
		lblTimeName = new JLabel("Time + Name");
		lblTimeName.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblTimeName.setBounds(34, 207, 116, 15);
		contentPane.add(lblTimeName);
		
		btnSearchtime = new JButton("searchTime");
		btnSearchtime.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String string1 = (textFieldt1.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt1.getText() + "'");

					String string2 = (textFieldt2.getText().trim().isEmpty())?("''")
							:( "'"+textFieldt2.getText() + "'");					
					
					
					String query = " select * " + 
							"from InvoiceList  where orderdate >=" + string1+ " "
									+ "and orderdate <=" + string2;

					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					//get all information to display
					table.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
					rs.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}								
				
				
				
			}
		});
		btnSearchtime.setBounds(160, 82, 131, 23);
		contentPane.add(btnSearchtime);
		
		btnBatchDel = new JButton("Batch DEL");
		btnBatchDel.setFont(new Font("Times New Roman", Font.BOLD, 13));
		btnBatchDel.setForeground(Color.RED);
		btnBatchDel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					if(textFieldt1.getText().trim().isEmpty() || textFieldt2.getText().trim().isEmpty())
					{
						JOptionPane.showMessageDialog(null, "Please enter Both date");
					}
					else 
					{
						String string1 = (textFieldt1.getText().trim().isEmpty())?("''")
								:( "'"+textFieldt1.getText() + "'");
	
						String string2 = (textFieldt2.getText().trim().isEmpty())?("''")
								:( "'"+textFieldt2.getText() + "'");					
						
						
						String query = " select * " + 
								"from InvoiceList  where orderdate >=" + string1+ " "
										+ "and orderdate <=" + string2;
	
						String q1 = "    DELETE from revorderlist WHERE id = any(select tid from\r\n" + 
								" (select id as tid FROM InvoiceList WHERE orderdate >="+string1+ " and orderdate <="
										+ string2 +") as a)";
						
						String q2 = "    DELETE from InvoiceList WHERE id = any(select tid from\r\n" + 
								" (select id as tid FROM InvoiceList WHERE orderdate >="+string1+ " and orderdate <="
										+ string2 +") as a)";
						
						JOptionPane.showConfirmDialog(null, "DELETE data from "+string1+" to "+string2+" ?");
						
						System.out.println(q1);
						System.out.println(q2);
						PreparedStatement pst= connection.prepareStatement(q1);
//						executeUpdate() rather than executeQuery().
						pst.execute();
						pst= connection.prepareStatement(q2);
						pst.execute();
						//get all information to display
//						table.setModel(DbUtils.resultSetToTableModel(rs));
						pst.close();
		
						refreshTable();
					}
				} catch (Exception e2) {
					e2.printStackTrace();
				}										
				
			}
		});
		btnBatchDel.setBounds(200, 232, 93, 23);
		contentPane.add(btnBatchDel);
		
		lblEditInvoice = new JLabel("Edit Invoice");
		lblEditInvoice.setFont(new Font("Arial Black", Font.BOLD, 16));
		lblEditInvoice.setBounds(21, 11, 182, 28);
		contentPane.add(lblEditInvoice);
		refreshTable();
	}
}
