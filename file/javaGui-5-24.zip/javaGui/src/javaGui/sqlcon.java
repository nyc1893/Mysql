package javaGui;
import java.sql.*;
import javax.swing.*;

public class sqlcon {
 
	static final String wordpath = "C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE";
	static final String exepath = "C:\\Program Files\\Microsoft Office\\root\\Office16\\EXCEL.EXE";
	
	
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
//    as host side:
    static final String DB_URL = "jdbc:mysql://localhost:3306/RUNOOB?characterEcoding=utf-8&allowPublicKeyRetrieval=TRUE&useSSL=false&serverTimezone=America/Los_Angeles";
    static final String savepath = "F:\\generated\\";

    
    
    // as remote side:
//    static final String savepath = "c:\\gen\\";
    
//    static final String savepath = "d:\\generated\\";
//    static final String DB_URL = "jdbc:mysql://192.168.0.139:3306/RUNOOB?characterEcoding=utf-8&allowPublicKeyRetrieval=TRUE&useSSL=false&serverTimezone=America/Los_Angeles";
    //need to be the same with 
//    static final String USER = "root";
    static final String PASS = "123";
    static final String USER = "uu";

    


    

        Connection conn = null;
        Statement stat = null;

        public static Connection db()
        {

            Connection conn = null;

	        try{
	            // ע�� JDBC ����
	            Class.forName(JDBC_DRIVER);
	            // ������
	            System.out.println("connecting to database...");
	            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            	//JOptionPane.showMessageDialog(null, "Connection Success");
        		return conn;
	        }
    		catch(Exception e)
    		{
    			System.out.println(e);
            	JOptionPane.showMessageDialog(null, "Connection Error");
        		return null;
	        }
    
        }

       

}