package javaGui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;

public class ad_store extends JFrame {

	private JPanel contentPane;
	Connection connection = null;
	char temp[] = new char [100];
	String EID = "";
	private JTable table;
	private JTextField textField_ch_name;
	private JTextField textField_en_name;
	private JTextField textField_item_num;
	private JTextField textField_case_num;
	private JTextField textField_case_unit;
	private JTextField textField_itempercase;
	private JTextField textField_s1;
	private JTextField textField_s2;
	private JTextField textField_t1;
	private JTextField textField_t2;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ad_store frame = new ad_store();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public void refreshTable() {

		try {
			String query= " select distinct tb1.id,tb2.ch_name, tb2.en_name, "+
					"  tb2.itempercase, tb1.largenum as basenumber " + 
					"from storelist tb1 " + 
					"inner join inventorylist tb2 " + 
					"on tb2.inv_id= tb1.id" ;
//			String query= "select * from storelist";
			System.out.println(query);

			PreparedStatement pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			//get all information to display
			table.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		
	}
	
	
	public void refreshTable2() {

		try {
			String query= "select distinct tb3.inv_id, tb3.ch_name,tb3.en_name, IFNULL(tb2.largenum,0.00) as buy,\r\n" + 
					" IFNULL(tb1.bignum,0.00) as sale ,IFNULL(tb2.largenum,0.00) - IFNULL(tb1.bignum,0.00) as storing, " + 
					"IFNULL(tb2.cost,0.00)  as cost "+
					"from (inventorylist tb3\r\n" + 
					"left join calcu tb1\r\n" + 
					"on tb1.goodid =  tb3.inv_id)\r\n" + 
					"left join calcu2 tb2\r\n" + 
					"on tb3.inv_id = tb2.invid";
//			String query= "select * from storelist";
			System.out.println(query);

			PreparedStatement pst= connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			//get all information to display
			table.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		
	}
	/**
	 * Create the frame.
	 */
	public ad_store() {
		connection = sqlcon.db();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 873, 655);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(37, 65, 604, 269);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
  				try {
//					System.out.println("Hi");
					int row = table.getSelectedRow();
				     EID = (table.getModel().getValueAt(row,0)).toString();
					System.out.println(EID);
					
					String query= " select tb1.id,tb2.ch_name, tb2.en_name, "
							+ "tb2.caseunit,tb2.itemunit, "+
							"  tb2.itempercase, tb1.largenum as basenumber " + 
							"from storelist tb1 " + 
							"inner join inventorylist tb2 " + 
							"on tb2.inv_id= tb1.id"
							+ " where tb1.id = '"+EID +"' ";
					
					System.out.println(query);
					PreparedStatement pst= connection.prepareStatement(query);

					ResultSet rs = pst.executeQuery();
					while(rs.next())
					{

						temp=rs.getString("id").toString().toCharArray();
  						textField_en_name.setText(rs.getString("en_name"));
  						textField_ch_name.setText(rs.getString("ch_name"));
//  						textField_item_num.setText(rs.getString("smallnum"));
  						textField_case_num.setText(rs.getString("basenumber"));
//  						textField_item_unit.setText(rs.getString("itemunit"));
  						textField_case_unit.setText(rs.getString("caseunit"));
  						textField_itempercase.setText(rs.getString("itempercase"));
					}
					pst.close();
					System.out.println(temp);

				} 
				catch (Exception e2) 
				{
					e2.printStackTrace();				
				}				
				
			}
		});
		scrollPane.setViewportView(table);
		
		textField_ch_name = new JTextField();
		textField_ch_name.setBounds(54, 371, 302, 21);
		contentPane.add(textField_ch_name);
		textField_ch_name.setColumns(10);
		
		textField_en_name = new JTextField();
		textField_en_name.setBounds(54, 428, 302, 21);
		contentPane.add(textField_en_name);
		textField_en_name.setColumns(10);
		
		JButton btnNewButton = new JButton("Load");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				refreshTable();
				
			}
			
		});

		btnNewButton.setBounds(496, 32, 93, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Update");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					

					String query= "update storelist "
							+ " set smallnum= 0 "
							+" ,largenum= "+ textField_case_num.getText()

							+" where ID = "+EID ;
				

					PreparedStatement pst= connection.prepareStatement(query);
			
					pst.execute();

					JOptionPane.showMessageDialog(null, "Data Updated");
					
					pst.close();
		
					
				} catch (Exception e3) {
					e3.printStackTrace();
				}
				refreshTable() ;
							
				
			}
		});
		btnNewButton_1.setBounds(294, 524, 93, 23);
		contentPane.add(btnNewButton_1);
		
		textField_item_num = new JTextField();
		textField_item_num.setBounds(54, 477, 93, 21);
		contentPane.add(textField_item_num);
		textField_item_num.setColumns(10);
		
		textField_case_num = new JTextField();
		textField_case_num.setBounds(54, 525, 93, 21);
		contentPane.add(textField_case_num);
		textField_case_num.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("CH_name");
		lblNewLabel.setBounds(68, 346, 54, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblEnname = new JLabel("EN_name");
		lblEnname.setBounds(64, 403, 54, 15);
		contentPane.add(lblEnname);
		
		JLabel lblNewLabel_1 = new JLabel("item num");
		lblNewLabel_1.setBounds(64, 459, 83, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("base num");
		lblNewLabel_2.setBounds(64, 500, 93, 15);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_4 = new JLabel("case unit");
		lblNewLabel_4.setBounds(184, 500, 54, 15);
		contentPane.add(lblNewLabel_4);
		
		textField_case_unit = new JTextField();
		textField_case_unit.setBounds(184, 525, 66, 21);
		contentPane.add(textField_case_unit);
		textField_case_unit.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Item per case");
		lblNewLabel_5.setBounds(294, 459, 112, 15);
		contentPane.add(lblNewLabel_5);
		
		textField_itempercase = new JTextField();
		textField_itempercase.setBounds(290, 477, 66, 21);
		contentPane.add(textField_itempercase);
		textField_itempercase.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Start");
		lblNewLabel_7.setBounds(424, 356, 54, 15);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("To");
		lblNewLabel_8.setBounds(424, 413, 54, 15);
		contentPane.add(lblNewLabel_8);
		
		textField_s1 = new JTextField();
		textField_s1.setBounds(413, 381, 119, 21);
		contentPane.add(textField_s1);
		textField_s1.setColumns(10);
		
		textField_s2 = new JTextField();
		textField_s2.setBounds(413, 428, 125, 21);
		contentPane.add(textField_s2);
		textField_s2.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("Generate");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {

					if(textField_s1.getText().trim().isEmpty() || textField_s2.getText().trim().isEmpty())
					{
						JOptionPane.showMessageDialog(null, "Please enter the searching date");
					}
					else {


						String string1 = (textField_s1.getText().trim().isEmpty())?("''")
								:( "'"+textField_s1.getText() + "'");

						String string2 = (textField_s2.getText().trim().isEmpty())?("''")
								:( "'"+textField_s2.getText() + "'");					

						
						
						String	query= " select invid,sum(largenum) as largenum from buylist " + 
										" where transdate > " + string1  
										+ " and transdate < " + string2
										+ " group by invid";
						
										
						System.out.println(query);
						PreparedStatement pst= connection.prepareStatement(query);
						ResultSet rs = pst.executeQuery();
						//get all information to display
						ArrayList<String> arr1 = new ArrayList<>();
						ArrayList<String> arr2 = new ArrayList<>();
						ResultSetMetaData rsmd=rs.getMetaData();  //��ȡ�������Ԫ����
						int columns=rsmd.getColumnCount();  //��ȡ�����������
						while(rs.next()){
//							for(int i=1;i<=columns;i++)
							{
								System.out.println(rs.getString(1));
								System.out.println(rs.getString(2));
								

								arr1.add(rs.getString(1));
								arr2.add(rs.getString(2));
							}				
//							System.out.println();				
						}
						

//						String[] c2 =  arr2.toArray(new String[]);
//						System.out.println(arr1.size());
//						System.out.println(c1);
						
						
						for (int i = 0; i < arr1.size(); i++) {
	

							query="update storelist set smallnum = 0, largenum = "+ arr2.get(i)
									+" where id = "+  arr1.get(i);
							System.out.println(query);
						    pst= connection.prepareStatement(query);
							pst.execute();
						}
//						
						JOptionPane.showMessageDialog(null, "Data Updated");
						
						pst.close();
						rs.close();		
						refreshTable();
					
					}


					
				} catch (Exception e2) {
					e2.printStackTrace();
				}					
				
			}
		});
		btnNewButton_2.setBounds(439, 496, 93, 23);
		contentPane.add(btnNewButton_2);
		
		JLabel lblNewLabel_6_1 = new JLabel("Base Number");
		lblNewLabel_6_1.setFont(new Font("����", Font.BOLD, 18));
		lblNewLabel_6_1.setBounds(424, 520, 200, 27);
		contentPane.add(lblNewLabel_6_1);
		
		JLabel lblNewLabel_7_1 = new JLabel("Start");
		lblNewLabel_7_1.setBounds(710, 72, 54, 15);
		contentPane.add(lblNewLabel_7_1);
		
		JLabel lblNewLabel_8_1 = new JLabel("To");
		lblNewLabel_8_1.setBounds(710, 131, 54, 15);
		contentPane.add(lblNewLabel_8_1);
		
		textField_t1 = new JTextField();
		textField_t1.setColumns(10);
		textField_t1.setBounds(700, 97, 119, 21);
		contentPane.add(textField_t1);
		
		textField_t2 = new JTextField();
		textField_t2.setColumns(10);
		textField_t2.setBounds(700, 156, 112, 21);
		contentPane.add(textField_t2);
		textField_t2.setText(Preview.getTime());
		
		JButton btnNewButton_2_1 = new JButton("Calculate");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {

					if(textField_t1.getText().trim().isEmpty() || textField_t2.getText().trim().isEmpty())
					{
						JOptionPane.showMessageDialog(null, "Please enter the searching date");
					}
					else {


						String string1 = (textField_t1.getText().trim().isEmpty())?("''")
								:( "'"+textField_t1.getText() + "'");

						String string2 = (textField_t2.getText().trim().isEmpty())?("''")
								:( "'"+textField_t2.getText() + "'");					

						String	query=  "DROP VIEW IF EXISTS calcu ";
						
						System.out.println(query);
						PreparedStatement pst= connection.prepareStatement(query);
						pst.executeUpdate();					
						
						query= "CREATE VIEW calcu AS\r\n" + 
						"select tb2.goodid,sum(tb2.qty/tb3.itempercase) as bignum\r\n" + 
						"from  invoicelist tb1 \r\n" + 
						"right join (revorderlist tb2 inner join inventorylist tb3 on tb2.goodid= tb3.inv_id )\r\n" + 
						"on tb1.id = tb2.id\r\n" + 
						"where tb1.orderdate > " +string1
						+ "and tb1.orderdate< " +string2
						+" group by goodid";
						
						System.out.println(query);
						 pst= connection.prepareStatement(query);
						 pst.executeUpdate();
						 
						 
						query= "DROP VIEW IF EXISTS calcu2";

						System.out.println(query);
						 pst= connection.prepareStatement(query);
						 pst.executeUpdate();

						query= "CREATE VIEW calcu2 AS\r\n" + 
								"select invid, sum(largenum) as largenum, " + 
								"max(cost) as cost " + 
								"from buylist \r\n" + 
								"group by invid";

						System.out.println(query);
						 pst= connection.prepareStatement(query);
						 pst.executeUpdate();

		 
							query= "select distinct tb3.inv_id, tb3.ch_name,tb3.en_name, IFNULL(tb2.largenum,0.00) as buy,\r\n" + 
									" IFNULL(tb1.bignum,0.00) as sale "
				
									+ " ,IFNULL(tb2.largenum,0.00) - IFNULL(tb1.bignum,0.00) as storing, " + 
									"IFNULL(tb2.cost,0.00)  as cost "+
									"from (inventorylist tb3\r\n" + 
									"left join calcu tb1\r\n" + 
									"on tb1.goodid =  tb3.inv_id)\r\n" + 
									"left join calcu2 tb2\r\n" + 
									"on tb3.inv_id = tb2.invid";

							System.out.println(query);
							 pst= connection.prepareStatement(query);
							 ResultSet rs = pst.executeQuery();	
//							 rs = pst.executeQuery();					 
							 table.setModel(DbUtils.resultSetToTableModel(rs));
						pst.close();
						rs.close();		
						refreshTable2();
					}


					
				} catch (Exception e2) {
					e2.printStackTrace();
				}					
				
				
				
			}
		});
		btnNewButton_2_1.setBounds(700, 239, 93, 23);
		contentPane.add(btnNewButton_2_1);
		
		JLabel lblNewLabel_6_1_1 = new JLabel("Instore Number");
		lblNewLabel_6_1_1.setFont(new Font("����", Font.BOLD, 18));
		lblNewLabel_6_1_1.setBounds(684, 187, 157, 27);
		contentPane.add(lblNewLabel_6_1_1);
		
		JButton btnNewButton_2_1_1 = new JButton("Print");
		btnNewButton_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					String sql2= "select distinct tb3.inv_id, tb3.ch_name,tb3.en_name, IFNULL(tb2.largenum,0.00) as buy,\r\n" + 
							" IFNULL(tb1.bignum,0.00) as sale "
		
							+ " ,IFNULL(tb2.largenum,0.00) - IFNULL(tb1.bignum,0.00) as storing, " + 
							"IFNULL(tb2.cost,0.00)  as cost "+
							"from (inventorylist tb3\r\n" + 
							"left join calcu tb1\r\n" + 
							"on tb1.goodid =  tb3.inv_id)\r\n" + 
							"left join calcu2 tb2\r\n" + 
							"on tb3.inv_id = tb2.invid";

					PreparedStatement pst= connection.prepareStatement(sql2);
//					System.out.println(sql2);
					ArrayList<String[]> arr = new ArrayList<>();
					ResultSet rs = pst.executeQuery();
					int index = 0;
					while(rs.next())
					{
						String tt[] = new String[7]; 
//						System.out.print(rs.getString("en") + " ");
//						System.out.print(rs.getString("ch") + " ");
//						System.out.print(rs.getString("price") + " ");
//						System.out.print(rs.getString("unit") + " ");
//						
//						System.out.print(rs.getString("qty") + " ");
//						System.out.print(rs.getString("taxrate") + " ");
						

						
						tt[0] = rs.getString("inv_id");
						tt[1] = rs.getString("ch_name");
						tt[2] = rs.getString("en_name");
						
						tt[3] = rs.getString("buy").replace("0E-8","0.00");
						tt[4] = rs.getString("sale").replace("0E-8","0.00");
						tt[5] = rs.getString("storing").replace("0E-8","0.00");
						tt[6] = rs.getString("cost");


						index++;
						
						System.out.println("");
						 arr.add(tt);
						 
					}
					String goods [][] = (String[][])arr.toArray(new String[0][]);

					gen_xls.save_stock( goods);
//					JOptionPane.showMessageDialog(null, "Save Product Info done!");
//					System.out.print("Total item:"+index );

					Runtime.getRuntime().exec(sqlcon.exepath+" "+sqlcon.savepath+"stock.xls");
//					Runtime.getRuntime().exec(sqlcon.exepath+" F:/generated/backup/product.xls");
					pst.close();				
					rs.close();				
				} catch (Exception e2) {
					e2.printStackTrace();
				}
														
				
				
				
			}
			
		});
		btnNewButton_2_1_1.setBounds(700, 272, 93, 23);
		contentPane.add(btnNewButton_2_1_1);
		refreshTable();
	}
}
